-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: priggm80_pgs66
-- ------------------------------------------------------
-- Server version	5.7.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AccountPayables`
--

DROP TABLE IF EXISTS `AccountPayables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AccountPayables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `APID` varchar(100) NOT NULL,
  `OrderID` int(10) unsigned DEFAULT '0',
  `fo_Vendor` int(11) unsigned DEFAULT '0',
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `fo_UnitPrice` float(10,2) DEFAULT '0.00',
  `fo_Description` text,
  `fo_Discount` float(10,2) DEFAULT '0.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `APID_unique` (`APID`),
  KEY `OrderID` (`OrderID`),
  KEY `fo_Vendor` (`fo_Vendor`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AccountPayables`
--

LOCK TABLES `AccountPayables` WRITE;
/*!40000 ALTER TABLE `AccountPayables` DISABLE KEYS */;
/*!40000 ALTER TABLE `AccountPayables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ActCard`
--

DROP TABLE IF EXISTS `ActCard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ActCard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ACID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ACID_unique` (`ACID`),
  KEY `ccpID` (`ccpID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ActCard`
--

LOCK TABLES `ActCard` WRITE;
/*!40000 ALTER TABLE `ActCard` DISABLE KEYS */;
/*!40000 ALTER TABLE `ActCard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Approval`
--

DROP TABLE IF EXISTS `Approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Approval` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Status` varchar(40) NOT NULL,
  `Description` text,
  `other_details` text,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Approval`
--

LOCK TABLES `Approval` WRITE;
/*!40000 ALTER TABLE `Approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `Approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Audit`
--

DROP TABLE IF EXISTS `Audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AuditNo` varchar(40) NOT NULL,
  `Rectitle` varchar(256) DEFAULT NULL,
  `fo_Desc` text,
  `fo_Auditor` varchar(10) NOT NULL,
  `fo_Classification` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `fo_AuditMemo` tinyint(4) DEFAULT '0',
  `fo_AuditPlan` tinyint(4) DEFAULT '0',
  `fo_AuditNote` tinyint(4) DEFAULT '0',
  `fo_AuditReport` tinyint(4) DEFAULT '0',
  `fo_NoObservation` smallint(6) DEFAULT '0',
  `fo_NoMinorNC` smallint(6) DEFAULT '0',
  `fo_NoMajorNC` smallint(6) DEFAULT '0',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `AuditNo_unique` (`AuditNo`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Audit`
--

LOCK TABLES `Audit` WRITE;
/*!40000 ALTER TABLE `Audit` DISABLE KEYS */;
INSERT INTO `Audit` (`id`, `AuditNo`, `Rectitle`, `fo_Desc`, `fo_Auditor`, `fo_Classification`, `fo_Regdate`, `fo_AuditMemo`, `fo_AuditPlan`, `fo_AuditNote`, `fo_AuditReport`, `fo_NoObservation`, `fo_NoMinorNC`, `fo_NoMajorNC`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'6140_001','KL PETROGAS INTERNAL AUDIT','INTERNAL AUDIT IN JUNE','Internal A','Management System Audit','2019-08-23',NULL,NULL,NULL,1,0,0,0,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-23 12:14:31',NULL),(2,'6140_002','EXTERNAL AUDIT: STAGE 1 ISO 9001:2015','- The audit plan was covered in full.\r\n- Current activities of the organization is in line with scope of certification, with exclusion of clause 8.3 Design and Development of product and service. \r\n- Various documented procedures are established in the QMS to enhance operation effectiveness.\r\n- Level of compliance with ISO9001:2015 are concluded as effective and satisfactory except for areas highlighted in this audit report.','External A','Management System Audit','2019-06-14',1,1,1,1,0,0,0,NULL,'Summary of conformity:\r\nGenerally, the Quality Management System is found to be established in accordance with ISO 9001:2015 except for areas highlighted in this audit report.\r\n\r\nPositive findings:\r\nThe organization management team represented by Mr. Syamsul Nizam Azmee (QMR), Mr. Mohd Hatta Zakaria (Project Manager), Mr. Azri Abas (Corporate) and others shown good commitment in implementation of quality management system based on ISO 9001:2015 requirements in the organization.','<div><b>Audit Findings:</b></div><div><br></div><div><u>Opportunities for Improvement:</u></div><div>1. To continue/strengthen the implementation of quality management system by taking appropriate actions to areas of concerned as per reported in this audit.</div><div>2. The management and staff were co-operative and helpful in the audit process. The staff were open-minded to receive audit findings.</div><div><br></div>','https://mega.nz/#F!UaonRCxQ!8HoY95RiiIO6eczuqvw1sg',NULL,'AUDIT_REPORT_STAGE_1.pdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-23 12:16:11','2019-10-08 10:50:32'),(3,'6140_003','EXTERNAL AUDIT: STAGE 2 ISO 9001:2015','- The audit plan was covered in full\r\n- Current activities of the organization is in line with scope of certification.\r\n- Various documented procedure are established in the QMS to enhance operational effectiveness.\r\n- Level of compliance with ISO 9001:2015 are concluded as effective and satisfactory except for areas highlighted in this audit report.','External A','Management System Audit','2019-07-13',1,1,1,1,3,4,0,NULL,'Additional statement of QMS scope: Project management for offshore transportation, installation, inspection, repair and maintenance projects.\r\n\r\nAudit findings:\r\n\r\nSummary of Conformity:\r\n- Generally, the Quality Management System is found to be established and effectively implemented in accordance with ISO 9001:2015 except for areas highlighted in this audit report.\r\n\r\nPositive findings:\r\n- The organization management team represented by Mr. Azri Abas (CSM), Mr. Syamsul Nizam (QMR) and others shown good commitment in implementation of quality management system  based on ISO 9001:2015 requirements in the organization.\r\n- Generally, the procedure and form were found to be effectively implemented, maintained and reviewed by the process owner and respective Head of Department.\r\n\r\nOpportunities of Improvement:\r\n- To continue / strengthen the implementation of quality management system by taking appropriate actions to areas of concerned as per reported in this audit.','<div>Reference Form ID Number:</div><div><br></div><div>6160_001 CAR</div><div>6160_002 CAR</div><div>6160_003 PAR</div><div><div style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: \" open=\"\" sans\",sans-serif;=\"\" 11.93px;=\"\" 400;=\"\" 2;=\"\" left;=\"\" none;=\"\" 0px;=\"\" normal;=\"\" 0px;\"=\"\">6160_004 CAR</div><div style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: \" open=\"\" sans\",sans-serif;=\"\" 11.93px;=\"\" 400;=\"\" 2;=\"\" left;=\"\" none;=\"\" 0px;=\"\" normal;=\"\" 0px;\"=\"\">6160_005 CAR</div><div style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: \" open=\"\" sans\",sans-serif;=\"\" 11.93px;=\"\" 400;=\"\" 2;=\"\" left;=\"\" none;=\"\" 0px;=\"\" normal;=\"\" 0px;\"=\"\">6160_006 PAR</div><b></b><i></i><u></u><sub></sub><sup></sup><strike></strike><div style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: \" open=\"\" sans\",sans-serif;=\"\" 11.93px;=\"\" 400;=\"\" 2;=\"\" left;=\"\" none;=\"\" 0px;=\"\" normal;=\"\" 0px;\"=\"\">6160_007 PAR</div><div style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: \" open=\"\" sans\",sans-serif;=\"\" 11.93px;=\"\" 400;=\"\" 2;=\"\" left;=\"\" none;=\"\" 0px;=\"\" normal;=\"\" 0px;\"=\"\">6160_008 PAR</div><div style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: \" open=\"\" sans\",sans-serif;=\"\" 11.93px;=\"\" 400;=\"\" 2;=\"\" left;=\"\" none;=\"\" 0px;=\"\" normal;=\"\" 0px;\"=\"\"><br></div><b></b><i></i><u></u><sub></sub><sup></sup><strike></strike><br></div><div><b></b><i></i><u></u><sub></sub><sup></sup><strike></strike><b></b><i></i><u></u><sub></sub><sup></sup><strike></strike><br></div><div><br></div>','https://mega.nz/#F!xK4nGYzQ!3bXVo6blbJanx76aqartXg',NULL,'AUDIT_REPORT_STAGE_2.pdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-29 13:19:16','2019-10-08 10:54:28');
/*!40000 ALTER TABLE `Audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Bi_WeeklyMeeting`
--

DROP TABLE IF EXISTS `Bi_WeeklyMeeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Bi_WeeklyMeeting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `BwmID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BwmID_unique` (`BwmID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bi_WeeklyMeeting`
--

LOCK TABLES `Bi_WeeklyMeeting` WRITE;
/*!40000 ALTER TABLE `Bi_WeeklyMeeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `Bi_WeeklyMeeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Breakdown`
--

DROP TABLE IF EXISTS `Breakdown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Breakdown` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recID` varchar(256) NOT NULL,
  `MTSID` int(10) unsigned DEFAULT NULL,
  `ResourceId` int(10) unsigned DEFAULT NULL,
  `Title` varchar(256) NOT NULL,
  `fo_Description` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherDetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `recID_unique` (`recID`),
  KEY `MTSID` (`MTSID`),
  KEY `ResourceId` (`ResourceId`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Breakdown`
--

LOCK TABLES `Breakdown` WRITE;
/*!40000 ALTER TABLE `Breakdown` DISABLE KEYS */;
/*!40000 ALTER TABLE `Breakdown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CalibrationCtrl`
--

DROP TABLE IF EXISTS `CalibrationCtrl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CalibrationCtrl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CalibrationID` varchar(250) NOT NULL,
  `Calibtitle` varchar(256) DEFAULT NULL,
  `fo_InventoryID` int(10) unsigned DEFAULT NULL,
  `fo_CalCom` int(11) unsigned DEFAULT NULL,
  `fo_DurCal` text,
  `fo_Delivdate` date DEFAULT NULL,
  `fo_contact_person` varchar(100) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CalibrationID_unique` (`CalibrationID`),
  KEY `fo_InventoryID` (`fo_InventoryID`),
  KEY `fo_CalCom` (`fo_CalCom`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CalibrationCtrl`
--

LOCK TABLES `CalibrationCtrl` WRITE;
/*!40000 ALTER TABLE `CalibrationCtrl` DISABLE KEYS */;
/*!40000 ALTER TABLE `CalibrationCtrl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Campaign`
--

DROP TABLE IF EXISTS `Campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Campaign` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CampaignID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CampaignID_unique` (`CampaignID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Campaign`
--

LOCK TABLES `Campaign` WRITE;
/*!40000 ALTER TABLE `Campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `Campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClaimRecord`
--

DROP TABLE IF EXISTS `ClaimRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ClaimRecord` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CRID` varchar(100) NOT NULL,
  `ReceivablesID` int(10) unsigned DEFAULT '0',
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_UnitPrice` float(10,2) DEFAULT '0.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CRID_unique` (`CRID`),
  KEY `ReceivablesID` (`ReceivablesID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClaimRecord`
--

LOCK TABLES `ClaimRecord` WRITE;
/*!40000 ALTER TABLE `ClaimRecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `ClaimRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Client`
--

DROP TABLE IF EXISTS `Client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Client` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ClientID` varchar(250) NOT NULL,
  `CompanyName` varchar(255) DEFAULT NULL,
  `fo_ContactName` varchar(200) DEFAULT NULL,
  `fo_ContactTitle` varchar(200) DEFAULT NULL,
  `fo_Address` varchar(250) DEFAULT NULL,
  `fo_City` varchar(100) DEFAULT NULL,
  `fo_Region` varchar(100) DEFAULT NULL,
  `fo_PostalCode` varchar(10) DEFAULT NULL,
  `fo_Country` varchar(15) DEFAULT NULL,
  `fo_Phone` varchar(24) DEFAULT NULL,
  `fo_Fax` varchar(24) DEFAULT NULL,
  `fo_Email` varchar(80) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherDetails` text,
  `ot_Comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ClientID_unique` (`ClientID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Client`
--

LOCK TABLES `Client` WRITE;
/*!40000 ALTER TABLE `Client` DISABLE KEYS */;
INSERT INTO `Client` (`id`, `ClientID`, `CompanyName`, `fo_ContactName`, `fo_ContactTitle`, `fo_Address`, `fo_City`, `fo_Region`, `fo_PostalCode`, `fo_Country`, `fo_Phone`, `fo_Fax`, `fo_Email`, `ot_FileLoc`, `ot_otherDetails`, `ot_Comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'2030_001','SUBSEA EXPLORE SERVICES (M) SDN BHD','Adam Hisham bin Salehuddin','Project Engineer','Lot 18 & 20, Jalan PJU 3/39, SME Bank Factory Complex, Sunway Damansara','Petaling Jaya','Central','47810','Malaysia','+603-7885 8700','+603-7885 9700',NULL,'adamhisham@subsearov.com','Subsea Explore Services (Subsea) is a specialize Service Contractor primarily involve in Oil and Gas industry in the area of seabed-to-surface covering worldwide. We provide wide range of equipments and technology solutions tailored to the given objective with cost-effective solutions.\r\n\r\nOur solutions are driven by understanding general client needs and specific technical requirements by deploying best value-added technology with innovation, efficient and cost effective approach and adaptation to dynamic environment of the industry that demand player to strive for excellence performance.\r\n\r\nFounded in 2005, Subsea has grown significantly over the years and remains as an integrated support services provider for the offshore industries via our expanding business portfolio in ROV, Diving, Survey, NDT, Telecommunications and Engineering services. We aims to be company recognized for technical excellence, innovation and quality services.','<p align=\"justify\" style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: &amp;quot;Open Sans&amp;quot;,sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; margin-bottom: 10px; margin-left: 0px; margin-right: 0px; margin-top: 0px; orphans: 2; text-align: justify; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">Our Vision<br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\">      We will develop Subsea Explore Services to be the most successful and admired                        subsea and maritime services company recognized worldwide for technical                         excellence, innovation and quality services.<br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\">Our Mission<br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\">• To provide quality products and services to our customers worldwide.                         <br style=\"box-sizing: border-box;\">• To build a dedicated team of employees with passion to provide the best                         customer support and technical services.                         <br style=\"box-sizing: border-box;\">• To provide participation, growth and fair compensation to each employee and                         reward performance based work.                         <br style=\"box-sizing: border-box;\">• To build passionate and equitable partnerships with our suppliers and                        partners.                         <br style=\"box-sizing: border-box;\">• To build a profitable business and create sustainable growth.<br style=\"box-sizing: border-box;\"></p><br style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: &amp;quot;Open Sans&amp;quot;,sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\"><p align=\"center\" style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: &amp;quot;Open Sans&amp;quot;,sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; margin-bottom: 10px; margin-left: 0px; margin-right: 0px; margin-top: 0px; orphans: 2; text-align: center; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\"><img style=\"border-bottom-color: currentColor; border-bottom-style: none; border-bottom-width: 0px; border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; border-left-color: currentColor; border-left-style: none; border-left-width: 0px; border-right-color: currentColor; border-right-style: none; border-right-width: 0px; border-top-color: currentColor; border-top-style: none; border-top-width: 0px; box-sizing: border-box; vertical-align: middle;\" src=\"\"></p><p align=\"center\" style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: &amp;quot;Open Sans&amp;quot;,sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; margin-bottom: 10px; margin-left: 0px; margin-right: 0px; margin-top: 0px; orphans: 2; text-align: center; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\"><br style=\"box-sizing: border-box;\"></p><p align=\"center\" style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: &amp;quot;Open Sans&amp;quot;,sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; margin-bottom: 10px; margin-left: 0px; margin-right: 0px; margin-top: 0px; orphans: 2; text-align: center; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\">At Subsea Explore Services, we believe that the highest standards of corporate governance are essential to our business integrity, reputation and performance.<br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\"><b style=\"box-sizing: border-box; font-weight: bold;\">Board of Directors</b><br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\">The Board represents and is accountable to the shareholders of the company. The Board\'s responsibilities are to regularly evaluate the strategic direction of the company, management policies and the effectiveness with which management implements them. The Board\'s responsibilities also include overseeing the structure and composition of the company\'s top management and monitoring legal compliance and the management of risks related to the company\'s operations.<br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\"><b style=\"box-sizing: border-box; font-weight: bold;\">Audit Committee </b><br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\">The Audit Committee meets at least twice a year to monitor the integrity of financial reporting and statements, the independence and performance of the Auditors, the effectiveness of the internal financial controls and the compliance with legal and regulatory requirements.<br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\"><b style=\"box-sizing: border-box; font-weight: bold;\">Remuneration Committee</b><br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\">The Remuneration Committee meets at least annually and is responsible for recommending to the Board the remuneration of Executive Directors and senior executives including the payment of bonuses and share options.<br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\"><b style=\"box-sizing: border-box; font-weight: bold;\">Health, Safety and Environment</b><br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\">The Company has an overriding commitment to health, safety and environmental responsibility. The Company works closely to ensure internationally recognised standards are implemented and maintained across its operations The Board of Directors is responsible for setting objectives and targets, monitoring performance and providing the necessary resources to support its commitment. All employees have responsibility for HSE awareness and the commitment to high standards. The Board has a clearly defined a Health, Safety and Environment Policy. <br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\"><b style=\"box-sizing: border-box; font-weight: bold;\">Internal control</b><br style=\"box-sizing: border-box;\"><br style=\"box-sizing: border-box;\">The directors acknowledge their responsibility for the Company\'s system of internal control and for reviewing its effectiveness. The system of internal control is designed to safeguard the Company\'s assets and interests and to help ensure accurate reporting and to help ensure compliance with applicable laws and regulation.<br style=\"box-sizing: border-box;\"></p><br>','https://mega.nz/#F!z7JXxCLA!zb4SHRHrTgtyR1SvLERbjQ','http://www.subsearov.com',NULL,NULL,'38930900_1564845490.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-03 23:18:10',NULL),(2,'2030_002','WOOD GROUP ENGINEERING SDN BHD',NULL,'Tender Secretary / Procurement Manager','Unit 1, Level 18, Naza Tower, Platinum Park No. 10, Persiaran KLCC','KUALA LUMPUR','KUALA LUMPUR','50088','Malaysia','+603 9212 4502',NULL,'TenderSecretary.Hess@woodplc.com',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 14:38:44',NULL),(3,'2030_003','MUHIBBAH ENGINEERING (M) BHD',NULL,NULL,'Lot 586 & 579, 2nd Mile, Jalan Batu Tiga Lama,','KLANG','SELANGOR','41300','Malaysia','(+603) 3342 4323','(+603) 3342 4327',NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 16:48:02',NULL),(4,'2030_004','VESTIGO PETROLEUM SDN BHD',NULL,NULL,'Jalan Ampang 50450 Kuala Lumpur Federal Territory of Kuala Lumpur','KUALA LUMPUR','KUALA LUMPUR','50450','Malaysia','+60 3-2776 9999',NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-26 14:12:41',NULL),(5,'2030_005','CARIGALI HESS OPERATING COMPANY',NULL,NULL,'Level 14\r\nMenara 3 Petronas\r\nKuala Lumpur City Centre','KUALA LUMPUR','KUALA LUMPUR','50088','Malaysia',NULL,NULL,NULL,NULL,NULL,'<br>','https://www.hess.com/operations',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-26 14:24:47',NULL),(6,'2030_006','PETRONAS GAS BERHAD (PGB)',NULL,NULL,'Jalan Tun Tan Cheng Lock 50000 Kuala Lumpur Federal Territory of Kuala Lumpur','KUALA LUMPUR','KUALA LUMPUR','50000','Malaysia',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-26 14:29:42','2019-10-01 12:21:29'),(7,'2030_007','GICON GROUP',NULL,NULL,'Germany',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 22:43:21',NULL),(8,'2030_008','E&P O&M SERVICES (EPOMS)',NULL,NULL,'A-25-1, Hampshire Place Office,1 57 Hampshire,1 Jalan Mayang Sari','KUALA LUMPUR','KUALA LUMPUR','50450','Malaysia','+603 - 220 306 00',NULL,'info@epoms.com.my',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 22:46:37',NULL),(9,'2030_009','PETRONAS',NULL,NULL,'PETRONAS Twin Towers','KUALA LUMPUR','KUALA LUMPUR','50088','Malaysia',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 22:53:33','2019-09-23 09:51:33'),(10,'2030_010','REPSOL OIL & GAS MALAYSIA LIMITED',NULL,'Procurement Supervisor','Level 39, Menara Citibank,\r\nNo 165, Jalan Ampang,\r\n50450 Kuala Lumpur','KUALA LUMPUR','KUALA LUMPUR','50450','Malaysia',NULL,NULL,'Bidsecretary11@repsol.com',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-17 16:01:52',NULL),(11,'2030_011','PETRONAS CARIGALI SDN BHD (PCSB)',NULL,NULL,'PETRONAS Twin Towers','KUALA LUMPUR','KUALA LUMPUR','50088','Malaysia',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-27 23:57:58',NULL),(12,'2030_012','MALAYSIA MARINE & HEAVY ENGINEERING SDN BHD (MMHE)','Nik Faiz Alzry Nik Mohammed Kamil','Commercial Services','MMHE West, PLO 3,\r\nJalan Pekeliling, P.O. Box 77,\r\n81700 Pasir Gudang, Johor, Malaysia','PASIR GUDANG','JOHOR','81700','Malaysia',NULL,NULL,'nik.faiz@mmhe.com.my',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-16 18:11:46',NULL);
/*!40000 ALTER TABLE `Client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CommConsParticipate`
--

DROP TABLE IF EXISTS `CommConsParticipate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CommConsParticipate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ccpID` varchar(40) NOT NULL,
  `WorkLocationID` int(10) unsigned DEFAULT NULL,
  `fo_WorkDate` date DEFAULT NULL,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ccpID_unique` (`ccpID`),
  KEY `WorkLocationID` (`WorkLocationID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CommConsParticipate`
--

LOCK TABLES `CommConsParticipate` WRITE;
/*!40000 ALTER TABLE `CommConsParticipate` DISABLE KEYS */;
INSERT INTO `CommConsParticipate` (`id`, `ccpID`, `WorkLocationID`, `fo_WorkDate`, `fo_RequiredDate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'6010_2019_Q3',1,'2019-07-17','2019-09-30',NULL,NULL,'<br>',NULL,NULL,'Q3_CALENDAR_CONSULTATION.pdf',NULL,'29613400_1568704313.JPG',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-17 12:11:14','2019-09-20 10:51:36'),(2,'6010_2019_Q4',1,'2019-10-01','2019-12-31',NULL,'2019 Fourth Quarter training plan','<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-23 11:01:02',NULL);
/*!40000 ALTER TABLE `CommConsParticipate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Competency`
--

DROP TABLE IF EXISTS `Competency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Competency` (
  `CompetencyID` int(11) NOT NULL AUTO_INCREMENT,
  `CompID` varchar(200) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `ProjectTeamID` int(11) DEFAULT NULL,
  `fo_CompetencySession` varchar(40) DEFAULT NULL,
  `fo_Description` text,
  `fo_Date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`CompetencyID`),
  UNIQUE KEY `CompID_unique` (`CompID`),
  KEY `EmployeeID` (`EmployeeID`),
  KEY `ProjectTeamID` (`ProjectTeamID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Competency`
--

LOCK TABLES `Competency` WRITE;
/*!40000 ALTER TABLE `Competency` DISABLE KEYS */;
/*!40000 ALTER TABLE `Competency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ContinualImprovement`
--

DROP TABLE IF EXISTS `ContinualImprovement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ContinualImprovement` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CAPARno` varchar(40) NOT NULL,
  `RecTitle` varchar(256) DEFAULT NULL,
  `fo_Class` varchar(100) NOT NULL,
  `fo_CAPAR` text NOT NULL,
  `fo_Desc` text,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CAPARno_unique` (`CAPARno`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContinualImprovement`
--

LOCK TABLES `ContinualImprovement` WRITE;
/*!40000 ALTER TABLE `ContinualImprovement` DISABLE KEYS */;
INSERT INTO `ContinualImprovement` (`id`, `CAPARno`, `RecTitle`, `fo_Class`, `fo_CAPAR`, `fo_Desc`, `fo_Regdate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'6160_001','QMS SCOPE','External','Corrective Action Request','It was clearly defined the quality management system scope in the quality manual.','2019-08-23','614','ROOT CAUSE & CORRECTION \r\n(a) Quality Management System Scope was described on different revision of document, the latest version of the QMS manual  [Doc number; PG-QMS/QAC/M001, Rev 2, Effective date 05/07/2019]. \r\n\r\nCORRECTION\r\n(b) Updated PETROGAS Quality Manual had been established and documented, Refer attachment Extracted pagesfrom QMS manual.  \r\nResponsibility: QMR\r\nDate Implemented: 5/7/2019\r\n\r\nCORRECTIVE ACTION\r\n(c ) ISO 9001:2015 requirements on clause 4.3 had been conducted to the project team members.\r\nResponsibility: QMR\r\nDate Implemented: 2/8/2019\"','Review effectiveness to be done on October 2019',NULL,NULL,NULL,NULL,'25871000_1566552436.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-23 12:22:29','2019-08-23 17:27:16'),(2,'6160_002','WORK ENVIRONMENT','External','Corrective Action Request','No evidence records to determine, provide and maintain the environment necessary for the operation of it processes and to achieve conformity of services, e.g. physical factors (temperature, light).','2019-08-23','F614','ROOT CAUSE & CORRECTION\r\n(a) The current work environment at the office is condusive, hence priority to perform such monitoring is taking less priority. Therefore the physical monitoring risk rating is being revised and inclusive under the annual scheduled plan.\r\n\r\nCORRECTION\r\n(b) Updated Risk rating specific process had been established and documented. The template for the physical monitoring also attached accordingly. \r\nResponsibility: QMR\r\nDate Implemented: 18/7/2019\r\n\r\nCORRECTIVE ACTION\r\n(c ) ISO 9001:2015 requirements on clause 7.1.4 had been conducted to the project team members.\r\nResponsibility: QMR\r\nDate Implemented: 2/8/2019\"','<br>',NULL,NULL,NULL,NULL,'87049200_1566887136.jpg',2,NULL,NULL,NULL,2,NULL,'2019-08-23 17:46:30','2019-08-27 14:26:10'),(3,'6160_003','ORGANIZATIONAL KNOWLEDGE','External','Preventive Action Request','Although the organization knowledge determined, however some of the organization knowledge were not included in the Annual Training Plan 2019 (F3035, Rev. No. 0, Effective date: 1/1/2019) to ensure the organization knowledge are shared and passed down to the employees, e.g. (PG/QMS/QAC/F6122, Rev. No. 0, Effective date: 1/1/2019), e.g. Project Execution Coaching Program, Mentoring Partnership Agreement, and etc.','2019-08-23','F614','Root caused:\r\n(a)  Lack of interdepartmental coordination for training plan','(b) Correction:<div>- Training plan coordination meeting between every department.&nbsp;</div><div>- To finalise training plan for 2019</div><div><br></div><div>(c) Corrective action:</div><div>- Review and endorse new PIRADC to include annual training coordination meeting frequency of at least once a year.</div><div><br></div>',NULL,NULL,NULL,NULL,'83325000_1566887379.jpg',2,NULL,NULL,NULL,NULL,NULL,'2019-08-23 17:59:45','2019-09-03 09:10:20'),(4,'6160_004','QMS INADEQUATE OBJECTIVE EVIDENCES','External','Corrective Action Request','\"I) Inadequate objective evidences were recorded for some areas or processes audited during internal audit conducted on 4/7/19, e.g. Process: Project Planning; Quoting, Bidding & Order, Risk based thinking, Information & Equipment Maintenance, Organizational Knowledge Management,  etc.\r\nNotes: Examples of objective evidence, e.g. Project title audited, PQP ref. number, tender/ quotation ref. number, risk assessment document ref. number, equipment maintenance schedule, sample of equipment maintenance record, records of organization knowledge shared,etc.','2019-08-26','F614','(a) The current internal audit checklist only cover some processes on the QMS, hence the objective evidence of other activity unable to be captured.','<table width=\"251\" style=\"border-collapse:&#10; collapse;width:188pt\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><colgroup><col width=\"251\" style=\"mso-width-source:userset;mso-width-alt:9179;width:188pt\"></colgroup><tbody><tr height=\"347\" style=\"mso-height-source:userset;height:260.25pt\"><td width=\"251\" height=\"347\" style=\"height:260.25pt;width:188pt\">(b)\r\n  New Internal audit checklist had been established and documented. <br>\r\n    Responsibility: QMR<br><div>\r\n    Date Implemented: 1/8/2019<br></div><div><table width=\"251\" style=\"border-collapse:&#10; collapse;width:188pt\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><colgroup><col width=\"251\" style=\"mso-width-source:userset;mso-width-alt:9179;width:188pt\">\r\n </colgroup><tbody><tr height=\"205\" style=\"page-break-before:always;mso-height-source:userset;&#10;  height:153.75pt\">\r\n\r\n  <td width=\"251\" height=\"205\" style=\"height:153.75pt;width:188pt\"><br></td>\r\n\r\n </tr>\r\n</tbody></table><b></b><i></i><u></u><sub></sub><sup></sup><strike></strike><br></div>\r\n    </td>\r\n\r\n </tr>\r\n</tbody></table><b></b><i></i><u></u><sub></sub><sup></sup><strike></strike><br>',NULL,NULL,NULL,NULL,'30386200_1566887541.jpg',2,NULL,NULL,NULL,2,NULL,'2019-08-26 11:39:14','2019-08-27 14:32:37'),(5,'6160_005','QMS INTERNAL AUDIT SCHEDULE','External','Corrective Action Request','II) Internal Audit Schedule established for year 2019 was not done by processes (currently scheduled by department, e.g. Sales, Operation, Purchasing, Maintenance, etc.) and lack of evidence the audit scheduling was done by taking consideration on importance of the processes concerned, changes affecting the organization, and the results of previous audits, etc.','2019-08-26','F614','(a) The current Internal audit plan only cover the critical issues on the department level, hence the processess audit was planned to be done later stage once the organization operates at full spread.','<table width=\"251\" style=\"border-collapse:\r\n collapse;width:188pt\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n <colgroup><col width=\"251\" style=\"mso-width-source:userset;mso-width-alt:9179;width:188pt\">\r\n </colgroup><tbody><tr height=\"205\" style=\"page-break-before:always;mso-height-source:userset;\r\n  height:153.75pt\">\r\n\r\n  <td width=\"251\" height=\"205\" style=\"height:153.75pt;width:188pt\">(b)\r\n  New Internal audit schedule had been established and documented. <br>\r\n    Responsibility: QMR<br>\r\n    Date Implemented: 1/8/2019<br>\r\n    <br>\r\n    (c ) ISO 9001:2015 requirements training on clause 9.2.2 had been conducted to the\r\n  project team members.<br>\r\n    Responsibility: QMR<br>\r\n    Date Implemented: 2/8/2019</td>\r\n\r\n </tr>\r\n</tbody></table><br>',NULL,NULL,NULL,NULL,'60215100_1566887716.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-26 11:41:53','2019-09-03 08:59:09'),(6,'6160_006','QMS DOCUMENT INFORMATION','External','Corrective Action Request','No evidence that some documented information was approved and controlled  with revision number and effective date prior to use, e.g. Continual Improvement (PG-QMS-QAC-P615), Management System Audit  (PG-QMS-QAC-P613), Management Review (PG-QMS-QAC-P613), Recruitment of Personnel (PG-QMS-HRA-P301), Training & Development (PG-QMS-HRA-P303), etc.','2019-08-26','F614','(a) The revision number of the document was not alligned with the previous ISO 9001:2008 record number, hence confirmation of the previous version of records only available to team on 15 July 2019. Therefore the record number and rivision number was left blank.','<table width=\"251\" style=\"border-collapse:&#10; collapse;width:188pt\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n <colgroup><col width=\"251\" style=\"mso-width-source:userset;mso-width-alt:9179;width:188pt\">\r\n </colgroup><tbody><tr height=\"224\" style=\"mso-height-source:userset;height:168.0pt\">\r\n\r\n  <td width=\"251\" height=\"224\" style=\"height:168.0pt;width:188pt\">(b)\r\n  Updated Document Master list had been established and documented, sample of\r\n  controlled records on Level 2 document is prepared accordingly.. <br>\r\n    Responsibility: QMR<br>\r\n    Date Implemented: 18/7/2019<br>\r\n    <br>\r\n    (c ) ISO 9001:2015 requirements on clause 7.5.2 had been conducted to the\r\n  project team members.<br>\r\n    Responsibility: QMR<br>\r\n    Date Implemented: 2/8/2019</td>\r\n\r\n </tr>\r\n</tbody></table><br>',NULL,NULL,NULL,NULL,'78007300_1566887908.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-26 11:43:49','2019-08-27 14:38:28'),(7,'6160_007','QMS MANAGEMENT REVIEW','External','Preventive Action Request','Management review meeting was conducted as per meeting minutes dated 10/7/19 had reviewed various review inputs, however some of the review inputs was not adequately discussed, e.g. feedback from interested parties, internal audit results, etc.','2019-08-26','F614',NULL,'<br>',NULL,NULL,NULL,NULL,'59193200_1566888036.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-26 11:44:56','2019-08-27 14:40:36'),(8,'6160_008','QMS ANALYSIS OF DATA','External','Preventive Action Request','Although analysis of data table was established (PG/QMS/QAC/F6124), data to be analyzed relevant to performance of external providers was not determined.','2019-08-26','F614',NULL,'<br>',NULL,NULL,NULL,NULL,'30776500_1566888176.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-26 11:45:43','2019-08-27 14:42:56');
/*!40000 ALTER TABLE `ContinualImprovement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ContractDeployment`
--

DROP TABLE IF EXISTS `ContractDeployment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ContractDeployment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(250) NOT NULL,
  `InquiryID` int(10) unsigned DEFAULT NULL,
  `fo_Type` text NOT NULL,
  `fo_Tajuk` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_ExeDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `InquiryID` (`InquiryID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContractDeployment`
--

LOCK TABLES `ContractDeployment` WRITE;
/*!40000 ALTER TABLE `ContractDeployment` DISABLE KEYS */;
INSERT INTO `ContractDeployment` (`id`, `DocconNumber`, `InquiryID`, `fo_Type`, `fo_Tajuk`, `fo_DocumentDescription`, `fo_ExeDate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'8020_008_006_001',8,'Others','Letter of Award','Letter of Award given from Petronas Gas Bhd',NULL,NULL,NULL,'<br>',NULL,NULL,'LETTER_OF_AWARD_ORIX.pdf',NULL,'75788800_1568780298.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-18 12:08:24','2019-09-18 12:20:33');
/*!40000 ALTER TABLE `ContractDeployment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DCN`
--

DROP TABLE IF EXISTS `DCN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DCN` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(255) NOT NULL,
  `DCCID` int(10) unsigned DEFAULT '0',
  `fo_DCCITEM` int(10) unsigned DEFAULT '0',
  `fo_Description` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `DCCID` (`DCCID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DCN`
--

LOCK TABLES `DCN` WRITE;
/*!40000 ALTER TABLE `DCN` DISABLE KEYS */;
/*!40000 ALTER TABLE `DCN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DailyProgressReport`
--

DROP TABLE IF EXISTS `DailyProgressReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DailyProgressReport` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ProgressReportId` varchar(100) NOT NULL,
  `DPRID` int(10) unsigned DEFAULT '0',
  `fo_Class` varchar(40) NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProgressReportId_unique` (`ProgressReportId`),
  KEY `DPRID` (`DPRID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DailyProgressReport`
--

LOCK TABLES `DailyProgressReport` WRITE;
/*!40000 ALTER TABLE `DailyProgressReport` DISABLE KEYS */;
/*!40000 ALTER TABLE `DailyProgressReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DeliveryOrder`
--

DROP TABLE IF EXISTS `DeliveryOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DeliveryOrder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DOID` varchar(100) NOT NULL,
  `OrderID` int(10) unsigned DEFAULT '0',
  `fo_Vendor` int(11) unsigned DEFAULT '0',
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `fo_Description` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DOID_unique` (`DOID`),
  KEY `OrderID` (`OrderID`),
  KEY `fo_Vendor` (`fo_Vendor`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DeliveryOrder`
--

LOCK TABLES `DeliveryOrder` WRITE;
/*!40000 ALTER TABLE `DeliveryOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `DeliveryOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DesignProposal`
--

DROP TABLE IF EXISTS `DesignProposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DesignProposal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `InquiryID` int(10) unsigned DEFAULT NULL,
  `fo_Type` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Intro` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_RecSub` tinyblob NOT NULL,
  `fo_Submissiondate` date DEFAULT NULL,
  `fo_contact_person` varchar(100) DEFAULT NULL,
  `fo_Price` decimal(10,2) DEFAULT '0.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `InquiryID` (`InquiryID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DesignProposal`
--

LOCK TABLES `DesignProposal` WRITE;
/*!40000 ALTER TABLE `DesignProposal` DISABLE KEYS */;
INSERT INTO `DesignProposal` (`id`, `DocconNumber`, `InquiryID`, `fo_Type`, `fo_Intro`, `fo_DocumentDescription`, `fo_RecSub`, `fo_Submissiondate`, `fo_contact_person`, `fo_Price`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'8010_002_003_001',2,'Commercial','PROVISION FOR ENGINEERING, PROCUREMENT, CONSTRUCTION, INSTALLATION & COMMISSIONING (EPCIC) FOR PM9 SIMPLIFICATION PROJECT','Commercial proposal for the PM9 EPCIC Simplification project.',_binary 'External Submission',NULL,NULL,89366322.00,'F202',NULL,'<br>','https://mega.nz/#F!7qh3yQrQ!GhPv7-ax35XW1g9TczuqUw',NULL,'Commercial_Tender_PM9.pdf',NULL,'38038600_1568706949.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-27 15:22:30','2019-09-17 15:55:47'),(2,'8010_002_003_002',2,'Design Ref','INVITATION TO BID FOR PM9 SIMPLIFICATION PROJECT','Invitation to bid document for PM9 Simplification project by Mhuibbah Engineering',_binary 'External Submission','2019-08-01',NULL,0.00,NULL,NULL,'<br>',NULL,NULL,'Table_of_Content_ITQ.PDF','ITB_-_Muhibbah_Eng_-_PM9.zip','22148500_1568706518.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-17 15:45:28','2019-09-18 11:55:30'),(12,'8010_012_012_001',12,'Technical ','TECHNICAL PROPOSAL FOR PROVISION OF TRANSPORTATION & INSTALLATION OF BUNDLE 4 OWF (OFFSHORE WELLHEAD FACILITIES) PROJECTS','TECHNICAL PROPOSAL FOR PROVISION OF TRANSPORTATION & INSTALLATION OF BUNDLE 4 OWF (OFFSHORE WELLHEAD FACILITIES) PROJECTS',_binary 'External Submission','2019-10-16','Nik Faiz',0.00,NULL,NULL,'<br>',NULL,NULL,NULL,'MMHE_T&I_OWF_KL_PETROGAS_SDN_BHD.zip',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-16 18:23:22',NULL),(13,'8010_012_012_002',12,'Technical ','COMMERCIAL PROPOSAL FOR PROVISION OF TRANSPORTATION & INSTALLATION OF BUNDLE 4 OWF (OFFSHORE WELLHEAD FACILITIES) PROJECTS','COMMERCIAL PROPOSAL FOR PROVISION OF TRANSPORTATION & INSTALLATION OF BUNDLE 4 OWF (OFFSHORE WELLHEAD FACILITIES) PROJECTS',_binary 'External Submission','2019-10-16','Nik Faiz',99999999.99,NULL,NULL,'<br>','https://mega.nz/#F!EORhBKhZ!aj1nxwgkXxEBXW5pr_rZTA',NULL,'Commercial_Proposal.pdf','COMMERCIAL_PROPOSAL.zip',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-16 18:46:49','2019-10-17 14:58:12'),(8,'8010_009_009_001',9,'Design Ref','COVER LETTER FOR INVITATION TO BID FOR PROVISION OF MAINTENANCE SERVICES FOR SINGLE POINT MOORING (SPM) AND SUPPLY OF MARINE HOSES FOR PETRONAS GROUP OF COMPANIES','INVITATION TO BID FOR PROVISION OF MAINTENANCE SERVICES FOR SINGLE POINT MOORING (SPM) AND SUPPLY OF MARINE HOSES FOR PETRONAS GROUP OF COMPANIES',_binary 'External Submission','2019-10-21','Tender Secretariat, GFM',0.00,NULL,NULL,'<br>','https://mega.nz/#F!pHgRQahZ!fULAhqlFdWRyHhKtKekN3A',NULL,'COVER_LETTER__CATEX_2019_GFM_1001_KL_PET',NULL,'31029900_1569203979.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-23 09:59:39','2019-09-24 10:18:52'),(7,'8010_001_002_001',1,'Technical ','INVITATION TO BID FOR PROVISION OF OFFLOADING FLOATNG HOSE INSPECTION & MAINTENANCE SERVICES FOR WOOD GROUP ENGINEERING','INVITATION TO BID FOR PROVISION OF OFFLOADING FLOATNG HOSE INSPECTION & MAINTENANCE SERVICES FOR WOOD GROUP ENGINEERING',_binary 'External Submission',NULL,NULL,0.00,NULL,NULL,'<br>',NULL,NULL,'ITB_for_Floating_Hose_Inspection_(07-Aug',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-20 10:33:38',NULL),(14,'8010_003_004_001',3,'Technical ','PROJECT MANAGEMENT TEAM ORGANZATION CHART','PROJECT MANAGEMENT TEAM ORGANZATION CHART BY KL PETROGAS FOR THE PROVISION OF ENGINEERING,PROCUREMENT, CONSTRUCTION, INSTALLATION AND PRE-COMMISSIONING OF PIPELINE SYSTEM FOR TEMBIKAI NON\r\nASSOCIATED GAS (TNAG) DEVELOPMENT',_binary 'External Submission',NULL,NULL,0.00,NULL,NULL,'<br>',NULL,NULL,'PMT_Organization_Chart.pdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-17 13:18:45',NULL),(15,'8010_003_004_002',3,'Technical ','PROJECT MANAGEMENT TEAM ORGANIZATION MATRIX','PROJECT MANAGEMENT TEAM ORGANZATION MATRIX BY KL PETROGAS FOR THE PROVISION OF ENGINEERING,PROCUREMENT, CONSTRUCTION, INSTALLATION AND PRE-COMMISSIONING OF PIPELINE SYSTEM FOR TEMBIKAI NON\r\nASSOCIATED GAS (TNAG) DEVELOPMENT',_binary 'External Submission',NULL,NULL,0.00,NULL,NULL,'<br>',NULL,NULL,'PMT_Organization_Matrix.pdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-17 13:20:21',NULL),(16,'8010_002_003_003',2,'Technical ','PROJECT MANAGEMENT TEAM ORGANIZATION CHART','PROJECT MANAGEMENT TEAM ORGANIZATION CHART FOR PROVISION OF ENGINEERING,PROCUREMENT, CONSTRUCTION, INSTALLATION AND PRE-COMMISSIONING (EPCIC) FOR PM9 SIMPLICATION PROJECT',_binary 'External Submission',NULL,NULL,0.00,NULL,NULL,'<br>',NULL,NULL,'PMT_Organization_Chart.pdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-17 13:23:18',NULL),(17,'8010_002_003_004',2,'Technical ','PROJECT ORGANISATION CHART ( OFFSHORE CONSTRUCTION TEAM )','PROJECT ORGANISATION CHART ( OFFSHORE CONSTRUCTION TEAM ) FOR PROVISION OF ENGINEERING, PROCUREMENT, CONSTRUCTION, INSTALLATION AND PRE-COMMISSIONING (EPCIC) FOR PM9 SIMPLICATION PROJECT',_binary 'External Submission',NULL,NULL,0.00,NULL,NULL,'<br>',NULL,NULL,'OFFSHORE_ORGANIZATION_CHART.pdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-17 13:25:12','2019-10-17 13:33:41'),(18,'8010_010_011_002',10,'Technical ','PROJECT EXECUTION PLAN (PEP) AND METHOD OF STATEMENT (MOS)','Project Execution Plan (PEP) and Method of Statement (MOS) for EPCIC PL429 Pipeline Replacement Project',_binary 'External Submission','2019-10-24',NULL,0.00,NULL,NULL,'<br>','https://mega.nz/#F!MPgTAKRS!BpUSXtTLJoDJPXRDy3sUpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-25 12:42:53','2019-10-25 12:46:27'),(19,'8010_010_011_003',10,'Technical ','QUALITY ASSURANCE / QUALITY CONTROL (QAQC) REQUIREMENTS','Quality Assurance and Quality Control (QAQC) Requirements for the EPCIC PL429 Pipeline Replacement Project',_binary 'External Submission','2019-10-24',NULL,0.00,NULL,NULL,'<br>','https://mega.nz/#F!QKgDjKbS!cS-ij_0Oz_nyL8tWkpqvdQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-25 12:46:04','2019-10-25 12:50:41'),(20,'8010_010_011_004',10,'Technical ','FN HAT FLEX COMPANY BROCHURE & TECHNICAL SPECIFICATIONS','FN HAT FLEX Company Brochure with Technical Specifications',_binary 'External Submission','2019-10-24',NULL,0.00,NULL,NULL,'<br>','https://mega.nz/#F!sXgn0CSI!nobAMQnaam3_XAyALJU2og',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-25 12:49:13','2019-10-25 12:55:08'),(11,'8010_010_011_001',10,'Technical ','APPENDIX 4 - HSE QUESTIONAIRE','APPENDIX 4 - HSE QUESTIONAIRE DOCUMENTS',_binary 'External Submission','2019-10-11',NULL,0.00,NULL,NULL,'<br>','https://mega.nz/#F!ECgUwABT!f_-KT4KGxOjN_5PgKdCOXA',NULL,'App_4_HSE.pdf','App_4_HSE.zip','63166100_1569294101.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-24 11:00:03','2019-10-16 18:19:35');
/*!40000 ALTER TABLE `DesignProposal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DocControl`
--

DROP TABLE IF EXISTS `DocControl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DocControl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(250) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Class` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_DocumentType` text NOT NULL,
  `fo_Rev` varchar(256) DEFAULT '00',
  `fo_date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=158 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DocControl`
--

LOCK TABLES `DocControl` WRITE;
/*!40000 ALTER TABLE `DocControl` DISABLE KEYS */;
INSERT INTO `DocControl` (`id`, `DocconNumber`, `DocItem`, `fo_DocumentDescription`, `fo_Class`, `fo_DocumentType`, `fo_Rev`, `fo_date`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'6050_L1_QAC_M001','QUALITY MANAGEMENT SYSTEM MANUAL','QUALITY MANUAL\r\n\r\nPETROGAS requires all activities to be subjected to rigorous quality assurance procedures.  This Quality Manual has been developed to give support to all PETROGAS staff & its management to deliver and accomplish their task and activity in accordance with the Quality Management System (QMS).  At all-time this Quality Manual is placed at the center of all activities and become the guidance and reference for such quality related activity.','Quality','Manual','2','2019-04-01',NULL,NULL,'<br>','https://mega.nz/#F!1e5QnAhJ!TMKHuRPnFWr22Jy2U7EPYQ',NULL,'ISO_9001-2015_QMS_Manual.pdf',NULL,'39415400_1569298251.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 10:30:18','2019-09-24 12:13:00'),(2,'6050_L1_QAC_PIM001','PROCESS INTERACTION MAP','PROCESS INTERACTION MAP','Organization','Forms','0','2019-01-06',NULL,NULL,'<br>','https://mega.nz/#F!depyxY6b!8SmRvFjZtuYO7REeUvT_ug',NULL,'Process_Interaction.pdf','6050_L1_QAC_PIM001.zip','01840900_1569300608.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 12:25:37','2019-10-01 13:32:25'),(3,'6050_L1_QAC_0C001','ORGANIZATIONAL CHART','ORGANIZATIONAL CHART','Organization','Forms','0','2019-01-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 12:29:38','2019-08-04 12:31:50'),(4,'6050_L2_ASW_P101','INFRASTRUCTURE & EQUIPMENT MAINTENANCE','The purpose of this procedure is to define Petrogas’s process for ensuring that suitable facilities, infrastructure and working environments are provided and maintained as required to ensure product conformity. This includes planning, provision and maintenance of employee facilities, workspaces, equipment, software and associated services.\r\n\r\nThis procedure is applicable to the following infrastructures,\r\n\r\na)     Buildings, workspaces (various work areas) and associated utilities (e.g. lighting, split air conditioner units, central air conditioners, water tabs, toilet flushing system);\r\n\r\nb)    Process equipment e.g. Offshore machineries/ equipment (both hardware’s and software’s e.g. ROV system);\r\n\r\nc)     Supporting services such as transports e.g. folk lift, hand lift, lorry; communication technology and information system/ office equipment e.g.  photo copy machine, printer, fax machine, computer hardware (monitor, central processing unit/ CPU, key boards), computer software (antivirus system, application system, operating system), internet, email system, intranet, servers, telephone system/ PABX system).','Technical','Manual','2','2019-04-01','PG/QMS/ASW/P101','1.3 Responsibilities\r\n1.3.1 General Manager \r\nGeneral Manager has the responsibility, authority and accountable for:\r\na) Ensuring important document are available within organization.\r\nb) Ensure implementation of this procedure based on QMS requirement.\r\nc) Ensure all Preventive Maintenance Schedule (MH/QMS/ASW/F1014) was filled properly.\r\nd) Review and verify:\r\n• Maintenance Work Order [PG/QMS/ASW/F1011]\r\n• Equipment Fault Report [PG/QMS/ASW/F1014]\r\n• Updated Master List of infrastructure [PG/QMS/ASW/F1011]\r\n1.3.2 Process owner \r\nProcess owner have the responsibility for:\r\na) Designating a responsible for the improvement action once the potential causes are agreed.\r\nb) Verifying effectiveness of implementation of process flow\r\nc) Congratulating the employee that initiated implementation of process flow\r\n1.3.3 Person in-charge \r\nPerson in charge have the responsibility, authority and accountability for:\r\na) To achieve KPI that was set for this procedure\r\nb) Custodian to ensure Equipment Fault Report [PG/QMS/ASW/F1012] and Maintenance Work Order [PG/QMS/ASW/F1011] filled properly.\r\nc) Prepare and Updated Master List Infrastructure [PG/QMS/ASW/F1013]\r\nd) To execute the programs that have been set in this procedure\r\ne) To work with the input that available at organization hence can achieve the target that have been set.\r\nAll interested parties & employees have common responsibilities for:\r\na) Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure is the Project Engineer.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 General Manager 4<br>1.3.2 Process owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>2.1 CONTROLLING INFRASTRUCTURE &amp; NATURAL RESOURCES CONSIDERATION 5<br>2.1.1 Infrastructure 5<br>2.1.2 Personnel 8<br>2.1.3 Natural Resources 9<br>2.1.4 Waste 10<br>2.1.5 Review 10<br>3 DETAIL PROCEDURE 10<br>3.1 DETERMINE INFRASTRUCTURE FOR PLANNED PREVENTIVE MAINTENANCE 10<br>3.1.1 General 10<br>3.1.2 The MLIA shall include the following details: 10<br>3.1.3 The PPM Schedule shall include the following details: 10<br>3.2 CONDUCT PERIODIC MAINTENANCE 11<br>3.2.1 General 11<br>3.2.2 Work Execution 11<br>3.3 MAINTAIN MAINTENANCE RECORD 12<br>3.3.1 General 12<br>3.3.2 Status of Equipment 12<br>4 REVIEW AND VERIFY 12<br>5 CONTROL AND MONITORING 12<br>6 FORMS &amp; RECORDS 12<br>','https://mega.nz/#F!PnQFgagA!PFcQy5A9IphtyYDkzUle0g',NULL,NULL,NULL,'09677800_1566878325.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 12:39:48','2019-08-27 11:58:45'),(5,'6050_L3_ASW_GL1011','GUIDELINE FOR INFRASTRUCTURE & EQUIPMENT MAINTENANCE','GUIDELINE FOR INFRASTRUCTURE & EQUIPMENT MAINTENANCE currently not available','Organization','Forms','00','2019-08-04',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 12:43:05','2019-08-04 17:26:38'),(6,'6050_L4_ASW_F1011','MAINTENANCE WORK ORDER','MAINTENANCE WORK ORDER','Quality','Procedure','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 14:19:01','2019-08-04 14:19:36'),(7,'6050_L4_ASW_F1012','EQUIPMENT FAULT REPORT','EQUIPMENT FAULT REPORT','Technical','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 14:25:19',NULL),(8,'6050_L4_ASW_F1013','MASTER LIST OF INFRASTRUCTURE','MASTER LIST OF INFRASTRUCTURE','Quality','Guideline','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 14:28:30',NULL),(9,'6050_L4_ASW_F1014','PREVENTIVE MAINTENANCE SCHEDULE','PREVENTIVE MAINTENANCE SCHEDULE','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 14:33:30',NULL),(10,'6050_L2_ASW_P102','GOODS EQUIPMENT RECEIVING, HANDLING & INSPECTION','The purpose of this procedure is to define Petrogas’ s process for ensuring that goods equipment receiving handling and inspection method and criteria are provided and maintained as required to ensure product conformity. This includes planning, provision and inspection of goods, equipment, workspaces, equipment, software and associated services.\r\nThe scope of this procedure documents Petrogas’s approach to the goods equipment receiving handling and inspection method and the use of resources to support operations and to ensure that risks associated with the provision of goods and equipment are adequately managed in order to minimise negative environmental impacts and to reduce the risk of injury or harm to employees.','Quality','Manual','1','2019-06-01','PG/QMS/ASW/P102','1.3 Responsibilities\r\n1.3.1 General Manager \r\nGeneral Manager has the responsibility, authority and accountable for:\r\na) Ensuring important document are available within organization.\r\nb) Ensure yard personnel inspect the received spares/parts.\r\nc) Review and verify Asset Register\r\nd) Ensure availability of Asset/Inventory File\r\n1.3.2 Process owner \r\nProcess owner have the responsibility for:\r\na) Designating a responsible for the improvement action once the potential causes are agreed.\r\nb) Verifying effectiveness of implementation of process flow\r\nc) Congratulating the employee that initiated implementation of process flow\r\n1.3.3 Person in-charge \r\nPerson in charge have the responsibility, authority and accountability for:\r\na) To achieve KPI that was set for this procedure\r\nb) Custodian to execute and amend Inventory List and Asset Register \r\nc) Create Asset/Inventory File\r\nd) To execute the programs that have been set in this procedure\r\ne) To work with the input that available at organization hence can achieve the target that have been set.\r\nAll interested parties & employees have common responsibilities for:\r\na) Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure are Business Development Manager and Commercial Executive','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 General Manager 4<br>1.3.2 Process owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 INCOMING RECEIVING SPARES/ EQUIPMENT/ MATERIAL/ SERVICES 5<br>3.1.1 General 5<br>3.1.2 Receiving Item 5<br>3.2 SPARES/EQUIPMENT/MATERIAL/SERVICES INSPECTION AND HANDLING 6<br>3.2.1 General 6<br>3.3 ITEM DISCREPANCIES 6<br>3.3.1 General 6<br>3.4 COMMUNICATION AND NOTIFICATION 6<br>3.4.1 General 6<br>4 REVIEW AND VERIFY 6<br>5 CONTROL AND MONITORING 6<br>6 FORMS &amp; RECORDS 6<br>','https://mega.nz/#F!W75k1K5Q!Opp5U97beVRkn7-aZTrTAQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-06 21:54:12','2019-08-27 12:00:39'),(11,'6050_L3_ASW_GL1021','GUIDELINE FOR GOODS EQUIPMENT RECEIVING, HANDLING & INSPECTION','GUIDELINE FOR GOODS EQUIPMENT RECEIVING, HANDLING & INSPECTION currently not available','Quality','Guideline','00','2019-08-07',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 20:11:39','2019-08-07 20:19:19'),(12,'6050_L4_ASW_GL1022','GUIDELINE FOR GOODS EQUIPMENT RECEIVING, HANDLING & INSPECTION','GUIDELINE FOR GOODS EQUIPMENT RECEIVING, HANDLING & INSPECTION currently not available','Quality','Guideline','00','2019-08-07',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 20:18:44',NULL),(13,'6050_L2_ASW_P103','EQUIPMENT PARTS PRESERVATION, STORAGE & HANDLING','The purpose of this procedure is to define Petrogas’ s process for ensuring that equipment part preservation, Inventory and storage method and criteria are provided and maintained as required to ensure service delivery and conformity. This to ensure that company operation equipment and spares item is readily available in good working condition as well as available when required. \r\n\r\nThe procedure is applicable to all company equipment, part & consumable material available on inventory including storage facility.','Quality','Procedure','1','2019-06-01','PG/QMS/ASW/P103','1.3	Responsibilities\r\n1.3.1	Operation Manager \r\nOperation Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization.\r\nb)	Review and verify:\r\n•	Inventory List [PG/QMS/ASW/F1031]\r\n•	Asset Register [PG/QMS/ASW/F1032]\r\na)	Ensure availability of Asset/inventory file.\r\nb)	Monitor Tracking Control Chart \r\n1.3.2	Process owner \r\nProcess owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge \r\nPerson in charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Custodian and shall prepare and update:\r\n•	Inventory List [PG/QMS/ASW/F1031]\r\n•	Asset Register [PG/QMS/ASW/F1032]\r\nc)	To execute the programs that have been set in this procedure\r\nd)	To work with the input that available at organization hence can achieve the target that have been set.\r\nAll interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure are Base Manager and Jr. Project Engineer.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 Operation Manager 4<br>1.3.2 Process owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 EQUIPMENT STORAGE AND PRESERVATION 5<br>3.1.1 Storage 5<br>3.1.2 Preservation 5<br>3.2 ASSET REGISTER &amp; INVENTORY 6<br>3.2.1 General 6<br>3.2.2 Inventory and Asset Listing 6<br>3.2.3 Inventory and Asset Control 6<br>3.2.4 Inventory &amp; Asset Updating 6<br>3.3 COMMUNICATION OF INVENTORY AND ASSET REGISTER STATUS 7<br>3.3.1 General 7<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7<br>','https://mega.nz/#F!iuoWDQAY!ZS91-u5KDQXltJjwfUHgkQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 20:23:54','2019-08-27 12:01:44'),(14,'6050_L3_ASW_GL1031','GUIDELINE FOR EQUIPMENT PARTS PRESERVATION, STORAGE & HANDLING','GUIDELINE FOR EQUIPMENT PARTS PRESERVATION, STORAGE & HANDLING currently not available .','Quality','Guideline','00','2019-08-07',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 23:08:41',NULL),(15,'6050_L4_ASW_F1031','INVENTORY LIST','INVENTORY LIST','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 23:15:18',NULL),(16,'6050_L4_ASW_F1032','ASSET REGISTER','ASSET REGISTER','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 23:17:36',NULL),(17,'6050_L2_ASW_P104','CALIBRATED EQUIPMENT','The purpose of this procedure is to define Petrogas\' responsibilities and activities in order to ensure that all relevant measuring equipment used for product, service and process verification is controlled and calibrated against nationally traceable standards at specified intervals and that such devices are available to ensure continuity of measurement capability.\r\n\r\nThis procedure applies to all measuring equipment for inspection and test process required for product and process verification. There must be confidence that equipment used to inspect or measure attributes of the design is calibrated to an acceptable level of accuracy.','Quality','Forms','1','2019-06-01','PG/QMS/ASW/P104','1.3	Responsibilities\r\n1.3.1	The Quality Manager \r\nQM is required to:\r\na)	Select suitable equipment to perform the required measurements with accuracy and precision;\r\nb)	Extend the control of inspection and test equipment to all approved suppliers where applicable;\r\nc)	Ensure inspection and test equipment cannot be used if they are not registered and calibrated;\r\nd)	Ensure inspection and test equipment is calibrated in a suitable environment;\r\ne)	Control all measurement, calibration and maintenance activities.\r\n1.3.2	Technical Manager \r\nTechnical manager has the responsibility, authorities and accountable for:\r\na)	Ensuring important document are available within the organization\r\nb)	Assuring equipment is protected during handling maintenance and storage;\r\nc)	Identification of calibration status; \r\nd)	Safe guarding to preclude unauthorized adjustments;\r\ne)	 Scheduling to assure than, when necessary for valid results, equipment is calibrated or verified at specified intervals against measurement standards traceable to international or national standards, or if no standard exists, the basis for the calibration / verification is documented; \r\nf)	Activities are identified, planned, conducted and recorded; \r\ng)	Responsibilities and qualifications for persons performing activities is determined;\r\nh)	Review and verify:\r\n•	Measuring Equipment Calibration Register List [PG/QMS/ASW/F1041]\r\ni)	Ensure technician fill-up the PMS and all related documents/records.\r\nj)	Approved Requisition Order [PG/QMS/PRO/F5011] that has been raised by Procurement Department.\r\n1.3.3	Process owner \r\nProcess Owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.4	Person in-charge \r\nhas the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure.\r\nb)	To execute the programs that has been set in this procedure.\r\nc)	To work with the input that available at organization hence can achieve the target that has been set.\r\nd)	Availability of Project File.\r\n1.3.5	All interested parties & employees \r\nAll interested parties have common responsibilities for:\r\n•	Check that inspection and test equipment is not damaged and is fit for purpose;\r\n•	Check the calibration status of inspection and test equipment prior to use.\r\n•	Communicate, consult & participate in the activities stated on the procedure.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 The Quality Manager 4<br>1.3.2 Technical Manager 4<br>1.3.3 Process owner 5<br>1.3.4 Person in-charge 5<br>1.3.5 All interested parties &amp; employees 5<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>2.1 CONTROLLING CALIBRATED EQUIPMENT DETAIL CONSIDERATION 6<br>2.1.1 Existing Devices 6<br>2.1.2 New Devices 6<br>2.1.3 Calibration Frequency 6<br>2.1.4 Calibration Due Date 6<br>2.1.5 Calibration Label 7<br>2.1.6 Outsourced Calibration 7<br>2.1.7 Software 7<br>2.1.8 Non-conforming Equipment 7<br>2.1.9 Review 7<br>3 DETAIL PROCEDURE 7<br>3.1 MEASURING EQUIPMENT LISTING 7<br>3.1.1 General 7<br>3.2 EQUIPMENT CALIBRATION 8<br>3.2.1 General 8<br>3.3 INVALIDATION OF CALIBRATION 9<br>3.3.1 General 9<br>3.4 COMPARISON TO PREVIOUS RESULTS 9<br>3.4.1 General 9<br>3.5 MEASURING EQUIPMENT STORAGE AND PROTECTION 9<br>3.5.1 General 9<br>4 REVIEW AND VERIFY 10<br>5 CONTROL AND MONITORING 10<br>6 FORMS &amp; RECORDS 10<br>6.1 CALIBRATED EQUIPMENT PROCESS MAP 11<br>','https://mega.nz/#F!Ln5EFAwQ!uDgwhtLjxJS58A-1YoQxCw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 23:21:40','2019-08-27 12:02:58'),(18,'6050_L3_ASW_GL1041','GUIDELINE FOR CALIBRATED EQUIPMENT','GUIDELINE FOR CALIBRATED EQUIPMENT currently not available .','Quality','Guideline','00','2019-08-07',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 23:23:42','2019-08-27 16:33:53'),(19,'6050_L4_ASW_F1041','MEASURING EQUIPMENT CALIBRATION REGISTER LIST','MEASURING EQUIPMENT CALIBRATION REGISTER LIST','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 23:29:27',NULL),(20,'6050_L2_ASW_P105','LOGISTIC','The purpose of this procedure is to define Petrogas’ s process for ensuring that Logistic Services are provided and maintained as required to ensure Service conformity. This includes planning, provision of logistic agent and associated services.\r\n\r\nThe scope of this procedure documents Petrogas’s approach to the logistic arrangement and the use of resources to support operations and to ensure that risks associated with the provision of external logistic are adequately managed in order to minimise negative quality impacts and to reduce the risk of injury or harm to employees.','Quality','Procedure','1','2019-06-01','PG/QMS/ASW/P105','1.3	Responsibilities\r\n1.3.1	General Manager \r\nGeneral Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization (risk and opportunity register).\r\nb)	Ensuring Mobilization Notice is received from client.\r\nc)	Review and verify:\r\n•	Travel Request \r\n•	Delivery Order \r\n•	Packing List\r\n•	Competency Certificate \r\n•	Insurance Declaration \r\n•	Lifting Permit \r\n•	MTO \r\n•	Commercial Invoice \r\nd)	Prepare and custodian for Logistic Plan\r\ne)	Monitor Operation Action Plan under Logistic Section \r\n1.3.2	Process owner \r\nProcess owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge \r\nPerson in charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Custodian to prepare;\r\n•	Travel Request \r\n•	Delivery Order \r\n•	Packing List\r\n•	Competency Certificate \r\n•	Insurance Declaration \r\n•	Lifting Permit \r\n•	MTO \r\n•	Commercial Invoice \r\nc)	To execute the programs that have been set in this procedure.\r\nd)	To work with the input that available at organization hence can achieve the target that have been set.\r\nAll interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure Operation Manager.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 General Manager 4<br>1.3.2 Process owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 PRE-DELIVERY OF SPREAD 5<br>3.1.1 General 5<br>3.2 PRE LOGISTIC ACTIVITY 6<br>3.2.1 General 6<br>3.3 LOGISTIC EXECUTION 7<br>3.3.1 General 7<br>3.4 POST LOGISTIC 8<br>3.4.1 General 8<br>4 REVIEW AND VERIFY 8<br>5 CONTROL AND MONITORING 8<br>6 FORMS &amp; RECORDS 8<br>','https://mega.nz/#F!P7hC3Cbb!MC7uiHyDQqb1FaSjkh_OPw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 23:31:54','2019-08-27 12:04:10'),(21,'6050_L3_ASW_GL1051','GUIDELINE FOR LOGISTIC','GUIDELINE FOR LOGISTIC currently not available.','Quality','Guideline','00','2019-08-07',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 23:39:03',NULL),(22,'6050_L3_ASW_GL1052','GUIDELINE FOR LOGISTIC','GUIDELINE FOR LOGISTIC','Quality','Guideline','00','2019-08-07',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-07 23:40:24','2019-08-17 23:46:11'),(23,'6050_L2_BDM_P201','ORGANIZATIONAL RESOURCE PLANNING','Purpose: This procedure applies to all resource planning activity which are required through project specifications and organizational requirement. Suitable request for manpower, spread & equipment is required prior to any engagement in order to ensure the sufficiency of the organizational resources. Resources required is to be defined and maintain accordingly. \r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Manual','1','2019-06-01','PG/QMS/BDM/P201','1.3 Responsibilities\r\n1.3.1 Project Manager \r\nGeneral Manager has the responsibility, authority and accountable for:\r\na) Ensuring important document are available within the organization.\r\nb) Ensure the client satisfaction and other interested parties requirements: it is necessary for the success of the project and future projects.\r\nc) Identifying the objectives for the resource planning.\r\nd) Providing the infrastructure and resources to ensure achievement of project objectives\r\n1.3.2 Process owner\r\nProcess Owner have the responsibility for:\r\na) Designating a responsible for the improvement action once the potential causes are agreed.\r\nb) Verifying effectiveness of implementation of process flow\r\nc) Congratulating the employee that initiated implementation of process flow\r\nPerson in-charge have the responsibility, authority and accountability for:\r\na) To achieve KPI that was set for this procedure\r\nb) To execute the programs that have been set in this procedure.\r\nc) Create Project File for each project.\r\nAll interested parties & employees have common responsibilities for:\r\na) Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure is the Project Engineer.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 Project Manager 4<br>1.3.2 Process owner 4<br>1.4 OPERATION &amp; OFFSHORE SERVICE PROVISION PROCESS 4<br>2 REQUIREMENT 5<br>2.1 PROCESS CONSIDERATION AND REQUIREMENT 5<br>2.2 OPERATIONAL CONTROL PLAN 5<br>3 DETAIL PROCEDURE 6<br>3.1 INTERNAL KICK-OFF MEETING 6<br>3.2 PREPARE PROJECT PLAN 7<br>3.3 INTEGRATION 8<br>3.4 CONTROL OF SERVICE PROVISION 8<br>4 REVIEW AND VERIFY 9<br>5 CONTROL AND MONITORING 9<br>6 FORMS &amp; RECORDS 9<br>','https://mega.nz/#F!P6xklSoI!KQlcFrHa0hrnp0tefiRxqg',NULL,NULL,NULL,'50396900_1566897917.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-08 19:54:45','2019-08-27 17:25:17'),(24,'6050_L3_BDM_GL2011','GUIDELINE FOR ORGANIZATIONAL RESOURCE PLANNING','GUIDELINE FOR ORGANIZATIONAL RESOURCE PLANNING','Quality','Guideline','00','2019-08-08',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-08 19:57:55',NULL),(25,'6050_L4_BDM_F2011','ORGANIZATIONAL RESOURCE PLAN','ORGANIZATIONAL RESOURCE PLAN','Quality','Forms','01','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-08 20:01:59',NULL),(26,'6050_L2_BDM_P202','TENDER, BID, & PROPOSAL','The purpose of this procedure is to ensure that all tender, bid, market survey, and proposal interfaces among different organizational functions and groups are defined and properly managed to ensure effective communication and clear assignment of responsibility. When the project proposal and project development process is outsourced, the supplier will meet the requirements of this procedure and provide objective evidence that the requirements were met.\r\n\r\nThe design and development process is carried out under controlled conditions. All activities are planned and documented. Designs are reviewed at appropriate stages and where applicable, validated. The design and development output is verified before it is released for production.','Quality','Forms','1','2019-06-01','PG/QMS/BDM/P202','1.3 Responsibilities\r\n1.3.1 General Manager \r\nGeneral Manager has the responsibility, authority and accountable for:\r\na) Ensuring important document are available within organization:\r\n• Inquiry Register Log [PG/QMS/BDM/F2021]\r\n• Letter of Award\r\n• Letter of Intent\r\nb) Select and appoint tender committee team\r\nc) Review and verify Summary Bid Form [PG/QMS/BDM/F2021]\r\nd) Ensure availability of BDM file.\r\n1.3.2 Process owner \r\nProcess owner have the responsibility for:\r\na) Designating a responsible for the improvement action once the potential causes are agreed.\r\nb) Verifying effectiveness of implementation of process flow\r\nc) Congratulating the employee that initiated implementation of process flow\r\n1.3.3 Person in-charge \r\nPerson in charge have the responsibility, authority and accountability for:\r\na) To achieve KPI that was set for this procedure\r\nb) Custodian to issue the Summary Bid Form [PG/QMS/BDM/F2021], \r\nc) Create a BDM File.\r\nd) To execute the programs that have been set in this procedure.\r\ne) To work with the input that available at organization hence can achieve the target that have been set.\r\nAll interested parties & employees have common responsibilities for:\r\na) Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure are Business Development Manager and Commercial Executive.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 4<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 General Manager 4<br>1.3.2 Process owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>2.1 BID/ TENDER, SCREENING &amp; PROPOSAL DESIGN CONSIDERATION 5<br>2.1.1 Input 5<br>2.1.2 Activities 6<br>2.1.3 Changes 7<br>2.1.4 Tools &amp; Techniques 8<br>2.1.5 Output 8<br>2.1.6 Review 8<br>3 DETAIL PROCEDURE 8<br>3.1 CLIENT COMMUNICATION 8<br>3.1.1 Communication and Client Opportunity 8<br>3.2 BID/ SCREENING REVIEW AND TENDER ACCEPTANCE PROCESS 9<br>3.2.1 General 9<br>3.2.2 Receive Inquiry 9<br>3.2.3 Register the Tender/ Bid/ request screening 10<br>3.3 REVIEW OF REQUIREMENT FOR SERVICES 10<br>3.3.1 General 10<br>3.3.2 Client requirement 10<br>3.4 DECISION TO DECLINE INVITATION 11<br>3.4.1 General 11<br>3.4.2 Decision to decline 11<br>3.5 PREPARE TECHNICAL &amp; COMMERCIAL PROPOSAL 11<br>3.5.1 General 11<br>3.5.2 Preparation of Tender/ Proposal 11<br>4 REVIEW AND VERIFY 11<br>5 CONTROL AND MONITORING 11<br>6 Forms &amp; Records 12<br>','https://mega.nz/#F!b3wmXSIS!mLJuXbca0Bx_ksGqrxZy5g',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-08 20:07:02','2019-08-27 12:13:38'),(27,'6050_L3_BDM_GL2021','GUIDELINE FOR TENDER,BID & PROPOSAL','GUIDELINE FOR TENDER,BID & PROPOSAL currently not available .','Quality','Guideline','00','2019-08-08',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-08 20:12:13',NULL),(28,'6050_L4_BDM_F2021','INQUIRY REGISTER LOG','INQUIRY REGISTER LOG','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-08 20:14:36',NULL),(29,'6050_L4_BDM_F2022','SUMMARY BID FORM','SUMMARY BID FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-09 22:05:53',NULL),(30,'6050_L2_BDM_P203','CONTRACT REVIEW & DEPLOYMENT','The purpose of this procedure is to ensure that all tender and contract requirements together with additional requirements that are not specified but are necessary for fitness for use as per applicable legislation, regulations and requirements for availability, delivery and support are adequately defined and that the company is capable of meeting the requirements of its clients.\r\n\r\nTo assure that contracts received for processing are reviewed in a timely fashion and to determine that all requirements are adequately defined, documented, and/or agreed upon by both parties, that any differences between orders and tenders are resolved and that Petrogas has the ability and capacity to meet the contract or order requirements.','Quality','Forms','2','2019-04-01','PG/QMS/BDM/P203','1.3 Responsibilities\r\n1.3.1 BDM Manager \r\nBusiness Development Manager has the responsibility, authority and accountable for:\r\na) Ensuring important document are available within organization (Risk and Opportunity Register)\r\nb) Obtaining the necessary information and requirements from clients;\r\nc) Evaluating and adding applicable project specifications;\r\nd) Verifying ability and operation capability to meet the contract or order requirements.\r\ne) Review and verify:\r\n• Tender Register [PG/QMS/BDM/F2031]\r\n• ROV Contract Template [PG/QMS/BDM/T2031]\r\n• Vessel Contract Template [PG/QMS/BDM/T2032]\r\n• Project Proposal [PG/QMS/BDM/T2033]\r\n• Project Hand Over Form [PG/QMS/BDM/F2032]\r\nf) Ensure availability of Contract file and share folder\r\ng) Monitor Tender Register [PG/QMS/BDM/F2031] \r\n1.3.2 Operations Manager \r\nThe OM is responsible for:  \r\na) Operational planning;\r\nb) Conducting contract reviews;\r\nc) Verify client requirements are clearly documented;\r\nd) Ensuring differences between the contract or order requirements are resolved with the client;\r\ne) Generating Work Orders. \r\n1.3.3 Quality Manager \r\nThe Quality Manager is responsible for:  \r\na) Handling conflicting requirements that arise during operation;\r\nb) Resolving conflicting issues;\r\nc) Review the effectiveness of corrective actions taken.\r\n1.3.4 Process owner \r\nProcess Owner have the responsibility for:\r\na) Designating a responsible for the improvement action once the potential causes are agreed.\r\nb) Verifying effectiveness of implementation of process flow\r\nc) Congratulating the employee that initiated implementation of process flow\r\n1.3.5 Person in-charge \r\nPIC have the responsibility, authority and accountability for:\r\na) To achieve KPI that was set for this procedure\r\nb) Custodian to prepare:\r\na. Tender Register [PG/QMS/BDM/F2031]\r\nb. ROV Contract Template [PG/QMS/BDM/T2031]\r\nc. Vessel Contract Template [PG/QMS/BDM/T2032]\r\nd. Project Proposal [PG/QMS/BDM/T2033]\r\ne. Project Hand Over Form [PG/QMS/BDM/F2032]\r\nc) To execute the programs that have been set in this procedure\r\nd) To work with the input that available at organization hence can achieve the target that have been set.\r\nAll interested parties & employees have common responsibilities for:\r\na) Communicate, consult & participate in the activities stated on the procedure.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 BDM Manager 4<br>1.3.2 Operations Manager 4<br>1.3.3 Quality Manager 4<br>1.3.4 Process owner 4<br>1.3.5 Person in-charge 5<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>2.1 CONTRACT REVIEW PROCESS CONSIDERATION 6<br>2.1.1 Client Communication 6<br>2.1.2 Contract Risk Assessment 6<br>3 DETAIL PROCEDURE 7<br>3.1 CONTRACT ACCEPTANCE PROCESS 7<br>3.1.1 General 7<br>3.1.2 Receive LOI/LOA/Client Response 7<br>3.1.3 Review for any Changes to Original Specifications 7<br>3.2 CONTRACT AWARDED 1<br>3.2.1 General 1<br>3.2.2 Operational Planning 1<br>3.3 CONTRACT/ WORK ORDER REVIEW 2<br>3.3.1 General 2<br>3.4 CONTRACT AMENDMENT PROCESS 2<br>3.4.1 General 2<br>3.4.2 Receive Notification for Additional Requirement 2<br>3.4.3 Evaluate Amendments on Additional Request 2<br>3.4.4 Acceptance of Amendments 3<br>3.4.5 Submit Response to Client 3<br>3.5 CONTRACT HAND OVER MEETING 3<br>3.5.1 General 3<br>3.5.2 Contract handover meeting 3<br>3.5.3 Conflicting Requirements 3<br>4 REVIEW AND VERIFY 1<br>5 CONTROL AND MONITORING 1<br>6 FORMS &amp; RECORDS 1<br>','https://mega.nz/#F!TzhGXAZT!ht-kbNMGUUiQ_-iKPtlNxQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-09 22:08:24','2019-08-27 12:14:57'),(31,'6050_L3_BDM_GL2031','GUIDELINE FOR CONTRACT REVIEW & DEPLOYMENT','GUIDELINE FOR CONTRACT REVIEW & DEPLOYMENT  currently not available .','Quality','Guideline','00','2019-08-09',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-09 22:13:28',NULL),(32,'6050_L4_BDM_F2031','TENDER REGISTER','TENDER REGISTER','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-09 22:15:54',NULL),(33,'6050_L4_BDM_F2032','PROJECT HAND OVER FORM','PROJECT HAND OVER FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-09 22:18:18',NULL),(34,'6050_L4_BDM_F2033','PROJECT PROPOSAL','PROJECT PROPOSAL','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-09 22:20:47','2019-08-09 22:21:31'),(35,'6050_L4_BDM_F2034','CONTRACT / WORK ORDER REVIEW CHECKLIST','CONTRACT / WORK ORDER REVIEW CHECKLIST','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-09 22:24:11','2019-09-03 10:40:53'),(36,'6050_L4_BDM_T2031','ROV CONTRACT TEMPLATE','ROV CONTRACT TEMPLATE','Quality','Manual','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-09 22:26:23',NULL),(37,'6050_L4_BDM_T2032','VESSEL CONTRACT TEMPLATE','VESSEL CONTRACT TEMPLATE','Quality','Manual','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-09 22:28:08',NULL),(38,'6050_L2_HRA_P301','RECRUITMENT OF PERSONNEL','The purpose of this procedure is to define Petrogas’ s process for undertaking the necessary actions and responsibilities for ensuring that the personnel recruitment needed to meet customer and other external or internal requirements, applicable to our business, are defined and actions are taken to meet these needs. This procedure also defines the responsibilities for planning, reporting and retaining associated records.\r\n\r\nHiring is executed to improve and ensure that all personnel are suitably engaged and positioned in all aspects of their duties, responsibilities and job functions, as well as, Petrogas ’s quality management system and the requirements of ISO 9001:2015.','Quality','Manual','2','2019-04-01','PG/QMS/HRA/P301','1.3 Responsibilities, Authorities & Accountabilities\r\nThe Human Resources Manager and Line Managers are responsible for:\r\n• Ensuring important document are available within organization (risk and opportunity register)\r\n• Ensuring new staff familiar with Petrogas’s staff, environment and management system.\r\nLine Managers and Supervisors are responsible for:\r\n• Designating a responsible for the improvement action once the potential causes are agreed.\r\n• Verifying effectiveness of implementation of process flow\r\n• Congratulating the employee that initiated implementation of process flow','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENTS 4<br>3 DETAIL PROCEDURE 5<br>3.1 RECRUITING PROCESS 5<br>3.1.1 General 5<br>3.1.2 Internal sources 5<br>3.1.3 External recruiting resources 5<br>3.1.4 Exclusion 6<br>3.2 CANDIDATE SCREENING PROCESS 6<br>3.2.1 General 6<br>3.2.2 CV Selection Method 6<br>3.2.3 Interview Panel 6<br>3.2.4 Unselected Candidate 7<br>3.3 INTERVIEW PROCESS 7<br>3.3.1 General 7<br>3.3.2 Before the interview 7<br>3.3.3 During the interview 7<br>3.3.4 After the interview 7<br>3.4 POST INTERVIEW REFLECTION 8<br>3.4.1 General 8<br>3.5 HIRING DECISION 8<br>3.5.1 General 8<br>4 REVIEW AND VERIFY 9<br>5 CONTROL AND MONITORING 9<br>6 FORMS &amp; RECORDS 9<br>','https://mega.nz/#F!bm4QCSbC!fCtGHtv6ar026ccwHCq-eQ',NULL,NULL,NULL,'57562100_1566898185.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-10 15:55:27','2019-08-27 17:29:45'),(39,'6050_L3_HRA_GL3011','GUIDELINE FOR RECRUITMENT OF PERSONNEL','GUIDELINE FOR RECRUITMENT OF PERSONNEL currently not available .','Quality','Guideline','00','2019-08-10',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-10 15:58:22',NULL),(40,'6050_L4_HRS_F3011','PERSONNEL DATA FORM','PERSONNEL DATA FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-10 16:04:57',NULL),(41,'6050_L4_HRA_F3012','INTERVIEW EVALUATION FORM','INTERVIEW EVALUATION FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-10 16:07:55',NULL),(42,'6050_L2_HRA_P302','COMPETENCY & AWARENESS','The purpose of this procedure is to define Petrogas’ s process for undertaking the necessary actions and responsibilities for ensuring that the competencies needed to meet customer and other external or internal requirements, applicable to our business, are defined and actions are taken to meet these needs. This procedure also defines the responsibilities for planning, reporting and retaining associated records.\r\n\r\nTraining is given to improve and ensure that all personnel are suitably aware and competent in all aspects of their duties, responsibilities and job functions, as well as, Petrogas ’s quality management system and the requirements of ISO 9001:2015.','Quality','Procedure','1','2019-06-01','PG/QMS/HRA/P302','1.3 Responsibilities, Authorities & Accountabilities\r\nThe Human Resources Manager and Line Managers are responsible for:\r\n• Identifying training needs\r\n• Developing and implementing a training plan\r\nLine Managers and Supervisors are responsible for:\r\n• Reporting any highlighted training needs \r\n• Ensuring that employees and contractors under their control are trained to complete their tasks\r\n• Ensuring that employees are assigned only to tasks for which they are qualified to perform\r\nProcess owner have the responsibility for:\r\na) Designating a responsible for the improvement action once the potential causes are agreed.\r\nb) Verifying effectiveness of implementation of process flow\r\nc) Congratulating the employee that initiated implementation of process flow\r\nPerson in-charge have the responsibility, authority and accountability for:\r\na) To achieve KPI that was set for this procedure\r\nb) Ensuring all new staff/contract staff attend the induction and familiarization. (ROV, Management System, Rules and regulations)\r\nc) Ensuring all staff competent to execute their task and job scope.\r\nd) To execute the programs that have been set in this procedure\r\ne) To work with the input that available at organization hence can achieve the target that have been set.\r\nAll interested parties & employees have common responsibilities for:\r\na) Communicate, consult & participate in the activities stated on the procedure.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 AWARENESS PROCESS 5<br>3.1.1 General 5<br>3.1.2 Internal Awareness Program 5<br>3.2 COMPETENCY 6<br>3.2.1 Training Plan and Objectives 6<br>3.2.2 Provide a Process for Competency Development 6<br>3.2.3 Follow-up to Ensure the Competency was learned 0<br>3.3 COMPETENCY AND SKILL ENHANCEMENT 0<br>3.3.1 Competency Plan and Objectives 0<br>4 REVIEW AND VERIFY 0<br>5 CONTROL AND MONITORING 0<br>6 FORMS &amp; RECORDS 1<br>','https://mega.nz/#F!qugimQCZ!K8Cd_R6EN-D_HaXiamNviA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-10 21:45:17','2019-08-27 12:17:39'),(43,'6050_L3_HRA_GL3021','GUIDELINE FOR COMPETENCY & AWARENESS','GUIDELINE FOR COMPETENCY & AWARENESS  currently not available .','Quality','Guideline','00','2019-08-10',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-10 21:47:18',NULL),(44,'6050_L4_HRA_F3021','COMPETENCY MATRIX','COMPETENCY MATRIX','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-10 21:49:01',NULL),(45,'6050_L2_HRA_P303','TRAINING AND DEVELOPMENT','The purpose of this procedure is to define Petrogas’ s process for undertaking the necessary actions and responsibilities for ensuring that the training and development needed to meet customer and other external or internal requirements, applicable to our business, are defined and actions are taken to meet these needs. This procedure also defines the responsibilities for planning, reporting and retaining associated records.\r\n\r\nTraining is given to improve and ensure that all personnel are suitably aware and trained in all aspects of their duties, responsibilities and job functions, as well as, Petrogas’s quality management system and the requirements of ISO 9001:2015.','Quality','Procedure','2','2019-04-01','PG/QMS/HRA/P303','1.3 Responsibilities, Authorities & Accountabilities\r\nThe Human Resources Manager and Line Managers are responsible for:\r\n• Identifying training needs\r\n• Developing and implementing a training plan\r\nLine Managers and Supervisors are responsible for:\r\n• Reporting any highlighted training needs \r\n• Ensuring that employees and contractors under their control are trained to complete their tasks\r\n• Ensuring that employees are assigned only to tasks for which they are qualified to perform','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENTS 4<br>3 DETAIL PROCEDURE 5<br>3.1 IDENTIFY TRAINING REQUIRED 5<br>3.1.1 Training Plan and Objectives 5<br>3.1.2 Training Needs Assessment 5<br>3.2 DEVELOP TRAINING PLAN 5<br>3.2.1 Development of Skills 5<br>3.3 CONDUCT TRAINING &amp; FEEDBACK ANALYSIS 5<br>3.3.1 Management System Training 5<br>3.3.2 On-the-Job Training 6<br>3.4 ASSESSING TRAINING EFFECTIVENESS 6<br>3.4.1 Performance Review 6<br>3.4.2 Training Evaluation 6<br>3.4.3 Review 6<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7</div><div>&#8195;<br></div>','https://mega.nz/#F!DrhkiYIR!56oO9T1sAcZr7Yo6NbuaIQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 20:19:38','2019-08-27 12:18:32'),(46,'6050_L3_HRA_GL3031','GUIDELINE FOR TRAINING & DEVELOPMENT','GUIDELINE FOR TRAINING & DEVELOPMENT currently not available .','Quality','Guideline','00','2019-08-11',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 20:21:39',NULL),(47,'6050_L4_HRA_F3031','TRAINING NEED ANALYSIS','TRAINING NEED ANALYSIS','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 20:23:40',NULL),(48,'6050_L4_HRA_F3032','TRAINING MATRIX','TRAINING MATRIX','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 20:24:56',NULL),(49,'6050_L4_HRA_F3033','TRAINING EVALUATION','TRAINING EVALUATION','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 20:26:21',NULL),(50,'6050_L2_HRA_P304','ORGANIZATIONAL KNOWLEDGE','The purpose of this procedure is to ensure that all relevant organizational knowledge which forms an integral part of our quality management system is managed under controlled conditions and that all documented information is reviewed and approved by authorized personnel prior to internal sharing. \r\n\r\nPurpose: The procedure is to ensure organization knowledge are effectively determined, documented where possible and shared/ communicated to the target group or relevant staff to enhance the staff competency and organisation performance and to prevent loss of knowledge following senior staff retirement or staff turnover/ resignation.\r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Policy','2','2019-04-01','PG/QMS/HRA/P304','1.3	Responsibilities, Authorities & Accountabilities\r\nQHSE Manager has the responsibility, authority and accountable for:\r\nEnsuring important document are available within organization (analysis of business plan, analysis of technology and competitors, economic reports from relevant business sector and technical reports from technical experts and consultant)\r\nProcess owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow.\r\nc)	Congratulating the employee that initiated implementation of process flow\r\nPerson in-charge has the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure.\r\nb)	Review and verify respective Business Plan Analysis.\r\nc)	To execute the programs that has been set in this procedure.\r\nd)	To work with the input that available at organization hence can achieve the target that has been set.\r\nAll interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owners of this procedure are Quality Management Representative and Quality Executive.\r\nThe performance indicator was set to meet organization objective through the implementation of Leading and Lagging Indicator [PG/QMS/QAC/F6125].','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 DETERMINE AND ASSESS THE KNOWLEDGE 5<br>3.1.1 General 5<br>3.1.2 Sources of Organization Knowledge 5<br>3.1.3 Determine internal and external source of knowledge 5<br>3.2 CAPTURING THE KNOWLEDGE 6<br>3.2.1 Capturing the Knowledge 6<br>3.3 SHARING/ IMPARTING THE KNOWLEDGE 7<br>3.3.1 General 7<br>3.3.2 Communication 7<br>3.4 SHARING/ IMPARTING THE KNOWLEDGE 7<br>3.4.1 General 7<br>4 REVIEW AND VERIFY 8<br>5 CONTROL AND MONITORING 8<br>6 FORMS &amp; RECORDS 8</div><div>&#8195;<br></div>','https://mega.nz/#F!63pAwALb!9yXSxtn636kX7gx0-DAiMw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 20:28:36','2019-08-27 12:19:27'),(51,'6050_L3_HRA_GL3041','COACHING & MENTORING GUIDELINE','COACHING & MENTORING GUIDELINE','Quality','Guideline','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 20:31:06',NULL),(52,'6050_L3_HRA_GL3042','BENCHMARKING GUIDELINE','BENCHMARKING GUIDELINE','Quality','Guideline','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 20:33:05',NULL),(53,'6050_L4_HRA_F3041','MENTORING & COACHING AGREEMENT','MENTORING & COACHING AGREEMENT','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 20:34:33',NULL),(54,'6050_L2_OPN_P405','PROJECT DELIVERY & COMPLETION','The purpose of this procedure is to define the activities required to ensure that all elements of the deliverables and service provision process are delivered and completed under control conditions to further ensure conformity to client or other specified requirements. \r\n\r\nPurpose: This procedure applies to all offshore service provision processes which are controlled through project specifications and work instructions. Suitable spread & equipment is used and properly maintained with the use of specified measuring and monitoring equipment and activities. Project release and post-delivery and delivery processes are defined. \r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Policy','1','2019-06-01','PG/QMS/QAC/P405','1.3	Responsibilities\r\n1.3.1	Project Manager \r\nProcess Manager have the responsibility, authorities and accountable for:\r\na)	Ensuring important document are available within the organization.\r\nb)	Ensure Client Satisfaction Form [PG/QMS/QAC/F6101] was filled by the Client.\r\nc)	Review and verify Job Completion Certificate [PG/QMS/OPN/F4032] and Project Close Out Report.\r\nd)	Monitor QA Launch Matrix.\r\ne)	Ensure availability of Project File.\r\nf)	Review and verify the Tracking Control Chart and Operation Action Plan [PG/QMS/OPN/F4013].\r\n1.3.2	Process owner \r\nProcess Owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge \r\nhave the responsibility, authority and accountability for:\r\na)	To achieve PGI that was set for this procedure.\r\nb)	Availability of Project Completion Certificate [PG/QMS/OPN/F4032] and Project Close Out Report. To work with the input that available at organization hence can achieve the target that have been set.\r\nc)	Availability of Project File.\r\nAll interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure are Project Engineer.','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 Project Manager 4<br>1.3.2 Process owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 IDENTIFICATION &amp; TRACEABILITY 5<br>3.1.1 Offshore Project Identification 5<br>3.1.2 Traceability of Client Supplied Material or Equipment 6<br>3.1.3 Offshore Project Delivery 6<br>3.2 PRESERVATION OF OFFSHORE PROJECT DELIVERABLES 6<br>3.2.1 Handling 6<br>3.2.2 Storage &amp; Preservation 6<br>3.2.3 Packaging 7<br>3.2.4 Delivery 7<br>4 REVIEW AND VERIFY 8<br>5 CONTROL AND MONITORING 8<br>6 FORMS &amp; RECORDS 8</div><div>&#8195;<br></div>','https://mega.nz/#F!K35CASDI!opcS8lNNuO9N2x9AirJWyg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 21:01:31','2019-08-27 12:25:04'),(55,'6050_L3_OPN_GL4051','GUIDELINE FOR PROJECT DELIVERY & COMPLETION','GUIDELINE FOR PROJECT DELIVERY & COMPLETION ( currently not available )','Quality','Guideline','00','2019-08-11',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 21:03:42',NULL),(56,'6050_L4_OPN_F4051','FORM FOR PROJECT DELIVERY & COMPLETION','FORM FOR PROJECT DELIVERY & COMPLETION','Quality','Forms','00','2019-08-11',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 21:06:17',NULL),(57,'6050_L2_OPN_P406','PROJECT CONTROL OF CHANGES','The purpose of this procedure is to ensure that all relevant project variation order/ change order which forms an integral part of our quality management system is managed under controlled conditions and that all documented information is reviewed and approved by authorized personnel prior to internal sharing. \r\n\r\nPurpose: The procedure is to ensure Project change order/variation order request are effectively determined, documented where possible and shared/ communicated to the target group or relevant staff to increase the awareness of project management team and project performance and to prevent loss of revenue due to lack of documentation.\r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Policy','1','2019-06-01','PG/QMS/OPN/P406','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	Project Manager \r\nhave the responsibility, authorities and accountable for:\r\na)	Ensuring important document are available within the organization.\r\nb)	Review and verify Variation Order Form [PG/QMS/OPN/F4061]\r\n1.3.2	Process owner \r\nhave the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge \r\nhave the responsibility, authority and accountability for:\r\na)	To achieve PGI that was set for this procedure\r\nb)	Ensure Variation Order Form [PG/QMS/OPN/F4061] has been filled.\r\nc)	To execute the programs that have been set in this procedure\r\nd)	To work with the input that available at organization hence can achieve the target that have been set.\r\ne)	Availability of Project File.\r\nAll interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure are Project Engineer.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.3.1 Project Manager 4<br>1.3.2 Process owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENTS 5<br>2.1 OPERATIONAL CONSIDERATION 5<br>3 DETAIL PROCEDURE 5<br>3.1 DETERMINE AND ASSESS THE KNOWLEDGE 5<br>3.1.1 General 5<br>3.1.2 Variation Order Request (Change Order request) 5<br>3.2 SUBMISSION OF VARIATION ORDER REQUEST TO CLIENT 6<br>3.2.1 Approval 6<br>3.3 SHARING/ EXECUTE THE VARIATION ORDER/ CHANGE ORDER 6<br>3.3.1 General 6<br>3.3.2 Communication 6<br>4 REVIEW AND VERIFY 6<br>5 CONTROL AND MONITORING 6<br>6 FORMS &amp; RECORDS 7<br>','https://mega.nz/#F!uqpk0KoB!cI6MfpBs2fHrf5MN5tztAw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 21:09:45','2019-08-27 12:26:00'),(58,'6050_L3_OPN_GL4061','GUIDELINE FOR PROJECT CONTROL OF CHANGES','GUIDELINE FOR PROJECT CONTROL OF CHANGES  ( currently not available )','Quality','Policy','00','2019-08-11',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 21:12:14',NULL),(59,'6050_L4_OPN_F4061','VARIATION ORDER','VARIATION ORDER','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 21:14:33',NULL),(60,'6050_L2_OPN_P407','PROJECT CLAIM & INVOICING','The purpose of this procedure is to ensure that all relevant project claim and invoicing which forms an integral part of our quality management system is managed under controlled conditions and that all documented information is reviewed and approved by authorized personnel prior to external dissemination. \r\n\r\nPurpose: The procedure is to ensure project claim records and invoices are effectively determined, documented where possible and shared/ communicated to the target group or relevant staff to ensure the payment milestone is achieved and to prevent delay of payment. \r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Procedure','1','2019-06-01','PG/QMS/OPN/P407','1.3 Responsibilities, Authorities & Accountabilities\r\n1.3.1 Project Manager \r\nProject manager have the responsibility, authorities and accountable for:\r\na) Ensuring important document are available within the organization.\r\nb) Review and verify Service Order, Invoice) and Project File.\r\n1.3.2 Process owner \r\nProcess Owner have the responsibility for:\r\na) Designating a responsible for the improvement action once the potential causes are agreed.\r\nb) Verifying effectiveness of implementation of process flow\r\nc) Congratulating the employee that initiated implementation of process flow\r\n1.3.3 Person in-charge \r\nPerson in-charge have the responsibility, authority and accountability for:\r\na) To achieve KPI that was set for this procedure\r\nb) Ensure Service Order and Invoice has been filled.\r\nc) Ensure supporting document available for claiming process (DPR, Timesheet, PO, Quotation, and Invoice)\r\nd) To execute the programs that have been set in this procedure\r\ne) To work with the input that available at organization hence can achieve the target that have been set.\r\nf) Availability of Project File.\r\nAll interested parties & employees have common responsibilities for:\r\na) Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure are Project Engineer.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.3.1 Project Manager 4<br>1.3.2 Process owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 VERIFICATION OF WORK DONE 5<br>3.1.1 General 5<br>3.1.2 Sources of Work Done 5<br>3.2 PREPARING THE CLAIM CERTIFICATE 5<br>3.2.1 Capturing the Knowledge 5<br>3.3 INVOICE AND CLAIM DISSEMINATION 6<br>3.3.1 General 6<br>3.3.2 Dissemination 6<br>3.4 INVOICE PROVE OF ACCEPTANCE 6<br>3.4.1 General 6<br>4 REVIEW AND VERIFY 6<br>5 CONTROL AND MONITORING 6<br>6 FORMS &amp; RECORDS 7<br>','https://mega.nz/#F!yy5AiKrS!17LKMV2evTZUDz0q9BJJxA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 21:16:46','2019-08-27 12:27:14'),(61,'6050_L3_OPN_GL4071','GUIDELINE FOR PROJECT CLAIM & INVOICING','GUIDELINE FOR PROJECT CLAIM & INVOICING ( currently not available )','Quality','Guideline','00','2019-08-11',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 21:18:42',NULL),(62,'6050_L2_OPN_P408','CONTROL OF CLIENT PROPERTY','The purpose of this procedure is to ensure that all relevant control of client property method and criteria which forms an integral part of our quality management system is managed under controlled conditions and that all documented information is reviewed and approved by authorized personnel prior to internal sharing. \r\n\r\nPurpose: The procedure is to ensure method and criteria for the control of client property are effectively determined, established, documented where possible and shared/ communicated to the target group or relevant staff to enhance the staff competency and organisation performance and to prevent loss revenue due to damage of client property. \r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Procedure','2','2019-04-01','PG/QMS/OPN/P408','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	Project Manager \r\nPM has responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization (risk and opportunity register)\r\nb)	Review and verify e.g.:\r\n•	Safety Walkabout \r\n•	Project Audit\r\n•	Hygiene at Worksite Form \r\nc)	Ensuring all offshore project personnel follow the rules and regulations that have been set at worksite.\r\nd)	Ensuring delivering of project output have been submitted in timely manner e.g.:\r\n•	Transmittal Note \r\n•	CD Hand Over Form\r\n•	DPR \r\n•	Dive Log \r\n•	Timesheet \r\n1.3.2	Process owner \r\nProcess owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge \r\nPIC have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Custodian to execute project audit at worksite\r\ne)	Ensuring delivering of project output have been submitted in timely manner e.g.:\r\n•	Transmittal Note \r\n•	CD Hand Over Form\r\n•	DPR \r\n•	Dive Log\r\n•	Timesheet \r\nc)	To execute the programs that have been set in this procedure\r\nd)	To work with the input that available at organization hence can achieve the target that have been set.\r\nAll interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure are Project Executive.\r\nThe performance indicator for this procedure is no damages to client property and belongings.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.3.1 Project Manager 4<br>1.3.2 Process owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 CONTROL OF CLIENT PROPERTY 5<br>3.1.1 Marking, Storage, &amp; Handling 6<br>3.1.2 Loss or Damage 6<br>3.1.3 Client Property 6<br>3.2 CONTROL OF CLIENT WORKSITE 7<br>3.2.1 General 7<br>3.2.2 Identification of Worksite Element 7<br>3.3 CONTROL OF CLIENT EQUIPMENT AND SERVICES 7<br>3.3.1 General 7<br>3.3.2 Client Facilities 7<br>4 REVIEW AND VERIFY 8<br>5 CONTROL AND MONITORING 8<br>6 FORMS &amp; RECORDS 8<br>','https://mega.nz/#F!Ly40ECzL!wf4dyXz1RKjwjG88y23ukg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 22:33:15','2019-08-27 12:28:06'),(63,'6050_L3_OPN_GL 4081','GUIDELINE FOR CONTROL OF CLIENT PROPERTY','GUIDELINE FOR CONTROL OF CLIENT PROPERTY','Quality','Guideline','00','2019-08-11',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 22:34:42','2019-08-17 23:45:31'),(64,'6050_L4_OPN_F4081','FORM FOR CONTROL OF CLIENT PROPERTY','FORM FOR CONTROL OF CLIENT PROPERTY ( currently not available )','Quality','Forms','00','2019-08-11',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 22:36:27',NULL),(65,'6050_L2_OPN_P401','PROJECT INITIATION','The purpose of this procedure is to define the activities required to ensure that all elements of the production and service provision process are planned and conducted under control conditions to further ensure conformity to client or other specified requirements. \r\n\r\nPurpose: This procedure applies to all offshore service provision processes which are controlled through project specifications and Contract Requirement. Suitable spread & equipment is used and properly maintained with the use of specified measuring and monitoring equipment and activities. Project release and post-delivery and delivery processes are defined. \r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Procedure','2','2019-04-01','PG/QMS/OPN/P401','1.3 Responsibilities\r\n1.3.1 Project Manager\r\nProject Manager have the responsibility, authorities and accountable for:\r\na) Ensuring important document are available within the organization\r\nb) Ensure the client satisfaction and other interested parties requirements: it is necessary for the success of the project and future projects.\r\nc) Selection of Project Management Team and person-in-charge of the project.\r\nd) Verify the Contract/Work Order Review Checklist and Minutes of Meeting.\r\ne) Review and verify the Project Charter [PG/QMS/OPN/F4011] that have been prepare by Project Engineer.\r\n1.3.2 Process Owner\r\nProcess owner have the responsibility for:\r\na) Designating a responsible for the improvement action once the potential causes are agreed.\r\nb) Verifying effectiveness of implementation of process flow\r\nc) Congratulating the employee that initiated implementation of process flow\r\n1.3.3 Person in-charge \r\nPIC have the responsibility, authority and accountability for:\r\na) To achieve KPI that was set for this procedure\r\nb) Review and verify respective Project Charter [PG/QMS/OPN/F4011]\r\nc) To execute the programs that have been set in this procedure\r\nd) To work with the input that available at organization hence can achieve the target that have been set.\r\ne) Availability of Project File.\r\nAll interested parties & employees have common responsibilities for:\r\na) Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure is the Project Engineer.\r\nThe performance indicator for this procedure is 100% project charter issuance on project.','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 Project Manager 4<br>1.3.2 Process Owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 REQUIREMENT AND DETAIL DATA COLLECTION 5<br>3.1.1 Project Initiation Meeting 5<br>3.1.2 Prepare Project Action Plan 6<br>3.1.3 Prepare Project Charter 6<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 8</div><div>&#8195;<br></div>','https://mega.nz/#F!L6xiVSgQ!V878F0Fnx-uQ7OQ69UdUMA',NULL,NULL,NULL,'26057200_1566898567.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 22:39:40','2019-08-27 17:36:20'),(66,'6050_L3_OPN_GL4011','GUIDELINE FOR PROJECT INITIATION','GUIDELINE FOR PROJECT INITIATION  (currently not available )','Quality','Guideline','00','2019-08-11',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-11 22:42:35',NULL),(67,'6050_L4_OPN_F4011','PROJECT CHARTER','PROJECT CHARTER','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:18:20',NULL),(68,'6050_L4_OPN_F4012','PROJECT OPENING FORM','PROJECT OPENING FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:20:09',NULL),(69,'6050_L4_OPN_F4013','PROJECT ACTION PLAN','PROJECT ACTION PLAN','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:21:26',NULL),(70,'6050_L2_OPN_P402','PROJECT PLANNING','The purpose of this procedure is to define the activities required to ensure that all elements of the production and service provision process are planned and conducted under control conditions to further ensure conformity to client or other specified requirements. \r\n\r\nPurpose: This procedure applies to all offshore service provision processes which are controlled through project specifications and work instructions. Suitable spread & equipment is used and properly maintained with the use of specified measuring and monitoring equipment and activities. Project release and post-delivery and delivery processes are defined. \r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Procedure','1','2019-06-01','PG/QMS/QAC/P402','1.3	Responsibilities\r\n1.3.1	Project Manager \r\nProject Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within the organization.\r\nb)	Ensure the client satisfaction and other interested parties requirements: it is necessary for the success of the project and future projects.\r\nc)	Identifying the objectives for the project.\r\nd)	Providing the infrastructure and resources to ensure achievement of project objectives\r\ne)	Project Manager shall ensure the availability of Project Management Plan [PG/QMS/QAC/GL4021] and shall assign Quality Executive to establish Project Leading and Lagging Indicator [PG/QMS/QAC/F6152].\r\nf)	Verify the Client Satisfaction Chain and Minutes of Meeting [PG/QMS/QAC/F6161].\r\ng)	Review and verify Project Action Plan [PG/QMS/OPN/F4013], Project ERP and approve Request Order [PG/QMS/PRO/F5011].\r\nh)	Review and verify Project Action Plan [PG/QMS/QAC/F4013], Operation Budget List, Planned Profit and Lost, Operational Matrix and Crew Matrix.\r\ni)	Ensuring availability of Project File.\r\n1.3.2	Process owner\r\nProcess Owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\nd)	Person in-charge have the responsibility, authority and accountability for:\r\ne)	To achieve PGI that was set for this procedure\r\nf)	To execute the programs that have been set in this procedure.\r\ng)	Custodian for Project Action Plan [PG/QMS/OPN/F4013].\r\nh)	Coordinate the project team to execute the program based on Project Action Plan [PG/QMS/OPN/F4013].\r\ni)	Monitor the project Profit and Lost.\r\nj)	Create Project File for each project.\r\nAll interested parties & employees have common responsibilities for:\r\nCommunicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure are Project Engineer.\r\nThe performance indicator was set that project planning record to be compiled as completed and tracked on Project Action Plan [PG/QMS/OPN/F4013].','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 Project Manager 4<br>1.3.2 Process owner 4<br>1.4 OPERATION &amp; OFFSHORE SERVICE PROVISION PROCESS 5<br>2 REQUIREMENT 5<br>2.1 PROCESS CONSIDERATION AND REQUIREMENT 5<br>2.2 OPERATIONAL CONTROL PLAN 6<br>3 DETAIL PROCEDURE 6<br>3.1 INTERNAL KICK-OFF MEETING 6<br>3.2 PREPARE PROJECT PLAN 7<br>3.3 INTEGRATION 8<br>3.4 CONTROL OF SERVICE PROVISION 8<br>4 REVIEW AND VERIFY 8<br>5 CONTROL AND MONITORING 9<br>6 FORMS &amp; RECORDS 9</div><div>&#8195;<br></div>','https://mega.nz/#F!vj4iBAIa!43cqGTbvNkjuuTqlWTwEqQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:23:57','2019-08-27 12:21:46'),(71,'6050_L3_OPN_GL4021','PROJECT MANAGEMENT PLAN','PROJECT MANAGEMENT PLAN','Quality','Guideline','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:25:25',NULL),(72,'6050_L4_OPN_F4021','FORM FOR PROJECT MANAGEMENT PLAN','FORM FOR PROJECT MANAGEMENT PLAN ( currently not available )','Quality','Guideline','00','2019-08-13',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:27:15','2019-09-04 20:37:01'),(73,'6050_L2_OPN_P403','PROJECT EXECUTION','The purpose of this procedure is to define the activities required to ensure that all elements of the production and service provision process are planned and conducted under control conditions to further ensure conformity to client or other specified requirements. \r\n\r\nPurpose: This procedure applies to all offshore service provision processes which are controlled through project specifications and work instructions. Suitable spread & equipment is used and properly maintained with the use of specified measuring and monitoring equipment and activities. Project release and post-delivery and delivery processes are defined. \r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Policy','1','2019-06-01','PG/QMS/QAC/P403','1.3 Responsibilities\r\n1.3.1 Project Manager \r\nProject Manager has the responsibility, authority and accountable for:\r\na) Ensuring important document are available within the organization \r\n• Project QHSE Plan \r\n• Project Resources Plan \r\n• Project Logistic Plan \r\n• Project Communication Plan\r\n• Project ERP \r\n• Addressing Risk and Opportunities (FMEA, HIRADC and EIA) \r\n• Project Execution Plan\r\n• Project Detail Plan \r\n• Project Cost Control Plan \r\nb) Ensure the client satisfaction and other interested parties requirements: it is necessary for the success of the project and future projects.\r\nc) Identifying the objectives for the project.\r\nd) Ensure availability and verify Project File, Daily Progress Report, Breakdown Notification, EFR, Timesheet, Variation Order [PG/QMS/OPN/F4061], PMS, Inventory Critical Spare List, Incident/Event Notification, Management of Change Form [PG/QMS/QHSE/F6061], Utilization Form, Requisition Order [PG/QMS/PRO/F5011] and Service Agreement.\r\n1.3.2 Process Owner \r\nProcess Owner have the responsibility for:\r\nDesignating a responsible for the improvement action once the potential causes are agreed.\r\nVerifying effectiveness of implementation of process flow\r\nCongratulating the employee that initiated implementation of process flow\r\n1.3.3 Person in-charge \r\nPerson In-Charge have the responsibility, authority and accountability for:\r\na) To achieve PGI that was set for this procedure\r\nb) To execute the programs that has been set in this procedure.\r\nc) Check availability of Project File, Daily Progress Report, Breakdown Notification, EFR, Timesheet, Variation Order [PG/QMS/OPN/F4061], PMS, Inventory Critical Spare List, Incident/Event Notification, Management of Change Form [PG/QMS/QHSE/F6061], Utilization Form, Requisition Order [PG/QMS/PRO/F5011] and Service Agreement.\r\nd) Monitor the Quality Assurance Launch Matrix, Tracking Control Chart and Project Leading and Lagging Indicator [PG/QMS/QAC/F6125].\r\ne) Custodian for Project Action Plan [PG/QMS/OPN/F4013].\r\nf) Coordinate the project team to execute the program based on Project Action Plan [PG/QMS/OPN/F4013].\r\ng) Monitor the project Profit and Lost.\r\nh) Create Project File for each project.\r\nAll interested parties & employees have common responsibilities for:\r\nCommunicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure is Project Engineer.\r\nThe performance indicator was set that project planning record to be compiled as completed and tracked on Project Action Plan [PG/QMS/OPN/F4013].','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 Project Manager 4<br>1.3.2 Process Owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>2.1 PROCESS CONSIDERATION 6<br>2.2 OPERATION EXECUTION 6<br>3 DETAIL PROCEDURE 6<br>3.1 PROJECT MOBILIZATION 6<br>3.1.1 Instruction of Mobilization 6<br>3.1.2 Execution of Mobilization 6<br>3.1.3 Completion of Mobilization 7<br>3.2 PROJECT OPERATION 7<br>3.3 DEMOBILIZATION 8<br>3.3.1 Instruction of Demobilization 8<br>3.3.2 Execution of Demobilization 8<br>3.3.3 Completion of Demobilization 8<br>4 REVIEW AND VERIFY 8<br>5 CONTROL AND MONITORING 8<br>6 FORMS &amp; RECORDS 9<br>','https://mega.nz/#F!2ihSnKTZ!bc927NvoAGUduS7xWQf2Eg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:33:35','2019-08-27 12:23:02'),(74,'6050_L3_OPN_GL4031','GUIDELINE FOR PROJECT EXECUTION','GUIDELINE FOR PROJECT EXECUTION ( currently not available )','Quality','Guideline','00','2019-08-13',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:35:07',NULL),(75,'6050_L4_OPN_F4031','PROJECT ON-HIRE CERTIFICATE','PROJECT ON-HIRE CERTIFICATE','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:41:07','2019-09-04 20:34:01'),(76,'6050_L4_OPN_F4032','JOB COMPLETION CERTIFICATE','JOB COMPLETION CERTIFICATE','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:43:26','2019-09-04 20:35:00'),(77,'6050_L2_OPN_P404','PROJECT CONTROL & MONITORING','The purpose of this procedure is to establish and define the process for testing and inspection activities that verify deliverables, material and service conformance, and to verify that process inputs and outputs conform to specified requirements. \r\n\r\nYour organization has implemented a process that includes all appropriate; methods, techniques, formats, etc. to monitor and measure the characteristics of products and services to verify that requirements are being met. This procedure is applicable to all incoming item, equipment, materials, and in-process testing and final articles. \r\n\r\nMaterials, components, subassemblies and finished products are prevented from use, assembly and dispatch until the required inspections are completed. When products are modified, they are fully re-inspected and re-tested. The required records of inspections and tests are established and maintained.','Quality','Procedure','1','2019-06-01','PG/QMS/OPN/P404','1.3	Responsibilities\r\n1.3.1	Top management\r\nTop management, each relevant department managers are responsible for:\r\n•	Ensuring that planned arrangements are satisfactorily completed prior to release.\r\n1.3.2	Quality Manager\r\nQuality Manager is required to:\r\n•	Determine the extent and scope of in-process inspection and testing;\r\n•	Determine the extent and scope of product inspection and testing;\r\n•	Ensure that this procedure is implemented.\r\n1.3.3	Quality Inspection \r\nThe Quality Inspection personnel are required to:\r\n•	Undertake inspection and testing in accordance with specified requirements;\r\n•	Preserve the identification of inspected and testing products.\r\n1.3.4	Project Manager \r\nProject Manager have the responsibility, authorities and accountable for:\r\n•	Ensuring important document are available within the organization.\r\n•	Monitor the client satisfaction and other interested parties requirements: it is necessary for the success of the project and future projects.\r\n•	Monitor Project Leading and Lagging Indicator [PG/QMS/OPN/F6152]\r\n•	Review the QA Launch Matrix\r\n•	Review and verify Project Control and Monitoring Chart \r\n1.3.5	Process owner \r\nProcess Owner have the responsibility for:\r\n•	Designating a responsible for the improvement action once the potential causes are agreed.\r\n•	Verifying effectiveness of implementation of process flow\r\n•	Congratulating the employee that initiated implementation of process flow\r\nPerson in-charge have the responsibility, authority and accountability for:\r\n•	To achieve PGI that was set for this procedure\r\n•	Ensure availability of Project Leading Lagging Indicator [PG/QMS/OPN/F6152]\r\n•	To execute the programs that have been set in this procedure\r\n•	To work with the input that available at organization hence can achieve the target that have been set.\r\n•	Availability of Project File.\r\nAll interested parties & employees have common responsibilities for:\r\n•	Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure are Project Engineer.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.3.1 Top management 4<br>1.3.2 Quality Manager 4<br>1.3.3 Quality Inspection 4<br>1.3.4 Project Manager 4<br>1.3.5 Process owner 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 PROCESS VALIDATION 5<br>3.1.1 Definitions 6<br>3.1.2 Offshore Project &amp; Process Validation Planning 6<br>3.1.3 When Process Validation is Required 6<br>3.1.4 When Process Validation is Recommended 7<br>3.1.5 Retrospective Validation 7<br>3.1.6 Prospective Validation 7<br>3.1.7 Revalidation 7<br>3.2 TESTING &amp; INSPECTION PROCESS 7<br>3.2.1 Receiving Inspection 7<br>3.2.2 First Article Inspection 8<br>3.2.3 In-process Inspection 8<br>3.2.4 Final Inspection 9<br>3.2.5 Nonconformities 9<br>4 REVIEW AND VERIFY 9<br>5 CONTROL AND MONITORING 9<br>6 FORMS &amp; RECORDS 10<br>','https://mega.nz/#F!mm5SWQQC!6TVxD5Gyj1Pvjd--Qt1BaQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:46:48','2019-08-27 12:23:58'),(78,'6050_L3_OPN_GL4041','GUIDELINE FOR PROJECT CONTROL & MONITORING','GUIDELINE FOR PROJECT CONTROL & MONITORING ( currently not available )','Quality','Guideline','00','2019-08-13',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 20:49:52',NULL),(79,'6050_L3_OPN_GL4042','GUIDELINE FOR PROJECT CONTROL & MONITORING','GUIDELINE FOR PROJECT CONTROL & MONITORING','Quality','Guideline','00','2019-08-13',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-13 21:00:21','2019-08-17 23:44:47'),(80,'6050_L2_PRO_P501','PURCHASING & PROCUREMENT','The purpose of this procedure is to define the activities required to ensure that purchased products conform to the specified purchase requirements, by detailing the combination of supplier controls, purchasing requirements and purchased product inspection taking into account the potential consequences of a non-conforming product being delivered.\r\n\r\nPurpose: This procedure applies to the evaluation and monitoring of suppliers supplying materials, components, parts, and sub-assemblies that are incorporated into final products. Also included are suppliers of associated services that may affect product quality, such as design, delivery and calibration of measuring equipment, etc. \r\nThis procedure also applies to all inspecting, testing and checking activities to verify that products and materials conform to specified requirements. Exclusion: The procurement of office supplies, stationery, sundries and janitorial services are excluded from this requirement, as are repair and replacement parts, etc.\r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Procedure','2','2019-04-01','PG/QMS/PRO/P501','1.3 Responsibilities\r\nAll Purchasing and Buying staff & Process Owners are required to: \r\n• Report non-conformances and possible corrective actions to their Line Manager/Supervisor;\r\n• Follow this procedure when interfacing with external suppliers or providers.\r\nThe Quality Manager is required to: \r\n• Determine the causes of non-conformities;\r\n• Maintain a system for reporting and record keeping;\r\n• Implement necessary actions to achieve resolution;\r\n• Review the effectiveness of corrective actions taken.','<div>TABLE OF CONTENTS 2<br>1 PURCHASING &amp; PROCUREMENT 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENT 4<br>2.1 CONTROL OF SUPPLIERS 5<br>2.1.1 Selection of Suppliers 5<br>2.1.2 Surveys &amp; Audits 5<br>2.1.3 Supplier Performance 5<br>2.1.4 Approved Supplier List 5<br>2.1.5 Review 6<br>3 DETAIL PROCEDURE 6<br>3.1 GENERATE REQUISITION [RF] 6<br>3.2 REQUISITION FORM [RF] SCREENING 6<br>3.3 SUPPLIER/VENDOR SOURCING SELECTION 6<br>3.4 PO/SO/WO/RO GENERATION 7<br>3.5 APPROVAL 7<br>3.6 DELIVERY 7<br>3.7 RECEIVING 8<br>4 REVIEW AND VERIFY 8<br>5 CONTROL AND MONITORING 8<br>6 FORMS &amp; RECORDS 8<br>7 FLOWCHART 9</div><div>&#8195;<br></div>','https://mega.nz/#F!Li4wCC6b!4XzW_csdmhWGGDOgZNd5TA',NULL,NULL,NULL,'00247700_1566964640.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-14 14:31:43','2019-08-28 11:57:20'),(81,'6050_L3_PRO_GL5011','GUIDELINE FOR PURCHASING & PROCUREMENT','GUIDELINE FOR PURCHASING & PROCUREMENT ( currently not available )','Quality','Guideline','00','2019-08-14',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-14 14:33:48','2019-08-17 23:42:05'),(82,'6050_L4_PRO_F5011','REQUEST ORDER FORM','REQUEST ORDER FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-14 14:36:31',NULL),(83,'6050_L4_HRA_F5012','PURCHASE ORDER / SERVICE ORDER','PURCHASE ORDER / SERVICE ORDER','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-14 14:38:21',NULL),(84,'6050_L2_PRO_P502','PAYMENT CERTIFICATE & PAYMENT REQUEST','The purpose of this procedure is to ensure that all relevant Vendor Payment Certificate and Payment Request which forms an integral part of our quality management system is managed under controlled conditions and that all documented information is reviewed and approved by authorized personnel prior to external dissemination. \r\n\r\nPurpose: The procedure is to ensure Vendor claim Certificate and Payment Request are effectively determined, documented where possible and shared/ communicated to the target group or relevant staff to ensure the payment milestone is achieved and to prevent delay of payment. \r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Procedure','1','2019-06-01','PG/QMS/PRO/P502','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	Project Manager \r\nProject manager have the responsibility, authorities and accountable for:\r\na)	Ensuring important document are available within the organization.\r\nb)	Review and verify Service Order, Invoice and Project File.\r\n1.3.2	Process owner \r\nProcess Owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge \r\nPerson in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Ensure Purchase Order (PG/QMS/PRO/F5011) and Invoice has been filled.\r\nc)	Ensure supporting document available for claiming process (DPR, Timesheet, PO, Quotation, and Invoice)\r\nd)	To execute the programs that have been set in this procedure\r\ne)	To work with the input that available at organization hence can achieve the target that have been set.\r\nf)	Availability of Project File.\r\nAll interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owner of this procedure are Project Engineer.','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.3.1 Project Manager 4<br>1.3.2 Process owner 4<br>1.3.3 Person in-charge 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 VERIFICATION OF WORK DONE 5<br>3.1.1 General 5<br>3.1.2 Sources of Work Done 5<br>3.2 PREPARING THE CLAIM CERTIFICATE 5<br>3.2.1 Capturing the Knowledge 5<br>3.3 INVOICE AND CLAIM DISSEMINATION 6<br>3.3.1 General 6<br>3.3.2 Dissemination 6<br>3.4 INVOICE PROVE OF ACCEPTANCE 6<br>3.4.1 General 6<br>4 REVIEW AND VERIFY 6<br>5 CONTROL AND MONITORING 6<br>6 FORMS &amp; RECORDS 7</div><div>&#8195;<br></div>','https://mega.nz/#F!yj5QTIIS!XR1ayXR2_ssOn2aHIH36pQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-14 14:42:22','2019-08-27 12:29:59'),(85,'6050_L3_PRO_GL5021','GUIDELINE FOR PAYMENT CERTIFICATE & PAYMENT REQUEST','GUIDELINE FOR PAYMENT CERTIFICATE & PAYMENT REQUEST','Quality','Guideline','00','2019-08-17',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-17 01:32:50',NULL),(86,'6050_L4_PRO_F5021','PAYMENT CERTIFICATE','PAYMENT CERTIFICATE','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-17 01:34:47',NULL),(87,'6050_L2_PRO_P503','MANAGING SUBCONTRACTOR','The purpose of this procedure is to define the activities required to ensure that subcontractor conform to the specified purchase requirements, by detailing the combination of supplier controls, purchasing requirements and purchased product inspection taking into account the potential consequences of a non-conforming product being delivered.\r\n\r\nPurpose: This procedure applies to the evaluation and monitoring of suppliers supplying materials, components, parts, and sub-assemblies that are incorporated into final products. Also included are suppliers of associated services that may affect product quality, such as design, delivery and calibration of measuring equipment, etc. \r\nThis procedure also applies to all inspecting, testing and checking activities to verify that products and materials conform to specified requirements. Exclusion: The procurement of office supplies, stationery, sundries and janitorial services are excluded from this requirement, as are repair and replacement parts, etc.\r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Procedure','1','2019-06-01','PG/QMS/PRO/P503','1.3	Responsibilities\r\nAll Purchasing and Buying staff & Process Owners are required to: \r\n•	Report non-conformances and possible corrective actions to their Line Manager/Supervisor;\r\n•	Follow this procedure when interfacing with external suppliers or providers.\r\nThe Quality Manager is required to: \r\n•	Determine the causes of non-conformities;\r\n•	Maintain a system for reporting and record keeping;\r\n•	Implement necessary actions to achieve resolution;\r\n•	Review the effectiveness of corrective actions taken.','<div>TABLE OF CONTENTS 2<br>1 MANAGING SUBCONTRACTOR 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENT 4<br>2.1 CONTROL OF SUPPLIERS CONSIDERATION 5<br>2.1.1 Surveys &amp; Audits 5<br>2.1.2 Review 5<br>3 DETAIL PROCEDURE 5<br>3.1 SELECTION OF CONTRACTOR 5<br>3.2 CHECK &amp; EVALUATE CONTRACTOR QMS 5<br>3.3 AWARD JOB TO CONTRACTOR 6<br>3.4 MONITOR AND CHECK CONTRACTOR QHSE IMPLEMENTATION DURING EXECUTION OF PROJECT 6<br>3.5 CONTRACTOR QHSE PERFORMANCE EVALUATION 6<br>4 REVIEW AND VERIFY 6<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7</div><div>&#8195;<br></div>','https://mega.nz/#F!CmwmDQhR!PUU8f-GGnyA3rhPP92XlcQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-17 01:36:45','2019-08-27 12:30:58'),(88,'6050_L3_PRO_GL5031','GUIDELINE FOR MANAGING SUBCONTRACTOR','GUIDELINE FOR MANAGING SUBCONTRACTOR ( currently not available )','Quality','Guideline','00','2019-08-17',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-17 01:38:42',NULL),(89,'6050_L4_PRO_F5031','FORM FOR MANAGING SUBCONTRACTOR','FORM FOR MANAGING SUBCONTRACTOR','Quality','Forms','00','2019-08-17',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-17 01:52:04',NULL),(90,'6050_L2_PRO_P504','SUBCONTRACTOR PERFORMANCE ASSESSMENT','The purpose of this procedure is to define the activities required to ensure that vendor performance assessment conform to the specified vendor performance assessment requirements, by detailing the combination of vendor controls, purchasing/subcontract requirements and purchased item/service inspection taking into account the potential consequences of a non-conforming item/service being delivered.\r\n\r\nPurpose: This procedure applies to the evaluation and monitoring of suppliers supplying materials, components, parts, and sub-assemblies that are incorporated into final products. Also included are suppliers of associated services that may affect product quality, such as design, delivery and calibration of measuring equipment, etc. \r\nThis procedure also applies to all inspecting, testing and checking activities to verify that products and materials conform to specified requirements. Exclusion: The procurement of office supplies, stationery, sundries and janitorial services are excluded from this requirement, as are repair and replacement parts, etc.\r\n\r\nScope: The procedure is applicable to all new and existing employees at all departments/ units/ functions in the organisation and is to be followed by all personnel where appropriate.','Quality','Procedure','2','2019-04-01','PG/QMS/PRO/P504','1.3	Responsibilities\r\nAll Purchasing and procurement, subcontract executive & Process Owners are required to: \r\n•	Report non-conformances and possible corrective actions to their Line Manager/Supervisor;\r\n•	Follow this procedure when interfacing with external suppliers or providers.\r\n•	Review and verify:\r\na.	Vendor Performance Assessment [PG/QMS/PRO/F5041]\r\nThe Quality Manager is required to: \r\n•	Determine the causes of non-conformities;\r\n•	Maintain a system for reporting and record keeping;\r\n•	Implement necessary actions to achieve resolution;\r\n•	Review the effectiveness of corrective actions taken.','<div>TABLE OF CONTENTS 2<br>1 PURCHASING &amp; PROCUREMENT 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REQUIREMENT 5<br>2.1 CONTROL OF SUPPLIERS 5<br>2.1.1 Supplier Performance 5<br>2.1.2 Approved Supplier List 5<br>2.1.3 Review 5<br>3 DETAIL PROCEDURE 5<br>3.1 RAISE VENDOR PERFORMANCE ASSESSMENT 5<br>3.2 GENERATE VENDOR PERFORMANCE SUMMARY 6<br>3.3 PERFORMANCE ASSESSMENT 6<br>3.4 DECISION AND ACCEPTANCE STATUS 7<br>3.5 REVIEW AND APPROVE 7<br>3.6 UPDATE APPROVED VENDOR/ SUBCONTRACTOR LIST 7<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7</div><div>&#8195;<br></div>','https://mega.nz/#F!e6hSRARR!sNVkKify9eGZRBrKBP4PAw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-17 01:55:28','2019-08-27 12:31:58'),(91,'6050_L3_PRO_GL5041','GUIDELINE FOR SUBCONTRACTOR PERFORMANCE ASSESSMENT','GUIDELINE FOR SUBCONTRACTOR PERFORMANCE ASSESSMENT ( currently not available )','Quality','Guideline','00','2019-08-17',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-17 01:57:29',NULL),(92,'6050_L4_PRO_F5041','VENDOR PERFORMANCE ASSESSMENT FORM','VENDOR PERFORMANCE ASSESSMENT FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-17 01:59:41',NULL),(93,'6050_L2_QAC_P601','DETERMINING CONTEXT OF THE ORGANIZATION','The purpose of this procedure is to define Petrogas process for undertaking QMS audits, process audits, and supplier and legislation audits in order to assess the effectiveness of the application of our quality management system and its compliance to ISO 9001:2015. This procedure also defines the responsibilities for planning and conducting audits, reporting results and retaining associated records.\r\n\r\nThe purpose of this document is to define the process of identification and determination of the internal and external context of the organization, as well as needs and expectations of interested parties related to the Quality Management System (QMS).','Quality','Procedure','1','2019-06-01','PG-QMS-QAC-P601','1.3 Responsibilities, Authorities & Accountabilities\r\n1.3.1 QMS Manager has the responsibility, authority and accountable for:\r\na) Ensuring important document are available within organization as per below item.\r\nb) Ensuring important document are available within organization\r\nc) Internal & External Issues (PG/QMS/QAC/F6011)\r\nd) List of Interested Parties (PG/QMS/QAC/F6012)\r\ne) Process owner have the responsibility for:\r\n1.3.2 Process owner have the responsibility for:\r\na) Designating a responsible for the improvement action once the potential causes are agreed.\r\nb) Verifying effectiveness of implementation of process flow.\r\nc) Congratulating the employee that initiated implementation of process flow\r\nd) Person in-charge have the responsibility, authority and accountability for:\r\ne) To achieve KPI that was set for this procedure.\r\nf) Review and verify respective Business Plan Analysis.\r\ng) To execute the programs that have been set in this procedure.\r\nh) To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.3 All interested parties & employees have common responsibilities for:\r\n1.3.4 Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5 The process owner of this procedure are QMS Manager and Quality Executive.\r\n1.3.6 The performance indicator was set to meet organization objective through the implementation of Leading and Lagging Indicator.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 3<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 4<br>2.1 REFERENCES DOCUMENT 4<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 INTERNAL CONTEXT 5<br>3.2 EXTERNAL CONTEXT 5<br>3.3 IDENTIFICATION OF INTERESTED PARTIES 6<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7<br>','https://mega.nz/#F!7rhg0KBb!_RBi6eKKncjvQOUtcqyjDA',NULL,NULL,NULL,'72007800_1566975817.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-17 03:15:03','2019-08-28 15:03:37'),(94,'6050_L2_QAC_P602','PERSONNEL ROLES, RESPONSIBILITIES & AUTHORITIES','To ensure the responsibility for the health, safety and environmental issues within the company that complies with company policy, client’s QHSE requirements and local government legislation. This procedure is applied to all processes within the Quality Management System.\r\n\r\nThis department has overall responsibility for the health, safety and environmental issues within the company. The department audits projects to ensure compliance with company policy, Client\'s QHSE requirements and local Government Legislation.','Quality','Procedure','1','2019-06-01','PG-QMS-QAC-P602','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization\r\nb)	Ensure all staff review and sign on the Job Description and Specification (PG/QMS/HRA/JD)\r\nc)	Ensure hierarchy of level for reporting are well determined by referring to Petrogas Organization Chart (PG/QMS/QAC/ORG001)\r\nd)	Review and verify:\r\na.	Personnel File (510)\r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating and responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Ensure Document Acknowledgement Form (PG/QMS/QAC /F6022) was filled properly.\r\nc)	Conduct QHSE Induction for new staff and ensure QHSE Induction Form (PG/QMS/QAC /F6021) has/have been fill properly.\r\nd)	Ensure availability of Personnel File.\r\ne)	To execute the programs that have been set in this procedure.\r\nf)	To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owners for this procedure are QMS Manager and Quality Executive.\r\n1.3.6	The performance indicator was set to ensure all new staff has been through the company induction.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 3<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 RESPONSIBILITIES 5<br>3.2 GENERAL RULES 8<br>3.3 DRUG ABUSE 9<br>3.4 ALCOHOL ABUSE 9<br>3.5 PERSONNEL JOB DESCRIPTION 10<br>4 REVIEW AND VERIFY 10<br>5 CONTROL AND MONITORING 10<br>6 FORMS &amp; RECORDS 10<br>','https://mega.nz/#F!GvpkGKzY!ZN4NWuSizAEPk49YE_uZZw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:12:48','2019-08-27 12:34:01'),(95,'6050_L2_QAC_P603','EVENT NOTIFICATION','Petrogas is committed to Quality, Health, Safety and Environment of all people and system at the workplace. The purpose of this procedure is to document a systematic process for the internal notification of QMS incident and event notification across Petrogas. This procedure also provides guidance on external notifications, being the requirements and process to report incident, breakdown and etc. to client/interested parties. This procedure include also include the external event notification to the external parties. \r\n\r\nThis procedure applies to all Petrogas workers, business groups and work activities, and it is not limited to the notification aspects of Petrogas personnel incidents only. It also can be notification of Mobilization and Demobilization, equipment transfer, crew changes and etc.','Quality','Procedure','1','2019-06-01','PG-QMS-QAC-P603','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization (risk and opportunity register)\r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Raise internal and external notification\r\nc)	To execute the programs that have been set in this procedure\r\nd)	To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owner of this procedure are QMS Manager and Quality Executive.\r\n1.3.6	The performance indicator for this procedure is event notification shall submit in timely manner.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 3<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 4<br>2.1 REFERENCES DOCUMENT 4<br>2.2 TERMS &amp; DEFINITION 4<br>3 DETAILED PROCEDURE 5<br>3.1 IMMEDIATE NOTIFICATION OF A IMS INCIDENT OR EVENT NOTIFICATION 5<br>3.2 EVENT FOLLOW-UP 5<br>3.3 EVENT CLOSE-UP 6<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7<br>','https://mega.nz/#F!PzhwjIxJ!8DllN0jmQ79G0BTdIJUc5Q',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:16:12','2019-08-27 12:34:53'),(96,'6050_L2_QAC_P604','COMMUNICATION, CONSULTATION & PARTICIPATION','The purpose of this general procedure is to:\r\na) Ensure QHSE awareness is positively communicated and promoted throughout the company by Senior Management and their Line Management.\r\nb) Demonstrate strong visible leadership and commitment.\r\nc) Promote Senior Managements readiness to address and resolve identified QHSE deficiencies and identify measures to prevent reoccurrence.\r\nd) Maintain an effective communications system by promoting staff participation.\r\n\r\nThe scope of this General Procedure is to describe how Senior Management, Project Managers and Line Managers effectively communicate the requirements of the Quality Management System, demonstrate commitment, achieve motivation and ensure all QHSE matters are given the same importance as any other business decision.','Quality','Procedure','2','2019-04-01','PG-QMS-QAC-P604','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization.\r\nb)	Discuss with top management regarding QMS Objectives every year\r\nc)	Review and verify :\r\na.	QMS Objectives achievement monitoring table\r\nb.	Leading and Lagging Indicator\r\nc.	Analysis of data table\r\na)	Chairman in Management Review Meeting\r\nb)	Ensure execution of QMS Programs; based on Annual QMS Plan (PG/QMS/QAC/F6042) (MOM, Campaign, and etc.)\r\nc)	Monitor QMS target and objectives.\r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Propose to Quality Manager regarding QMS target and objectives.\r\nc)	To execute the programs that have been set in this procedure\r\nd)	To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owner of this procedure are Quality Manager and Quality Executive.\r\n1.3.6	The performance indicator is to ensure implementation of participation, communication and consultation activity on time.','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 ESTABLISHMENT OF QMS OBJECTIVES &amp; PROGRAMS 5<br>3.2 ENROLMENT OF QUALITY OBJECTIVE &amp; PROGRAM 6<br>3.3 PARTICIPATION COMMUNICATION &amp; CONSULTATION 7<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 8<br>6 FORMS &amp; RECORDS 8</div><div>&#8195;<br></div>','https://mega.nz/#F!Kr4k3Iab!Huxnjf-Xfo-fw4y8G-hyTA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:18:59','2019-08-27 12:35:48'),(97,'6050_L2_QAC_P605','ADDRESSING RISKS & OPPORTUNITIES','The purpose of this procedure is to outline Petrogas’ s the risk and opportunity management framework and the activities within. The risk and opportunity management framework defines Petrogas current risk management process, which includes; methodology, risk appetite, methods for training and reporting.\r\n\r\n1.2.1 The Risk and opportunity is defined by Petrogas as ‘something happening that may have an impact on the achievement of Petrogas objectives or which may affect Petrogas QMS’. \r\n1.2.2 Risk and opportunity management is a central part of Petrogas organization’s strategic management. It is the process whereby management teams and risk owners methodically address the risks and opportunities attached to their activities with the goal of achieving sustained benefit within their activity. \r\n1.2.3 This includes the assessment of risks and opportunities of any type. Accountable Managers shall:\r\na) Maintain a risk registers in for the scope and objectives for which they are accountable;\r\nb) Consider all types of risk and opportunity, including; schedule, cost, quality, 3rd Parties, etc.;\r\nc) Ensure that this procedure operates fully within their teams;\r\nd) Make adequate competent resource available to ensure that risk management obligations are met;\r\ne) Ensure that all other relevant parties and perspectives are appropriately engaged.','Quality','Procedure','1','2019-06-01','PG-QMS-QAC-P605','1.3 Responsibilities, Authorities & Accountabilities\r\n1.3.1 QMS Manager has the responsibility, authority and accountable for:\r\na) Ensuring important document are available within organization (Risk and Opportunity Register)\r\nb) Review and verify Addressing Risks & Opportunities Register (PG/QMS/QAC/F6051).\r\nc) Monitor Addressing Addressing Risks & Opportunities Register (PG/QMS/QAC/F6051).\r\n1.3.2 Process owner have the responsibility for:\r\na) Designating a responsible for the improvement action once the potential causes are agreed.\r\nb) Verifying effectiveness of implementation of process flow\r\nc) Congratulating the employee that initiated implementation of process flow\r\n1.3.3 Person in-charge has the responsibility, authority and accountability for:\r\na) To achieve KPI that was set for this procedure\r\nb) Review and verify respective Business Plan Analysis\r\nc) To execute the programs that have been set in this procedure\r\nd) To work with the input that available at organization hence can achieve the target that has been set.\r\n1.3.4 All interested parties & employees have common responsibilities for:\r\na) Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5 The process owner of this procedure is QMR and Quality Executive.\r\n1.3.6 The performance indicator was set to ensure Addressing Risks & Opportunities review and analyzed before job execution.\r\n1.3.7 The performance indicator was set to meet organization objective through the implementation of Leading and Lagging Indicator (PG/QMS/QAC/F6025)','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 GENERAL 5<br>3.2 CONTEXT 5<br>3.3 IDENTIFICATION 6<br>3.4 ASSESSMENT 7<br>3.5 INHERENT RISK RATING 7<br>3.6 RISK TREATMENT 9<br>3.7 REVIEW 9<br>3.8 REPORTING 10<br>3.9 MONITORING 10<br>3.10 RISK REGISTER 10<br>3.11 TRAINING 10<br>3.12 COMMUNICATION 11<br>4 REVIEW AND VERIFY 11<br>5 CONTROL AND MONITORING 11<br>6 FORMS &amp; RECORDS 11</div><div>&#8195;<br></div>','https://mega.nz/#F!224yHQqC!xj0Pg6QAsbz5vp1GfHp5kg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:22:02','2019-08-27 12:37:12'),(98,'6050_L2_QAC_P606','MANAGEMENT OF CHANGE','1.1.1 The objective of the Management of Change procedure is to provide the necessary tools for a comprehensive review of all changes affecting refinery processes prior to implementation of the change and prior to the IMS Process involved. \r\n1.1.2 The procedures stipulated in this document shall be applicable to all Petrogas operations, if there are any changes are made to:\r\na) Management system process changes\r\nb) Operating change involving equipment.\r\nc) Equipment change involving engineering and/or design.\r\nd) Organizational change to team structures, competence, and staffing.\r\ne) Procedural change to approved methods or agreed practices.\r\n\r\n1.2.1 The change management process is the sequence of steps or activities that a change management team or project leader would follow to apply change management to a project or change. Based on Prosci\'s research of the most effective and commonly applied change, most change management processes contain the following three phases:\r\na) Phase 1 - Preparation, assessment and strategy development\r\nb) Phase 2 - Detailed planning and change management implementation\r\nc) Phase 3 - Data gathering, corrective action and recognition','Quality','Procedure','2','2019-04-01','PG-QMS-QAC-P606','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\nd)	Ensuring important document are available within organization (Risk and Opportunities Register)\r\ne)	Ensure requirement by QMS followed by staff.\r\nf)	Review and verify Management of Change Evaluation Form (PG/QMS/QAC/F6061)\r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge has the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Custodian to filled the Management of Change Evaluation Form (PG/QMS/QAC/F6061)\r\nc)	To execute the programs that have been set in this procedure\r\nd)	To work with the input that available at organization hence can achieve the target that has been set.\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owner of this procedure is QMR and Quality Executive.\r\n1.3.6	The performance indicator was set to meet organization objective through the implementation of Leading and Lagging Indicator.','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 RESPONSIBILITIES 5<br>3.1 THE MOC REVIEW COMMITTEE APPOINTMENT/ SELECTION 5<br>3.2 FUNCTION OF MOC REVIEW 5<br>3.3 MOC PROCESS 6<br>4 DETAILED PROCEDURE 6<br>4.1 INTRODUCTION 6<br>4.2 REQUEST OF CHANGE 7<br>4.3 REVIEW MOC APPLICATION 8<br>4.4 APPROVAL OF APPLICATION 8<br>4.5 REJECTED APPLICATION 8<br>4.6 IMPLEMENTATION 8<br>5 REVIEW AND VERIFY 9<br>6 CONTROL AND MONITORING 9<br>7 FORMS &amp; RECORDS 9</div><div>&#8195;<br></div>','https://mega.nz/#F!fmpWDCKR!kYf1zSCTuXW1oL8lKUdTGA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:25:35','2019-08-27 12:38:02'),(99,'6050_L2_QAC_P607','DOCUMENTED INFORMATION','The purpose of this procedure is to ensure that all relevant documented information and organizational knowledge which forms an integral part of our quality management system is managed under controlled conditions and that all documented information is reviewed and approved by authorized personnel prior to issue. \r\n\r\nDocumented information is retained to provide evidence of conformity to the requirements specified by ISO standards, client requirements and of the effective operation of our management system. Petrogas uses standard forms and templates accessed via a local area network computer system. This documented procedure defines the controls for:\r\n1. Approving documents for adequacy prior to issue;\r\n2. Reviewing and revising as necessary and re-approving documents;\r\n3. Ensuring that changes and current revision status of documents are identified;\r\n4. Ensuring that relevant versions of applicable documents are available at points of use;\r\n5. Ensuring that documents remain legible and readily identifiable;\r\n6. Ensuring that documents of external origin are identified and their distribution controlled;\r\n7. Preventing the unintended use of obsolete documents; \r\n8. Ensuring that documents of external origin are identified and their distribution controlled. \r\nThis procedure applies to all quality management system documentation and is to be followed by all personnel where appropriate.','Quality','Procedure','2','2019-04-01','PG/QMS/QAC/P607','1.3	Responsibilities, Authorities & Accountabilities\r\nQHSE Manager has the responsibility, authority and accountable for:\r\nEnsuring important document are available within organization (analysis of business plan, analysis of technology and competitors, economic reports from relevant business sector and technical reports from technical experts and consultant)\r\nProcess owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow.\r\nc)	Congratulating the employee that initiated implementation of process flow\r\nPerson in-charge has the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure.\r\nb)	Review and verify respective Business Plan Analysis.\r\nc)	To execute the programs that has been set in this procedure.\r\nd)	To work with the input that available at organization hence can achieve the target that has been set.\r\nAll interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\nThe process owners of this procedure are Quality Management Representative and Quality Executive.\r\nThe performance indicator was set to meet organization objective through the implementation of Leading and Lagging Indicator (PG/QMS/QAC/F6125).','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.1.1 Process Activity Map 3<br>1.1.2 References 3<br>1.1.3 Terms &amp; Definitions 3<br>1.2 APPLICATION &amp; SCOPE 4<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REQUIREMENTS 5<br>3 DETAIL PROCEDURE 5<br>3.1 CREATING, UPDATING &amp; CONTROLLING DOCUMENTED INFORMATION 5<br>3.1.1 General 5<br>3.1.2 Document &amp; Data Identification, Approval and Use 6<br>3.1.3 Revising a Controlled Document 6<br>3.1.4 External Documents 6<br>3.1.5 Uncontrolled Documents 6<br>3.1.6 Document Change Requests 7<br>3.1.7 International Standards &amp; Specifications 7<br>3.1.8 Obsolete Documents 7<br>3.2 MANAGEMENT SYSTEM RECORDS 7<br>3.2.1 Protection, Storage and Retrieval of Documented Information 7<br>3.2.2 Retention Period for Records 8<br>3.2.3 Disposal of Records 8<br>3.2.4 Register of Documented Information 8<br>4 REVIEW AND VERIFY 9<br>5 CONTROL AND MONITORING 9<br>6 FORMS &amp; RECORDS 9</div><div>&#8195;<br></div>','https://mega.nz/#F!y34wSIQA!S8ILSpwcxLlIu76Y48p7oA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:28:43','2019-08-27 12:38:56'),(100,'6050_L2_QAC_P608','WORK ENVIRONMENT MONITORING & CONTROL','1.1.1 The purpose of this work instruction is to describe the methods used by the Company to manage and secure safe working conditions and practices in compliance to Malaysia HSE legislation and International Marine Contractor Association (IMCA).\r\n\r\n1.2.1 The scope of this procedure are:\r\na) The ability of activities and operations to achieve expected results and product requirements according to customer satisfaction and regulatory requirements\r\nb) The ability of the process environment to support the resources that operate business activities\r\nc) The ability of the process environment to support the safety of products—the conditions of protection against consequences of failure, damage, error, accidents, harm, or any other event that could be considered as nonconformity','Quality','Procedure','1','2019-06-01','PG-QMS-QAC-P608','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization.\r\nb)	Ensure implementation of this procedure based on QMS requirement.\r\nc)	Review and verify:\r\na.	Hygiene Inspection Form (PG/QMS/QAC/F6081)\r\nb.	Work Environment Questionnaire (PG/QMS/QAC/F6082)\r\nd)	Monitor Leading and Lagging Indicator (PG/QMS/QAC/F6152)\r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure.\r\nb)	Inspect working area:\r\na.	Perform Hygiene Inspection (PG/QMS/QAC/F6081) for every month\r\nb.	Execute Work Environment Questionnaire (PG/QMS/QAC/F6082) for every quarter\r\nc)	Custodian to plan and implement the QHSE Campaign. The content of QHSE Campaign include QHSE Alert, QHSE Bulletin, QHSE Training and Poster.\r\nd)	Custodian to collect the data for Leading and Lagging Indicator (PG/QMS/QAC/F6152).\r\ne)	To execute the programs that have been set in this procedure\r\nf)	To work with the input that available at organization hence can achieve the target that have been set.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 3<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 4<br>2.1 REFERENCES DOCUMENT 4<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>2.3 SAFE WORKING ENVIRONMENT 5<br>2.4 SAFE WORKING PRACTICES 6<br>2.5 INFORMATION, INSTRUCTION AND TRAINING 6<br>2.6 MONITORING OF WORK ENVIRONMENT PARAMETER 7<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7<br>','https://mega.nz/#F!e7wGDQ4Y!t8TRBzKfuUEgiHegiMJvyA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:31:13','2019-08-27 12:39:47'),(101,'6050_L2_QAC_P609','LEGAL & OTHER REQUREMENTS','1.1.1 This procedure describes the method to document the process of identifying and acquiring access to Quality, Health, Safety and Environment related legal and other requirements applicable to Petrogas activities, products and services. It also includes QHSE legislation provided for communication to interested parties and to keep the information up–to–date. It also describes the periodical evaluation of the compliance with the applicable legal requirements.\r\n\r\n1.2.1 This procedure applies to quality, safety, health legal and other requirements which relate to the QMS process and project. \r\n1.2.2 This procedure also covers the legal and other requirements that specific to the company’s activities and facilities, and industry, occupational health and safety laws, agreements, guidelines and directives in which the company have to comply.\r\n1.2.3 The Quality Dept., together with Quality Personnel identified the legal and other requirements at the early stage of the projects. These requirements are listed in a register and communicated to the Project Manager and other team members. \r\n1.2.4 The Quality department shall maintain the list of legal and other requirements that relate to QHSE and update whenever necessary.','Quality','Procedure','1','2019-06-01','PG-QMS-QAC-P609','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization (risk and opportunity register)\r\nb)	Ensuring all regulations (OSHA 1994, FMA, EQA, BOMBA, Shipping Ordinance, Electrical Act, IMCA, etc.) has been comply.\r\nc)	Review and verify Legal Register (PG/QMS/QMS/F6091)\r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Custodian to update Legal Register (PG/QMS/QMS/F6091)\r\nc)	To execute the programs that have been set in this procedure\r\nd)	To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owner of this procedure are QMR and Quality Executive.\r\n1.3.6	The performance indicator for this procedure is continuously update Legal Register.','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 GENERAL 5<br>3.2 IDENTIFICATION OF LEGAL AND OTHER REQUIREMENT 5<br>3.3 IMPLEMENTATION OF LEGAL AND OTHER REQUIREMENT 6<br>3.4 NON-COMPLIANCE WITH LEGAL AND OTHER REQUIREMENT 6<br>3.5 COMPLIANCE ASSESSMENT OF LEGAL AND OTHER REQUIREMENT 6<br>3.6 MAINTENANCE OF LEGAL AND OTHER REQUIREMENT 6<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7</div><div>&#8195;<br></div>','https://mega.nz/#F!XmggQIbJ!H4x_-pepQv0EOaScEFkBMg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:33:43','2019-08-27 12:40:41'),(102,'6050_L2_QAC_P610','STAKEHOLDER SATISFACTION & FEEDBACK','1.1.1 The purpose of this procedure is to describe the methods for measuring, monitoring and interpreting Client perception information to determine whether Petrogas is meeting Client requirements. Petrogas recognizes that the Client feedback process has important links and interfaces between other management system process that include, but are not limited to; Client communication, design and development validation, design and development changes and process validation.\r\n\r\n1.2.1 The scope of this procedure is to assess the level of Client satisfaction by obtaining input from various sources defined herein. Trends and key indicators of satisfaction are captured and benchmarked. Client satisfaction information is obtained from Client feedback and by analysing Client responses to:\r\na) Project Deliverables returns and warranty claims;\r\nb) Repeat Clients and market share;\r\nc) Analysis of Client complaints and Client satisfaction surveys;\r\nd) Recognition and awards;\r\ne) Growth of key accounts;\r\nf) Analysis of credit notes;\r\ng) On-time delivery.','Quality','Procedure','2','2019-04-01','PG-QMS-QAC-P610','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	Project Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization (Risk and opportunity register)\r\nb)	Ensuring all stakeholder feedback and complains have been records.\r\nc)	Review and verify:\r\na.	CAPAR form (PG/QMS/QAC/F6141)\r\nb.	Customer Perception Monitoring Table\r\nc.	Stakeholder Feedback & Complaint Form (PG/QMS/QAC/F6101)\r\nb)	Monitor Stakeholder Feedback and Complain Register & Non-Conformance Register Log \r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Records all Stakeholder Feedback and Complaint (PG/QMS/QAC/F6101)\r\nc)	Raise CAPAR (PG/QMS/QAC/F6141) if got any Nonconformance or observation from stakeholder\r\nd)	Ensuring stakeholder fill Stakeholder Feedback and Complain Form (PG/QMS/QAC/F6101)\r\ne)	To execute the programs that have been set in this procedure\r\nf)	To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owner of this procedure are Project Engineer.\r\n1.3.6	The performance indicator was set to meet organization objective through the implementation of Leading and Lagging Indicator.','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 RECEIVING COMPLAINTS 5<br>3.2 RESPONSE OF THE COMPLAINT TO CUSTOMER 6<br>3.3 MONITORING INTERVALS AND RESPONSIBILITY 6<br>3.4 RESOLUTION OF THE COMPLAINT 6<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7</div><div>&#8195;<br></div>','https://mega.nz/#F!X7ognSiC!0wOY9c1YthNxl5DQqkCkdg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:36:05','2019-08-27 12:41:35'),(103,'6050_L2_QAC_P611','QUALITY ASSURANCE & CONTROL OF NON-CONFORMANCE','1.1.1 The objective of this procedure is to ensure that any non-conformance processes or/and documents required by the Quality Management System (QMS) detected is properly identified and immediately rectified and corrected. \r\n1.1.2 This procedure also defines the responsibilities and processes for identifying and investigating non-conformances, the action taken to mitigate any negative impacts caused, and for applying corrective and preventive actions.  \r\n\r\n1.2.1 This procedure is applicable to all non-conforming products, services, processes and any aspect of our quality management system. \r\n1.2.2 This procedure is applied to all processes within the QMS. This procedure is applicable to any non-conformity that is internally detected by any of Petrogas personnel both onshore and offshore disregard of their roles and responsibilities. The scope also covers any external reports or/and complaint i.e. the client/s, supplier/s, contractor/s or sub-contractor/s. Any deviation from Petrogas policies, business processes and standards shall be classed as a non-conformance.','Quality','Procedure','1','2019-06-01','PG-QMS-QAC-P611','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization (Risk and Opportunity Register)\r\nb)	Ensure implementation of this procedure based on QMS requirement.\r\nc)	Review and verify:\r\nd)	CAPAR (PG/QMS/QAC/F6141)\r\ne)	Ensure all the data track into Minutes of Meeting (PG/QMS/QAC/F6161).\r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Raise the CAPAR Form (PG/QMS/QAC/F6141) if there any Observation or Non Conformance on process.\r\nc)	To execute the programs that have been set in this procedure\r\nd)	To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owner of this procedure are QMR and Quality Executive.\r\n1.3.6	The performance indicator for this procedure is 100% execution of QA/QC inspection for every month.','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 DETECTION OF NON-CONFORMITIES 5<br>3.2 IDENTIFY THE NON-CONFORMITIES 6<br>3.3 QUALITY ASSURANCE AND CLASSIFICATION OF NC 6<br>3.4 HANDLING OF NON-CONFORMANCE PROCESS/PRODUCT 7<br>3.5 RECHECK NC PRODUCT/PROCESS 7<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7</div><div>&#8195;<br></div>','https://mega.nz/#F!v24ymYIY!_hhCYekjtWKk4I647p5Fqg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:38:26','2019-08-27 12:42:33'),(104,'6050_L2_QAC_P612','MONITORING, MEASUREMENT & ANALYSIS OF DATA','1.1.1 The purpose of this procedure is to establish and define the roles and responsibilities for collecting and analyzing data using appropriate statistical and non-statistical techniques to determine the suitability and effectiveness of key quality management system processes using data in order to drive continual improvement and to facilitate a factual approach to decision making.\r\n\r\n1.2.1 Effective data analysis is an essential part of our QMS. Statistical and non-statistical techniques are utilized, where appropriate, and the data is analyzed by designated personnel and utilized for continuous product and process improvement. \r\n1.2.2 Petrogas monitors trends in the following activities by monitoring the key QMS data points and sources of information:\r\na) Customer satisfaction and dissatisfaction data;\r\nb) Conformity to product requirements;\r\nc) Characteristics of processes, products and their trends;\r\nd) Suppliers and their performance;\r\ne) Quality management system data.\r\n1.2.3 Regardless of the nature of the data source, if there is a decision to escalate the information for further evaluation and investigation, the steps of investigation, identification of root causes and actions needed, verification, implementation, and effectiveness checks will be similar.','Quality','Procedure','2','2019-04-01','PG-QMS-QAC-P612','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization (Risk and opportunity register)\r\nb)	Review and verify:\r\na.	Analysis of Data Table (PG/QMS/QAC/F6124)\r\nb.	QMS Leading and Lagging Indicator (PG/QMS/QAC/F6125)\r\nc.	KPI Summary Plan (PG/QMS/QAC/F6121)\r\nd.	KPI Monitoring Table (PG/QMS/QAC/F6123)\r\nc)	Ensuring analyzing method table referring to below item:\r\na.	Cause Effect Diagram\r\nb.	Check sheet\r\nc.	Control Chart\r\nd.	Histogram\r\ne.	Pareto Diagram\r\nd)	Monitor Leading and Lagging Indicator (PG/QMS/QAC/F6125) \r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	To analyzing the data from each department\r\nc)	To execute the programs that have been set in this procedure\r\nd)	To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owner of this procedure are QMR and Quality Executive.\r\n1.3.6	The performance indicator for this procedure is analyze data on monthly basis.','<div>TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 DETERMINE AND DEFINE SPECIFIC APPROPRIATE DATA 5<br>3.2 MONITORING AND MEASUREMENT OF DATA 6<br>3.3 COLLECT AND ANALYZE DATA 6<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 7</div><div>&#8195;<br></div>','https://mega.nz/#F!eugkmQrR!zWYWD3AJ9y_A7fk13hEBPg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:42:15','2019-08-27 12:43:27'),(105,'6050_L2_QAC_P613','MANAGEMENT SYSTEM AUDIT','1.1.1 The purpose of this procedure is to define Petrogas process for undertaking QMS audits, process audits, and supplier and legislation audits in order to assess the effectiveness of the application of our quality management system and its compliance to ISO 9001:2015. This procedure also defines the responsibilities for planning and conducting audits, reporting results and retaining associated records.\r\n\r\n1.2.1 The scope of this procedure is focused on assessing the effectiveness of Petrogas quality management system. \r\n1.2.2 Where such processes are found to be deficient, the audit will lead to improvement in those processes. \r\n1.2.3 By applying the principles of auditing, outlined by ISO 19011:2011, Petrogas ensures that all internal audits are conducted with due professional care, integrity and independence. \r\n1.2.4 All conclusions derived from the audit are based upon objective and traceable evidence.','Quality','Procedure','2','2019-04-01','PG-QMS-QAC-P613','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization as per below item.\r\na.	Annual QMS Plan (PG/QMS/QAC/F6042)\r\nb.	Audit Schedule (PG/QMS/QAC/6131)\r\nc.	Risk and Opportunities Register (PG/QMS/QAC/F6051)\r\nb)	Review and verify:\r\na.	Audit Memo (PG/QMS/QAC/F6132)\r\nb.	Audit Plan (PG/QMS/QAC/F6133)\r\nc.	Audit Notes and Checklist (PG/QMS/QAC/F6134)\r\nd.	Audit Report and Summary (PG/QMS/QAC/F6135)\r\ne.	CAPAR Form (PG/QMS/QAC/F6141)\r\nc)	Ensuring Management System Audit, Equipment Technical Audit, Project Execution Audit and Vendor Audit has been executed.\r\nd)	Monitor Leading and Lagging Indicator (PG/QMS/QAC/F6125)\r\n1.3.2	Person in-charge has the responsibility, authority and accountability for:\r\na)	Determine the root causes of non-conformities;\r\nb)	Maintain a system for reporting audit results;\r\nc)	Determine conformity to planned arrangements;\r\nd)	Determine proper implementation and maintenance;\r\ne)	Provide the results of audits to top management;\r\nf)	Review the effectiveness of corrective actions taken\r\ng)	Perform Management System Audit, Equipment Technical Audit, Project Execution Audit and Vendor Audit within organization.\r\nh)	To execute the programs that have been set in this procedure\r\ni)	To work with the input that available at organization hence can achieve the target that have been set.\r\nj)	Custodian to plan and prepare:\r\na.	Audit Memo (PG/QMS/QAC/F6132)\r\nb.	Audit Plan (PG/QMS/QAC/F6133)\r\nc.	Audit Notes and Checklist (PG/QMS/QAC/F6134)\r\nd.	Audit Report and Summary (PG/QMS/QAC/F6135)\r\ne.	CAPAR Form (PG/QMS/QAC/F6141)\r\nf.	Audit Schedule (PG/QMS/QAC/6131)\r\n1.3.3	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owners of this procedure are Quality Management Representative and Quality Executive.\r\n\r\nThe performance indicator was set to meet organization objective through the implementation of Leading and Lagging Indicator (PG/QMS/QAC/F6125)\r\n\r\n\r\n&#8195;','<div>TABLE OF CONTENTS</div><div>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 3<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 6<br>3.1 GENERAL 6<br>3.2 PREPARE YEARLY INTERNAL AUDIT SCHEDULE 6<br>3.3 APPOINTMENT AND SELECTION OF AUDIT TEAM 6<br>3.4 PREPARE AND ISSUE AUDIT PLAN 7<br>3.5 PREPARE AND ISSUE AUDIT NOTIFICATION 7<br>3.6 PERFORM AUDIT 7<br>3.7 PREPARE AND ISSUE AUDIT REPORT 7<br>3.8 CONDUCT INVESTIGATION AND INITIATE CORRECTIVE/ PREVENTIVE ACTION 8<br>3.9 REVIEW CORRECTION AND CORRECTIVE ACTION TAKEN EFFECTIVENESS 8<br>4 REVIEW AND VERIFY 8<br>5 CONTROL AND MONITORING 8<br>6 FORMS &amp; RECORDS 8</div><div>&#8195;<br></div>','https://mega.nz/#F!Xn5EkKaR!ckcJvLBOgaStcquud1HvIA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:44:34','2019-08-23 16:54:30'),(106,'6050_L2_QAC_P614','CORRECTIVE & PREVENTIVE ACTION REQUEST','1.1.1 The purpose of this procedure is to establish the process for identifying, documenting and analyzing non-conformities and mitigating their impacts by implementing appropriate corrective actions. Petrogas quality management system is geared toward the proactive elimination of actual and potential deficiencies. \r\n\r\n1.2.1 This procedure is applicable to all non-conforming products, services, processes and any aspect of our quality management system. \r\n1.2.2 Any corrective action & preventive action taken to eliminate the cause of non-conformity is appropriate to the magnitude of the problem whilst also being in proportion to the risks presented by the non-conformity. \r\n1.2.3 Root causes of process non-conformities, including those arising from complaints are investigated and actions implemented to prevent their recurrence. \r\n&#8195;\r\n1.2.4 This procedure applies to:\r\na) Processes producing negative results and defect outputs. Any process which does not produce an acceptable product or services should be reported by any employee through the initiation of the Corrective Action Request Form. \r\nb) Incoming products from suppliers or customers. Product received from suppliers which is found to be non-conforming are identified, reported and returned to the supplier. Recurring problems with discrepant materials from a vendor are reported to the Purchasing Department. \r\nc) Services provided by external sources. If a service provided from an external source does not comply with the requirements of the purchase order and/or contract, then the Corrective Action Request Form is completed and submitted. \r\nd) Internal issues and quality audits. During the process of conducting internal quality audits, processes may be identified as being non-conforming. These are documented on the Internal Audit Checklist, Internal Audit Report Form, and the Corrective & Preventive Action Request Form (PG/QMS/QAC/F6141).','Quality','Procedure','2','2019-04-01','PG-QMS-QAC-P614','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization (risk and opportunity register)\r\nb)	Review and verify CAPAR Form (PG/QMS/QAC/F6141)\r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Raise the CAPAR Form (PG/QMS/QAC/F6141) has been properly filled.\r\nc)	To execute the programs that have been set in this procedure\r\nd)	To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owner of this procedure are QHSE Manager and QHSE Executive.\r\n1.3.6	The performance indicator for this procedure is close out CAPAR correctly as procedure.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 REVIEW NC AND POTENTIAL NC 5<br>3.2 ISSUE CORRECTIVE ACTION &amp; PREVENTIVE ACTION REQUEST (CAPAR) 6<br>3.3 INVESTIGATE OF ROOT CAUSE AND POTENTIAL ROOT CAUSE 6<br>3.4 EVALUATE THE NEED FOR PREVENTIVE AND CORRECTIVE ACTION 7<br>3.5 DETERMINE APPROPRIATE CORRECTIVE AND PREVENTIVE ACTION 7<br>3.6 IMPLEMENT CORRECTIVE AND PREVENTIVE ACTION 7<br>3.7 REVIEW THE EFFECTIVENESS OF THE CORRECTIVE AND PREVENTIVE ACTION TAKEN 7<br>4 REVIEW AND VERIFY 8<br>5 CONTROL AND MONITORING 8<br>6 FORMS &amp; RECORDS 8<br><br>','https://mega.nz/#F!Oi5yWYCb!KR99biq9TKrJWLK5B1gGjw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:46:48','2019-08-23 16:50:59'),(107,'6050_L2_QAC_P615','CONTINUAL IMPROVEMENT','1.1.1 The purpose of this procedure is to define Petrogas’ s process for establishing a philosophy of continual improvement throughout our business, which is driven by goals documented in the corporate objectives and policies. Opportunities for improvement are identified and translated into improvement projects.\r\n\r\n1.2.1 This procedure applies to all staff at all levels. Continual improvement is more of a philosophy than a process or system. It requires everyone as a participant to adopt, as part of their normal work, a mind-set of continuously looking for ways to improve processes and systems, i.e. to make them more efficient and effective.\r\n1.2.2 Petrogas uses the PDCA-cycle is used to coordinate our continuous improvement efforts. It emphasizes and demonstrates that improvement programs must start with careful planning, must result in effective action, and must move on again to careful planning in a continuous cycle. It is a strategy used to achieve breakthrough improvements in safety, quality, morale, delivery cost, and other critical business objectives.\r\na) Plan - analysis of what needs to be improved by taking into consideration areas that hold opportunities for change. Decision on what should be changed.\r\nb) Do - implementation of the changes that are decided on in the Plan step.\r\nc) Check - Control and measurement of processes and products in accordance to changes made in previous steps and in accordance with policy, goals and requirements on products. Report on results.\r\nd) Act - Adoption or reaction to the changes or running the PDCA-cycle through again. Keeping improvement on-going.','Quality','Procedure','2','2019-04-01','PG-QMS-QAC-P615','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization (risk and opportunity register)\r\nb)	Review and verify Continual Improvement Plan Form (PG/QMS/QAC/F6151)\r\n1.3.2	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.3	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Ensuring filled properly fill Continual Improvement Plan Form (PG/QMS/QAC/F6151)\r\nc)	Properly plan for Annual QMS Plan (PG/QMS/QAC/F6042)\r\nd)	To execute the programs that have been set in this procedure\r\ne)	To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.4	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.5	The process owner of this procedure are QMR and Quality Executive.\r\n1.3.6	The performance indicator for this procedure is close out CAPAR correctly as procedure.\r\n\r\n&#8195;','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 4<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 IMPROVEMENT PROCESS 5<br>3.2 IDENTIFYING OPPORTUNITIES FOR IMPROVEMENT 5<br>3.3 ANALYZING CURRENT QMS PROCESSES 6<br>3.4 IDENTIFYING ISSUES &amp; PROBLEMS 6<br>3.5 DEVELOPING SOLUTIONS 7<br>3.6 TRACKING METRICS 7<br>3.7 EVALUATION, PRIORITIZATION AND IMPLEMENTATION 7<br>4 REVIEW AND VERIFY 7<br>5 CONTROL AND MONITORING 7<br>6 FORMS &amp; RECORDS 8<br><br>','https://mega.nz/#F!jihUVaDS!vfiXlEALekpo0pNwRjl-UA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:50:02','2019-08-23 16:49:23'),(108,'6050_L2_QAC_P616','MANAGEMENT REVIEW','1.1.1 The purpose of this procedure is to define Petrogas’ s process for undertaking management reviews in order to assess the effectiveness of the application of our quality management system and its compliance to ISO 9001:2015. This procedure also defines the responsibilities for planning, conducting, reporting results and retaining associated records.\r\n\r\n1.2.1 The scope of this procedure details the method of reviewing the quality management system and describing how deficiencies are documented to ensure it is up to date, controlled and effective. \r\n1.2.2 The review ensures the quality systems’ continuing suitability and effectiveness in satisfying the requirements of ISO 9001:2015 and Petrogas’ s quality policies and objectives. \r\n1.2.3 The management reviews are undertaken annually.','Quality','Procedure','2','2019-04-01','PG-QMS-QAC-P616','1.3	Responsibilities, Authorities & Accountabilities\r\n1.3.1	QMS Manager has the responsibility, authority and accountable for:\r\na)	Ensuring important document are available within organization as per below.\r\na.	Memo (PG/QMS/QAC/F6132)\r\nb.	Management Review Minutes and Agenda (PG/QMS/QAC/F6161)\r\nc.	Annual QMS Plan (PG/QMS/QAC/F6042)\r\nd.	Risk and Opportunity Register (PG/QMS/QAC/F6051)\r\nb)	Chairman of the MRM\r\nc)	Ensuring all staff attend MRM\r\nd)	Ensure that management reviews are conducted at planned intervals;\r\ne)	Quality management system data, e.g. results of internal audits, KPIs, etc.;\r\nf)	Opportunities for improvement;\r\ng)	Monitoring of quality, environmental and health and safety objectives;\r\nh)	Results of the reporting and evaluation of the cost of poor quality.\r\ni)	Review and verify:\r\na.	Meeting Attendance (PG/QMS/QAC/F6162)\r\nb.	Management Review Minutes and Agenda (PG/QMS/QAC/F6161)\r\nj)	Monitor QMS Leading and Lagging Indicator (PG/QMS/QAC/F6125)\r\n1.3.2	Each Manager prepares a report to be circulated prior to the meeting, which summarizes our organization’s performance. Representation at the review includes Top management, functional management, line management, process owners, process champions, lead process users and action owners.\r\n1.3.3	Process owner have the responsibility for:\r\na)	Designating a responsible for the improvement action once the potential causes are agreed.\r\nb)	Verifying effectiveness of implementation of process flow\r\nc)	Congratulating the employee that initiated implementation of process flow\r\n1.3.4	Person in-charge have the responsibility, authority and accountability for:\r\na)	To achieve KPI that was set for this procedure\r\nb)	Ensuring staff that participate in MRM sign the attendance.\r\nc)	Prepare Management Review Minutes and Agenda (PG/QMS/QAC/F6161)\r\nd)	To execute the programs that have been set in this procedure\r\ne)	To work with the input that available at organization hence can achieve the target that have been set.\r\n1.3.5	All interested parties & employees have common responsibilities for:\r\na)	Communicate, consult & participate in the activities stated on the procedure.\r\n1.3.6	The process owner of this procedure are QMR and Quality Executive.\r\n1.3.7	The performance indicator for this procedure is MRM to be done by annually.','TABLE OF CONTENTS 2<br>1 INTRODUCTION 3<br>1.1 INTRODUCTION &amp; PURPOSE 3<br>1.2 APPLICATION &amp; SCOPE 3<br>1.3 RESPONSIBILITIES, AUTHORITIES &amp; ACCOUNTABILITIES 4<br>1.4 STRATEGIC PLAN, RISK &amp; OPPORTUNITIES, LEADING &amp; LAGGING 5<br>2 REFERENCES DOCUMENT, TERMS &amp; DEFINITION 5<br>2.1 REFERENCES DOCUMENT 5<br>2.2 TERMS &amp; DEFINITION 5<br>3 DETAILED PROCEDURE 5<br>3.1 GENERAL 5<br>3.2 DETERMINE DATE FOR MANAGEMENT REVIEW 6<br>3.3 MANAGEMENT REVIEW INPUTS 6<br>3.4 PREPARE SUMMARY DATA 6<br>3.5 CONDUCT MANAGEMENT REVIEW MEETING 6<br>3.6 MANAGEMENT REVIEW OUTPUTS 7<br>3.7 PREPARE &amp; APPROVE MANAGEMENT REVIEW MEETING MINUTES 7<br>3.8 DISTRIBUTE MANAGEMENT REVIEW MINUTES 8<br>3.9 CORRECTIVE ACTION 8<br>4 REVIEW AND VERIFY 8<br>5 CONTROL AND MONITORING 8<br>6 FORMS &amp; RECORDS 8<br>','https://mega.nz/#F!KnggxAKZ!RjD0Xe-3pMoUD0Pb5pH0QQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 13:52:47','2019-08-23 16:47:59'),(109,'6050_L3_QAC_GL601','GUIDELINE FOR DETERMINING CONTEXT OF THE ORGANIZATION','GUIDELINE FOR DETERMINING CONTEXT OF THE ORGANIZATION ( currently not available )','Quality','Guideline','00','2019-08-24',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-24 09:43:40',NULL),(110,'6050_L3_QAC_GL6011','GUIDELINE FOR DETERMINING CONTEXT OF THE ORGANIZATION','GUIDELINE FOR DETERMINING CONTEXT OF THE ORGANIZATION (currently not available )','Quality','Guideline','00','2019-09-01',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-01 20:57:42',NULL),(111,'6050_L4_QAC_F6011','INTERNAL & EXTERNAL ISSUES','INTERNAL & EXTERNAL ISSUES','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 17:14:21',NULL),(112,'6050_L4_QAC_F6012','LIST OF INTERESTED PARTIES','LIST OF INTERESTED PARTIES','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 17:17:10',NULL),(113,'6050_L4_QAC_F6013','ORGANIZATIONAL CONTEXT DIAGRAM','ORGANIZATIONAL CONTEXT DIAGRAM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 17:19:08',NULL),(114,'6050_L3_QAC_GL6021','LEADERSHIP GUIDELINE','LEADERSHIP GUIDELINE','Quality','Guideline','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 22:48:42',NULL),(115,'6050_L4_QAC_F6021','INDUCTION FORM','INDUCTION FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 22:49:58',NULL),(116,'6050_L4_QAC_F6022','DOCUMENT ACKNOWLEDGEMENT','DOCUMENT ACKNOWLEDGEMENT','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 22:52:33',NULL),(117,'6050_L3_QAC_GL6031','GUIDELINE FOR EVENT NOTIFICATION','GUIDELINE FOR EVENT NOTIFICATION ( CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-02',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 22:58:51','2019-09-02 23:30:55'),(118,'6050_L4_QAC_F6031','FORM FOR EVENT NOTIFICATION','FORM FOR EVENT NOTIFICATION ( CURRENTLY NOT AVAILABLE )','Quality','Forms','00','2019-09-02',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:00:14','2019-09-03 10:44:26'),(119,'6050_L3_QAC_GL6041','GUIDELINE FOR COMMUNICATION, CONSULTATION & PARTICIPATION','GUIDELINE FOR COMMUNICATION, CONSULTATION & PARTICIPATION ( CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-02',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:13:01','2019-09-02 23:30:06'),(120,'6050_L4_QAC_F6041','COMMUNICATION MATRIX','COMMUNICATION MATRIX','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:22:00',NULL),(121,'6050_L4_QAC_F6042','QMS ANNUAL PLAN','QMS ANNUAL PLAN','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:23:45',NULL),(122,'6050_L4_QAC_F6043','QMS OBJECTIVE & TARGET','QMS OBJECTIVE & TARGET','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:25:25',NULL),(123,'6050_L3_QAC_GL6051','GUIDELINE FOR ADDRESSING RISK & OPPORTUNITIES','GUIDELINE FOR ADDRESSING RISK & OPPORTUNITIES (CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-02',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:28:30','2019-09-02 23:29:28'),(124,'6050_L4_QAC_F6051','ADDRESSING RISK & OPPORTUNITIES REGISTER','ADDRESSING RISK & OPPORTUNITIES REGISTER','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:46:24',NULL),(125,'6050_L3_QAC_GL6061','GUIDELINE FOR MANAGEMENT OF CHANGE','GUIDELINE FOR MANAGEMENT OF CHANGE (CURRENTLY NOT AVAILABLE)','Quality','Guideline','00','2019-09-02',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:48:49',NULL),(126,'6050_L4_QAC_F6061','MANAGEMENT OF CHANGE EVALUATION FORM','MANAGEMENT OF CHANGE EVALUATION FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:52:31',NULL),(127,'6050_L3_QAC_GL6071','GUIDELINE FOR DOCUMENTED INFORMATION','GUIDELINE FOR DOCUMENTED INFORMATION ( CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-02',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:56:03',NULL),(128,'6050_L4_QAC_F6071','DOCUMENT MASTER LIST','DOCUMENT MASTER LIST','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,'DOCUMENT_MASTER_LIST.pdf','6050_L4_QAC_F6071.zip',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:57:23','2019-10-07 16:41:41'),(129,'6050_L4_QAC_F6072','DOCUMENT CHANGE NOTICE','DOCUMENT CHANGE NOTICE','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-02 23:58:29',NULL),(130,'6050_L3_QAC_GL6081','GUIDELINE FOR WORK ENVIROMENT MONITORING & CONTROL','GUIDELINE FOR WORK ENVIROMENT MONITORING & CONTROL ( CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-02',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 00:14:38',NULL),(131,'6050_L4_QAC_F6081','HYGIENE INSPECTION FORM','HYGIENE INSPECTION FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 00:16:10',NULL),(132,'6050_L4_QAC_F6082','WORK ENVIROMENT QUESTIONNAIRE','WORK ENVIROMENT QUESTIONNAIRE','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 00:20:27',NULL),(133,'6050_L3_QAC_GL6091','GUIDELINE FOR LEGAL & OTHER REQUIREMENT','GUIDELINE FOR LEGAL & OTHER REQUIREMENT ( CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-03',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 00:23:51',NULL),(134,'6050_L4_QAC_F6091','LEGAL & OTHER REQUIREMENT REGISTER','LEGAL & OTHER REQUIREMENT REGISTER','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 00:27:12',NULL),(135,'6050_L3_QAC_GL610 1','GUIDELINE FOR STAKEHOLDER SATISFACTION & FEEDBACK FORM','GUIDELINE FOR STAKEHOLDER SATISFACTION & FEEDBACK FORM ( CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-03',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 00:31:15',NULL),(136,'6050_L4_QAC_F6101','STAKEHOLDER SATISFACTION & FEEDBACK FORM','STAKEHOLDER SATISFACTION & FEEDBACK FORM ( CURRENTLY NOT AVAILABLE )','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 00:33:47',NULL),(137,'6050_L3_QAC_GL6111','GUIDELINE FOR QUALITY ASSURANCE & CONTROL OF NON-COMFORMANCE','GUIDELINE FOR QUALITY ASSURANCE & CONTROL OF NON-COMFORMANCE ( CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-03',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 00:38:12',NULL),(138,'6050_L4_QAC_F6111','FORM FOR QUALITY ASSURANCE & CONTROL OF NON-CONFORMANCE','FORM FOR QUALITY ASSURANCE & CONTROL OF NON-CONFORMANCE ( CURRENTLY NOT AVAILABLE )','Quality','Forms','00','2019-09-03',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 00:41:08',NULL),(139,'6050_L3_QAC_GL6121','GUIDELINE FOR MONITORING MEASUREMENT & ANALYSIS OF DATA','GUIDELINE FOR MONITORING MEASUREMENT & ANALYSIS OF DATA ( CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-03',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 00:43:31',NULL),(140,'6050_L4_QAC_F6121','KPI SUMMARY PLAN','KPI SUMMARY PLAN','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 09:52:58',NULL),(141,'6050_L4_QAC_F6122','KPI TRACKING TABLE','KPI TRACKING TABLE','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 09:54:42',NULL),(142,'6050_L4_QAC_F6123','MONITORING TABLE','MONITORING TABLE','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 09:57:10',NULL),(143,'6050_L4_QAC_F6124','LEADING & LAGGING INDICATOR','LEADING & LAGGING INDICATOR','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 09:59:00',NULL),(144,'6050_L3_QAC_GL6131','GUIDELINE FOR MANAGEMENT SYSTEM AUDIT','GUIDELINE FOR MANAGEMENT SYSTEM AUDIT  ( CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-03',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:02:46',NULL),(145,'6050_L4_QAC_F6131','AUDIT SCHEDULE','AUDIT SCHEDULE','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,'F6131_P3Internal_Audit_Schedule.pdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:04:10','2019-10-17 13:09:21'),(146,'6050_L4_QAC_F6132','MEMO','MEMO','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:05:05',NULL),(147,'6050_L4_QAC_F6133','AUDIT PLAN','AUDIT PLAN','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:06:29',NULL),(148,'6050_L4_QAC_F6134','AUDIT NOTES & CHECKLIST','AUDIT NOTES & CHECKLIST','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:08:01',NULL),(149,'6050_L4_QAC_F6135','AUDIT REPORT & SUMMARY','AUDIT REPORT & SUMMARY','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:09:06',NULL),(150,'6050_L3_QAC_GL6141','GUIDELINE FOR CORRECTIVE & PREVENTION ACTION REQUEST','GUIDELINE FOR CORRECTIVE & PREVENTION ACTION REQUEST (CURRENTLY NOT AVAILABLE)','Quality','Guideline','00','2019-09-03',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:13:33',NULL),(151,'6050_L4_QAC_F6141','CORRECTIVE & PREVENTIVE ACTION REQUEST FORM','CORRECTIVE & PREVENTIVE ACTION REQUEST FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:15:43',NULL),(152,'6050_L3_QAC_GL6151','GUIDELINE FOR CONTINUAL IMPROVEMENT','GUIDELINE FOR CONTINUAL IMPROVEMENT ( CURRENTLY NOT AVAILABLE )','Quality','Guideline','00','2019-09-03',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:18:21',NULL),(153,'6050_L4_QAC_F6151','CONTINUAL IMPROVEMENT FORM','CONTINUAL IMPROVEMENT FORM','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:20:05',NULL),(154,'6050_L3_QAC_GL6161','GUIDELINE FOR MANAGEMENT REVIEW','GUIDELINE FOR MANAGEMENT REVIEW  ( CURRENTLY NOT AVAILABLE )','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:23:15',NULL),(155,'6050_L4_QAC_F6161','MINUTES OF MEETING','MINUTES OF MEETING','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:24:35',NULL),(156,'6050_L4_QAC_F6162','MEETING ATTENDANCE','MEETING ATTENDANCE','Quality','Forms','1','2019-06-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-03 10:25:50',NULL),(157,'6050_L2_QAC_001','KL PETROGAS COMPANY PROFILE','KL Petrogas company profile','Quality','Manual','00','2019-10-08',NULL,NULL,'<br>',NULL,NULL,'Petrogas_-_Company_Profile.pdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-08 16:13:22',NULL);
/*!40000 ALTER TABLE `DocControl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DrillNInspection`
--

DROP TABLE IF EXISTS `DrillNInspection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DrillNInspection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DillID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DillID_unique` (`DillID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DrillNInspection`
--

LOCK TABLES `DrillNInspection` WRITE;
/*!40000 ALTER TABLE `DrillNInspection` DISABLE KEYS */;
/*!40000 ALTER TABLE `DrillNInspection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ERP`
--

DROP TABLE IF EXISTS `ERP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ERP` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Registerdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ERP`
--

LOCK TABLES `ERP` WRITE;
/*!40000 ALTER TABLE `ERP` DISABLE KEYS */;
/*!40000 ALTER TABLE `ERP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EventNotification`
--

DROP TABLE IF EXISTS `EventNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EventNotification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ENID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ENID_unique` (`ENID`),
  KEY `ccpID` (`ccpID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EventNotification`
--

LOCK TABLES `EventNotification` WRITE;
/*!40000 ALTER TABLE `EventNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `EventNotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IMSControl`
--

DROP TABLE IF EXISTS `IMSControl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IMSControl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Status` varchar(40) NOT NULL,
  `Description` text,
  `other_details` text,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IMSControl`
--

LOCK TABLES `IMSControl` WRITE;
/*!40000 ALTER TABLE `IMSControl` DISABLE KEYS */;
INSERT INTO `IMSControl` (`id`, `Status`, `Description`, `other_details`, `filed`, `last_modified`) VALUES (1,'Open','Open item for IMS Control','Initiate IMS control of record and document. This indicates that the record is check for the adequacy for record keeping','2019-06-18 20:26:10',NULL),(2,'Ongoing','Ongoing item for IMS control','Ongoing Record review for adequacy check by QA','2019-06-18 20:39:16',NULL),(3,'Pending','Pending item for IMS control','Pending Check','2019-06-18 20:40:47',NULL),(4,'Close','Close item for IMS control','Close the checking for QA record','2019-06-18 20:41:34',NULL);
/*!40000 ALTER TABLE `IMSControl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IMSDataAnalysis`
--

DROP TABLE IF EXISTS `IMSDataAnalysis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IMSDataAnalysis` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `worklocID` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `worklocID` (`worklocID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IMSDataAnalysis`
--

LOCK TABLES `IMSDataAnalysis` WRITE;
/*!40000 ALTER TABLE `IMSDataAnalysis` DISABLE KEYS */;
/*!40000 ALTER TABLE `IMSDataAnalysis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IMSReport`
--

DROP TABLE IF EXISTS `IMSReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IMSReport` (
  `Postid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Title` varchar(40) NOT NULL,
  `image` varchar(40) DEFAULT NULL,
  `TextPost` text,
  `website` varchar(200) DEFAULT NULL,
  `Ref01` varchar(40) DEFAULT NULL,
  `ClosedIssue` tinyint(4) DEFAULT '0',
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`Postid`),
  UNIQUE KEY `Title_unique` (`Title`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IMSReport`
--

LOCK TABLES `IMSReport` WRITE;
/*!40000 ALTER TABLE `IMSReport` DISABLE KEYS */;
INSERT INTO `IMSReport` (`Postid`, `Title`, `image`, `TextPost`, `website`, `Ref01`, `ClosedIssue`, `filed`, `last_modified`) VALUES (1,'NC Report here','45147200_1560860581.jpg','Dear all, appreciate to kindly report all complaint from stakeholder onto this table. \r\n\r\nthe issue shall be taken into consideration for further improvement on the organization\r\n\r\nthank you',NULL,NULL,NULL,'2019-06-18 20:23:01',NULL);
/*!40000 ALTER TABLE `IMSReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IMStrackingNmonitoring`
--

DROP TABLE IF EXISTS `IMStrackingNmonitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IMStrackingNmonitoring` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `WorklocID` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `WorklocID` (`WorklocID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IMStrackingNmonitoring`
--

LOCK TABLES `IMStrackingNmonitoring` WRITE;
/*!40000 ALTER TABLE `IMStrackingNmonitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `IMStrackingNmonitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InOutRegister`
--

DROP TABLE IF EXISTS `InOutRegister`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `InOutRegister` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecordNumber` varchar(40) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` varchar(255) NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Delivdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecordNumber_unique` (`RecordNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InOutRegister`
--

LOCK TABLES `InOutRegister` WRITE;
/*!40000 ALTER TABLE `InOutRegister` DISABLE KEYS */;
INSERT INTO `InOutRegister` (`id`, `RecordNumber`, `DocItem`, `fo_DocumentDescription`, `fo_Classification`, `fo_Delivdate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (2,'3030_001','Issued For Reviewed POTCH-DD-KLP-PGRO-ENG-DWG-010RevA TRENCH BACKFILLING SCHEMATIC ON LAND','Issued For Reviewed POTCH-DD-KLP-PGRO-ENG-DWG-010RevA TRENCH BACKFILLING SCHEMATIC ON LAND','Incoming','2019-03-26',NULL,'TRENCH BACKFILLING SCHEMATIC ON\r\nLAND ISSUE FOR REVIEW','<br>','https://mega.nz/#F!i6oRwIBD!9zabsS-a9J90qeNO-wIP0g',NULL,NULL,NULL,'24780700_1567759610.jpeg',2,NULL,NULL,NULL,2,NULL,'2019-09-06 16:46:50','2019-09-06 16:57:24'),(3,'3030_002','Issued For Reviewed POTCH-DD-KLP-PGRO-ENG-PRC-004RevA RIVER BANK PROTECTION CONSTRUCTION PROCEDURE','Issued For Reviewed POTCH-DD-KLP-PGRO-ENG-PRC-004RevA RIVER BANK PROTECTION CONSTRUCTION PROCEDURE','Incoming','2019-03-27',NULL,'RIVER BANK PROTECTION CONSTRUCTION PROCEDURE ISSUE FOR REVIEW','<br>','https://mega.nz/#F!b2p3nYpD!fFSEM4R2s5h8ngzl6kTV5g',NULL,NULL,NULL,'67162100_1567759879.jpeg',2,NULL,NULL,NULL,2,NULL,'2019-09-06 16:51:19','2019-09-06 16:56:57'),(4,'3030_003','Issued For Reviewed POTCH-DD-KLP-PGRO-ENG-DWG-012RevA TRENCH BACKFILLING SCHEMATIC AT SELAT MENDANA','Issued For Reviewed POTCH-DD-KLP-PGRO-ENG-DWG-012RevA TRENCH BACKFILLING SCHEMATIC AT SELAT MENDANA','Incoming','2019-03-28',NULL,'TRENCH BACKFILLING SCHEMATIC AT SELAT MENDANA ISSUE FOR REVIEW','<br>','https://mega.nz/#F!Py5lmKJZ!ZPzLMUIY6asMuSHZXmYp2A',NULL,NULL,NULL,'22677400_1567760149.jpeg',2,NULL,NULL,NULL,2,NULL,'2019-09-06 16:55:49','2019-09-06 16:57:11'),(5,'3030_004','Issued For Reviewed POTCH-EXE-KLP-PGRO-HSE-JMS-001RevA JOB METHOD STATEMENT POST TRENCHING','Issued For Reviewed POTCH-EXE-KLP-PGRO-HSE-JMS-001RevA JOB METHOD STATEMENT POST TRENCHING','Incoming','2019-03-28',NULL,NULL,'<br>','https://mega.nz/#F!q65FDAxA!x4DjQ9HP8_QfNykd3CURyg',NULL,'KLP-A-014.pdf',NULL,'96587400_1569409230.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-25 18:58:31','2019-09-25 19:00:30'),(6,'3030_005','Issued For Reviewed POTCH-DD-KLP-PGRO-ENG-RPT-009RevA RIVER BANK PROTECTION DESIGN','Issued For Reviewed POTCH-DD-KLP-PGRO-ENG-RPT-009RevA RIVER BANK PROTECTION DESIGN','Incoming','2019-03-29',NULL,NULL,'<br>','https://mega.nz/#F!Ki4jXKDT!LGrFrf0OTDxGK6ZaJCNmqg',NULL,'KLP-A-014.pdf',NULL,'43237000_1569409475.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-25 19:04:35',NULL),(7,'3030_006','Issued For Approval POTCH-DD-KLP-PGRO-ENG-RPT-004RevB BACKFILLING CALCULATION','Issued For Approval POTCH-DD-KLP-PGRO-ENG-RPT-004RevB BACKFILLING CALCULATION','Incoming','2019-04-02',NULL,NULL,'<br>','https://mega.nz/#F!K6BglKLD!mzLoExq7Je3M7GbtJHHxrA',NULL,'KLP-A-014.pdf',NULL,'35616300_1569409686.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-25 19:08:06',NULL),(8,'3030_007','Issued For Approval POTCH-DD-KLP-PGRO-ENG-PRC-002RevB BACKFILLING PROCEDURE','Issued For Approval POTCH-DD-KLP-PGRO-ENG-PRC-002RevB BACKFILLING PROCEDURE','Incoming','2019-04-05',NULL,NULL,'<br>','https://mega.nz/#F!q6xlgaJQ!hGs3-Q3eruNbyXo2hW21zw',NULL,'KLP-A-014.pdf',NULL,'11575800_1569409804.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-25 19:10:04',NULL),(9,'3030_008','Issued For Reviewed POTCH-DD-KLP-PGRO-ENG-LYT-001RevA OVERALL LAYOUT AT KG. SUNGAI LATOH, SELAT  MENDANA, PULAU JULING & SG. JOHOR','Issued For Reviewed POTCH-DD-KLP-PGRO-ENG-LYT-001RevA OVERALL LAYOUT AT KG. SUNGAI LATOH, SELAT  MENDANA, PULAU JULING & SG. JOHOR','Incoming','2019-04-15',NULL,NULL,'<br>','https://mega.nz/#F!j65ywQ7B!8wHDc9Slo5G8DftS1bsjhw',NULL,'KLP-A-014.pdf',NULL,'37080200_1569409985.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-25 19:13:05',NULL);
/*!40000 ALTER TABLE `InOutRegister` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IncidentReporting`
--

DROP TABLE IF EXISTS `IncidentReporting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IncidentReporting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IncidentReporting`
--

LOCK TABLES `IncidentReporting` WRITE;
/*!40000 ALTER TABLE `IncidentReporting` DISABLE KEYS */;
/*!40000 ALTER TABLE `IncidentReporting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Inquiry`
--

DROP TABLE IF EXISTS `Inquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Inquiry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `InqNumber` varchar(100) NOT NULL,
  `ClientID` int(10) unsigned DEFAULT NULL,
  `fo_InquiryDate` date DEFAULT NULL,
  `fo_DueDate` date DEFAULT NULL,
  `fo_kelasifikasi` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_DeliveryDate` date DEFAULT NULL,
  `fo_Logistic` int(11) unsigned DEFAULT NULL,
  `fo_Freight` float(10,2) DEFAULT '0.00',
  `fo_ShipName` int(10) unsigned DEFAULT NULL,
  `fo_ShipAddress` int(10) unsigned DEFAULT NULL,
  `fo_ShipCity` int(10) unsigned DEFAULT NULL,
  `fo_ShipRegion` int(10) unsigned DEFAULT NULL,
  `fo_ShipPostalCode` int(10) unsigned DEFAULT NULL,
  `fo_ShipCountry` int(10) unsigned DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `InqNumber_unique` (`InqNumber`),
  KEY `ClientID` (`ClientID`),
  KEY `fo_Logistic` (`fo_Logistic`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Inquiry`
--

LOCK TABLES `Inquiry` WRITE;
/*!40000 ALTER TABLE `Inquiry` DISABLE KEYS */;
INSERT INTO `Inquiry` (`id`, `InqNumber`, `ClientID`, `fo_InquiryDate`, `fo_DueDate`, `fo_kelasifikasi`, `fo_DeliveryDate`, `fo_Logistic`, `fo_Freight`, `fo_ShipName`, `fo_ShipAddress`, `fo_ShipCity`, `fo_ShipRegion`, `fo_ShipPostalCode`, `fo_ShipCountry`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'2040_001',2,'2019-08-09','2019-08-19','Tender Bidding','2019-09-30',NULL,0.00,2,2,2,2,2,2,NULL,'PROVISION OF OFFLOADING FLOATING HOSE INSPECTION AND MAINTENANCE','<br>','https://mega.nz/#F!ruxUTCZY!He1WANKbZCvwJ2Dif7I2CA',NULL,NULL,NULL,'00368000_1566961328.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 14:44:23','2019-08-28 11:17:51'),(2,'2040_002',3,'2019-08-27','2019-08-27','Tender Bidding',NULL,NULL,0.00,3,3,3,3,3,3,'F202','PROVISION OF ENGINEERING, PROCUREMENT, CONSTRUCTION & COMMISSIONING (EPCIC) FOR PM9 SIMPLIFICATION PROJECT.','<br>',NULL,NULL,NULL,NULL,'59757400_1566960995.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-27 15:15:24','2019-08-28 11:13:57'),(3,'2040_003',4,'2019-08-28','2019-04-27','Tender Bidding',NULL,NULL,0.00,4,4,4,4,4,4,'F202','PROVISION OF ENGINEERING, PROCUREMENT, CONSTRUCTION, INSTALLATION & PRE-COMMISSIONING OF PIPELINE SYSTEM FOR TEMBIKAI NON-ASSOCIATED GAS (TNAG) DEVELOPMENT','<br>',NULL,NULL,NULL,NULL,'68715100_1566961933.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-28 11:10:42','2019-09-05 23:49:06'),(4,'2040_004',7,'2019-07-05','2019-07-11','Email',NULL,NULL,0.00,7,7,7,7,7,7,NULL,'Wind Turbine TLP Installation','<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 22:48:26','2019-09-05 22:49:38'),(5,'2040_005',9,'2019-08-28','2019-09-03','Market Survey',NULL,NULL,0.00,9,9,9,9,9,9,NULL,'Screening Questionnaires Exercise for Provision of Engineering, Procurement, Construction and Installation (EPCI) for Pipeline Replacement Project','To replace rigid pipeline to flexible pipeline',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 22:56:30','2019-09-26 10:37:13'),(6,'2040_006',8,'2019-09-17','2019-09-17','Tender Bidding',NULL,1,0.00,8,8,8,8,8,8,NULL,'PROVISIONS OF CARGO OIL TANK & PRESSURE VESSEL DEMUCKING AND CLEANING SERVICES (WEST MALAYSIA)','<br>','https://mega.nz/#F!YWhixC7I!91ioSIvWO3FnD46f9SVSMQ',NULL,'SOW_PV_CLEANING.pdf','2040_006.zip','88427900_1569310749.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-17 16:06:01','2019-09-25 15:52:42'),(7,'2040_007',10,'2019-09-17','2019-09-11','Market Survey',NULL,1,0.00,10,10,10,10,10,10,NULL,'PROVISION OF MINI ROV EQUIPMENT AND SERVICES','<br>','https://mega.nz/#F!ZfQj1IYJ!4uj4sS-pAaru9nRLT6xJGA',NULL,'REPSOL_MINI_ROV.pdf',NULL,'96547200_1569310087.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-17 16:13:31','2019-09-25 15:51:13'),(8,'2040_008',6,'2019-09-18','2019-09-18','Tender Bidding',NULL,1,0.00,6,6,6,6,6,6,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-18 12:04:04',NULL),(9,'2040_009',9,'2019-09-23','2019-10-21','Tender Bidding',NULL,1,0.00,9,9,9,9,9,9,NULL,'PROVISION OF MAINTENANCE SERVICES FOR SINGLE POINT MOORING (SPM) AND SUPPLY OF MARINE HOSES FOR PETRONAS GROUP OF COMPANIES','<div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal; text-align: center;\"><b><u>TABLE OF CONTENT</u></b></div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\"><b><u>SECTION A</u> BID ACKNOWLEDGEMENT 4</b></div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\"><br></div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\"><b>SECTION B INSTRUCTIONS TO BIDDER 6</b></div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B1 PURPOSE OF INSTRUCTIONS 7</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B2 INTRODUCTION 7</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B3 BID ACKNOWLEDGEMENT 8</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B4 THE OPTIONS AND PACKAGE OF THE TENDER 8</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B5 PREPARATION OF BID PROPOSAL 10</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B6 BID VALIDITY 10</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B7 PRICE QUOTATIONS 11</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B8 CONTRACT EXCEPTIONS 13</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B9 SUBMISSION OF PROPOSALS 13</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B10 CONSIDERATION OF BID PROPOSAL 16</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B11 FACE-TO-FACE CLARIFICATIONS WITH BIDDER 17</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B12 ACCEPTANCE 17</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B13 BANK GUARANTEE (BG) 17</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B14 TAXES 17</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B15 PETRONAS LICENSE AND OTHER REQUIREMENTS 19</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B16 LOCAL CONTENT 20</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">B17 MISCELLANEOUS 20</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\"><br></div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\"><b>SECTION C TECHNICAL PROPOSAL SUBMISSION 22</b></div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">GENERAL 23</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 1 COVER LETTER 24</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">PROPOSAL FORM AND COMPLIANCE WITH ITB &amp; SCOPE OF WORKS 24</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">PETRONAS LICENSE 24</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 2 BIDDER’S QUESTIONNAIRE 27</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 3 COMPLIANCE TO TECHNICAL SPECIFICATIONS AND THE SCOPE OF WORKS 34</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 4 BIDDER’S WORK EXPERIENCE 35</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 5 CURRENT AND PROJECTED WORKLOAD 37</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 6 EXPERIENCE OF MARINE SPREAD LEASING 38</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 7 KEY PERSONNEL 36</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 8 EQUIPMENT: SURFACE SUPPLIED AIR DIVING SYSTEM 41</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 9 OPERATION BASE, SITE OFFICE AND STORAGE FACILITIES 42</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 10 BIDDER’S PROPOSED SUBCONTRACTOR(S) AND PART(S) OF THE WORK 43</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 11 HSE REQUIREMENTS 44</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 12 EXCEPTIONS TO TENDER/CONTRACT SCOPE OF WORKS AND TERMS &amp;&nbsp;<span style=\"font-size: 11.93px;\">CONDITIONS</span><span style=\"font-size: 11.93px;\">55</span></div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 13 PROPOSED ALTERNATIVES 53</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 14 INSURANCE 54</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 15 BIDDER’S COMMERCIAL INFORMATION/FINANCIAL REPORT 55</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 16 QUALITY ASSURANCE/QUALITY CONTROL (QA/QC) FOR PETRONAS CARIGALI&nbsp;<span style=\"font-size: 11.93px;\">SDN. BHD.&nbsp;</span><span style=\"font-size: 11.93px;\">58</span></div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 17 LOCAL CONTENT 60</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 18 UNPRICED COMMERCIAL PROPOSAL 61</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 19 TAXES RELATED INFORMATION 62</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 20 TECHNICAL BID SUBMISSION CHECKLIST 63</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\"><br></div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\"><b>SECTION D COMMERCIAL PROPOSAL SUBMISSION 63</b></div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 21 COVER LETTER 64</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 22 EXHIBIT III – CONTRACT PRICE 65</div><div style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\"><span style=\"font-size: 11.93px; font-variant-numeric: normal; font-variant-east-asian: normal;\">APP 23 COMMERCIAL BID SUBMISSION CHECKLIST 67</span><br></div>','https://mega.nz/#F!cDhWkQBI!c4RlgkZdh6kdAtqAxpTj7g',NULL,NULL,NULL,'05526500_1569309360.jpg',2,NULL,NULL,NULL,2,NULL,'2019-09-23 09:53:34','2019-09-26 09:33:53'),(10,'2040_010',11,'2019-09-20','2019-10-11','Tender Bidding',NULL,1,0.00,11,11,11,11,11,11,NULL,'INVITATION TO BID FOR PROVISION OF ENGINEERING, PROCUREMENT, CONSTRUCTION,  INSTALLATION AND COMMISSIONING (EPCIC) FOR PL429 PIPELINE REPLACEMENT PROJECT (PCSB)','<div style=\"font-size: 11.998px;\">TABLE OF CONTENTS</div><div style=\"font-size: 11.998px;\">PART I – TENDER INSTRUCTIONS</div><div style=\"font-size: 11.998px;\">Section 1 : ACKNOWLEDGEMENT OF TENDER</div><div style=\"font-size: 11.998px;\">Section 2 : INSTRUCTIONS AND INFORMATION TO BIDDER</div><div style=\"font-size: 11.998px;\">Section 3 : TECHNICAL PROPOSAL SUBMISSION</div><div style=\"font-size: 11.998px;\"><br></div><div style=\"font-size: 11.998px;\">PART II – CONTRACT DOCUMENT</div><div style=\"font-size: 11.998px;\">1. TERMS AND CONDITIONS OF CONTRACT</div><div style=\"font-size: 11.998px;\">2. SCOPE OF WORK&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EXHIBIT I</div><div style=\"font-size: 11.998px;\">3. TECHNICAL SPECIFICATION&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; EXHIBIT II</div><div style=\"font-size: 11.998px;\">4. SCHEDULE OF WORKS&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EXHIBIT III</div><div style=\"font-size: 11.998px;\">5. SCHEDULE OF COMPENSATION&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EXHIBIT IV</div><div style=\"font-size: 11.998px;\">6. ADMINISTRATIVE PROCEDURES&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; EXHIBIT V</div><div style=\"font-size: 11.998px;\">7. CONTRACTOR ORGANIZATION &amp; PROJECT TEAM KEY</div><div style=\"font-size: 11.998px;\">&nbsp; &nbsp; PERSONNEL&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EXHIBIT VI</div><div style=\"font-size: 11.998px;\">8. LIST OF PROPOSED MANUFACTURES/SUBCONTRACTORS&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EXHIBIT VII</div><div style=\"font-size: 11.998px;\">9. QUALITY ASSURANCE PROGRAM REQUIREMENT&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EXHIBIT VIII</div><div style=\"font-size: 11.998px;\">10 HEALTH, SAFETY AND ENVIRONMENT REQUIREMENTS&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;EXHIBIT IX</div><div style=\"font-size: 11.998px;\">11. OBLIGATIONS OF PARTIES EXHIBIT X</div><div style=\"font-size: 11.998px;\">12. BANK GUARANTEE AND PERFORMANCE GUARANTEE&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; EXHIBIT XI</div><div style=\"font-size: 11.998px;\">13. PARENT/PRINCIPAL GUARANTEE AND RETENTION SUM&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; EXHIBIT XII</div>','https://mega.nz/#F!1bhGEQ5S!Hw_uO8bQqJ_Tt862LzrXvQ',NULL,NULL,NULL,'31984100_1569305847.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-24 10:00:49','2019-10-25 12:40:29'),(11,'2040_011',11,'2019-09-26','2019-10-02','Market Survey',NULL,1,0.00,11,11,11,11,11,11,NULL,'SCREENING EXERCISE: PROVISION OF ENGINEERING, PROCUREMENT, CONSTRUCTION, INSTALLATION & COMMISSIONING (EPCIC) FOR SUBSEA WELL TIE BACK DEVELOPMENT AT PM309 FIELD (PMA).','<div>PETRONAS Carigali Sdn Bhd is conducting a screening exercise for the above subject under the following work category(s):</div><div><b></b><br></div><ul><li><b>&nbsp;PS3010100</b> - To design, manufacture, assemble, test, supply, deliver, install, hook-up, commissioning of Subsea Wellhead &amp; Christmas Tree, Installation &amp; Workover Control System (IWOCS), wellhead equipment, running tools, consumables and spare parts, connection system with qualified personnel including provision of engineering services.</li><li><b>SO2010106</b> -The provision of PMT, Transportation &amp; Installation Engineering, Procedure (including welding), Construction marine spread, pipe stringing, facilities inclusive of construction equipment, diving spread, qualified personnel, rigging, survey and positioning, ROV, field joint coating, NDT consumables and other installation aids required for offshore installation and pre-commissioning.<br></li></ul>',NULL,NULL,NULL,NULL,'76034100_1569600774.jpeg',NULL,NULL,NULL,NULL,2,NULL,'2019-09-28 00:09:06','2019-09-28 15:10:25'),(12,'2040_012',12,'2019-10-08','2019-10-16','Tender Bidding','2019-11-01',1,0.00,12,12,12,12,12,12,NULL,'PROVISION OF TRANSPORTATION & INSTALLATION FOR BUNDLE 4  OWF (OFFSHORE WELLHEAD FACILITIES) PROJECTS','<br>','https://mega.nz/#F!NSwWDQzL!jqwalck4a0xPkGkF5GcUkA',NULL,'RFQ_T&I_MMHE_BUNDLE_4_OWF.pdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-16 18:12:58','2019-10-16 18:18:03'),(13,'2040_013',3,'2019-10-25','2019-10-31','Tender Bidding',NULL,1,0.00,3,3,3,3,3,3,NULL,NULL,'<br>',NULL,NULL,'Exhibit_1_Scope_of_Work.pdf',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-25 16:35:24',NULL);
/*!40000 ALTER TABLE `Inquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Inventory`
--

DROP TABLE IF EXISTS `Inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Inventory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `InventoryID` varchar(100) NOT NULL,
  `asstitle` varchar(256) DEFAULT NULL,
  `Description` text,
  `fo_Type` varchar(100) DEFAULT NULL,
  `fo_Manufacturer` varchar(250) DEFAULT NULL,
  `fo_ModelNumber` varchar(250) DEFAULT NULL,
  `fo_SerialNumber` varchar(250) DEFAULT NULL,
  `fo_Condition` text,
  `fo_history` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_Quantity` int(11) DEFAULT '0',
  `fo_UnitPrice` float(10,2) DEFAULT '0.00',
  `fo_Remarks` text,
  `fo_date` date DEFAULT NULL,
  `fo_ItemLocation` varchar(100) DEFAULT NULL,
  `fo_image` varchar(40) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `InventoryID_unique` (`InventoryID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Inventory`
--

LOCK TABLES `Inventory` WRITE;
/*!40000 ALTER TABLE `Inventory` DISABLE KEYS */;
INSERT INTO `Inventory` (`id`, `InventoryID`, `asstitle`, `Description`, `fo_Type`, `fo_Manufacturer`, `fo_ModelNumber`, `fo_SerialNumber`, `fo_Condition`, `fo_history`, `fo_Quantity`, `fo_UnitPrice`, `fo_Remarks`, `fo_date`, `fo_ItemLocation`, `fo_image`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_last_modified`) VALUES (6,'5030_001','NOT APPLICABLE','<span style=\'display: inline !important; float: none; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: \"Open Sans\",sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\'>Generic initial item to define non applicability to the Request order form</span><br>','Others','NA','NA','NA','Operational Ready','None',0,0.00,NULL,'2019-09-04','KL PETROGAS HQ',NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 14:48:52','2019-09-17 11:22:57'),(7,'5030_002','OTHERS: Outsourced Services','<span style=\'display: inline !important; float: none; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: \"Open Sans\",sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\'>Deliverables and subcontract for outsourced services</span><br>','Others','Others','0909','193','Functional','New',1,100000.00,NULL,'2019-09-04',NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 14:54:44','2019-09-17 11:33:45'),(8,'5030_003','OTHERS: Company & Corporate requirement','<span style=\'display: inline !important; float: none; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: \"Open Sans\",sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\'>Generic and company statutory</span>.','Asset','Internal',NULL,NULL,'Functional','New',1,20000.00,NULL,'2019-09-04',NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 14:58:24','2019-09-17 11:42:18'),(9,'5030_004','HP OFFICEJET 7612 COLOR PRINTER','HP color printer for office use','Asset','HP','G1X85-64001','CN8644R0G2','Functional','New',1,500.00,NULL,'2019-09-04',NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'09513200_1567580551.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 15:01:57','2019-09-06 11:33:28'),(10,'5030_005','RICOH AFICIO MP SERIES BLACK & WHITE PRINTER','Ricoh black and white printer for office use.','Asset','RICOH','DF83','K7567406935','Functional','New',1,1000.00,NULL,'2019-09-04',NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'50903400_1567580816.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 15:06:28','2019-09-06 11:34:26'),(11,'5030_006','CANON PIXMA E510 COLOR PRINTER','Canon color printer for office use.','Asset','CANON',NULL,'LRHF36721','Functional','New',1,250.00,NULL,'2019-09-04',NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'87339400_1567581153.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 15:11:02','2019-09-06 11:34:01'),(12,'5030_007','ACER DESKTOP','<span style=\'display: inline !important; float: none; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: \"Open Sans\",sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\'>General purpose work desktop</span><br>','Asset','ACER','K222HQL','MMT0ESS00144705A8D8512','Functional','New',1,3000.00,NULL,'2019-09-17','KL PETROGAS HQ',NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'46369300_1568690473.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-17 11:21:13',NULL),(13,'5030_008','DELL MONITOR','<span style=\'display: inline !important; float: none; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: \"Open Sans\",sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\'>General purpose work monitor</span><br>','Asset','DELL','10047200','CN-02G4HX-74445-05T-A0BU','Functional','New',1,300.00,NULL,'2019-09-17','KL PETROGAS MAIN HQ',NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'13495700_1568691107.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-17 11:31:47',NULL),(14,'5030_009','SHARP TV SCREEN','<span style=\'display: inline !important; float: none; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: \"Open Sans\",sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\'>Sharp TV screen for presentation and work purposes.</span><br>','Asset','SHARP','501727310','LC-40LE265M','Functional','New',1,2000.00,NULL,'2019-09-17','KL PETROGAS MAIN HQ',NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'30137000_1568691654.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-17 11:40:54','2019-09-17 11:42:27');
/*!40000 ALTER TABLE `Inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Item`
--

DROP TABLE IF EXISTS `Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Item` (
  `ProductID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` varchar(200) NOT NULL,
  `ProductName` varchar(50) DEFAULT NULL,
  `fo_SupplierID` int(11) unsigned DEFAULT NULL,
  `fo_CategoryID` int(11) DEFAULT NULL,
  `fo_QuantityPerUnit` varchar(50) DEFAULT NULL,
  `fo_UnitPrice` float(10,2) DEFAULT '0.00',
  `fo_UnitsInStock` smallint(6) DEFAULT '0',
  `fo_UnitsOnOrder` smallint(6) DEFAULT '0',
  `fo_ReorderLevel` smallint(6) DEFAULT '0',
  `fo_Description` text,
  `fo_Discontinued` tinyint(4) DEFAULT '0',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`ProductID`),
  UNIQUE KEY `ItemID_unique` (`ItemID`),
  KEY `fo_SupplierID` (`fo_SupplierID`),
  KEY `fo_CategoryID` (`fo_CategoryID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Item`
--

LOCK TABLES `Item` WRITE;
/*!40000 ALTER TABLE `Item` DISABLE KEYS */;
INSERT INTO `Item` (`ProductID`, `ItemID`, `ProductName`, `fo_SupplierID`, `fo_CategoryID`, `fo_QuantityPerUnit`, `fo_UnitPrice`, `fo_UnitsInStock`, `fo_UnitsOnOrder`, `fo_ReorderLevel`, `fo_Description`, `fo_Discontinued`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'4020_001','NOT APLICABLE',1,1,'1',0.00,0,0,0,'<br>',NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'2019-08-04 09:49:10',NULL);
/*!40000 ALTER TABLE `Item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JD_JS`
--

DROP TABLE IF EXISTS `JD_JS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JD_JS` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecordNumber` varchar(40) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` varchar(255) NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_ProjectTeamID` int(11) DEFAULT NULL,
  `fo_JDDesc` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecordNumber_unique` (`RecordNumber`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `fo_ProjectTeamID` (`fo_ProjectTeamID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JD_JS`
--

LOCK TABLES `JD_JS` WRITE;
/*!40000 ALTER TABLE `JD_JS` DISABLE KEYS */;
/*!40000 ALTER TABLE `JD_JS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KM`
--

DROP TABLE IF EXISTS `KM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KM` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocumentName` varchar(250) NOT NULL,
  `fo_Description` text,
  `fo_Reference` varchar(40) NOT NULL,
  `fo_Volume` varchar(100) NOT NULL,
  `fo_Classification` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_Class` varchar(100) DEFAULT 'Unknown',
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocumentName_unique` (`DocumentName`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KM`
--

LOCK TABLES `KM` WRITE;
/*!40000 ALTER TABLE `KM` DISABLE KEYS */;
INSERT INTO `KM` (`id`, `DocumentName`, `fo_Description`, `fo_Reference`, `fo_Volume`, `fo_Classification`, `fo_Class`, `fo_Regdate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'6020_001_VERTICAL XMAS TREE ONESUBSEA','Standard Vertical Subsea Xmas / Christmas Tree brochure by OneSubsea','External Reference','0','E-Book','Technical','2019-09-28',NULL,'OneSubsea can design and deliver standard vertical subsea trees anywhere globally within 18 months and the tubing head spool (THS) in 12 months.','<br>','https://mega.nz/#F!taBhFQpL!sg56PBaRouALbnKKHQtl8w',NULL,'Vertical_Monobore_XT.pdf',NULL,'34062500_1569672949.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-28 20:12:44','2019-09-28 20:26:14'),(2,'6020_002_WELLHEAD TECHNIPFMC','Wellhead design brochure by TechnipFMC','External Reference','0','E-Book','Technical','2019-09-28',NULL,NULL,'<br>','https://mega.nz/#F!gSZRhSSL!DnEkHmIworg3zbLkWEhr_A',NULL,'WELLHEAD_TECHNIP.PDF',NULL,'53895500_1569673892.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-28 20:30:05','2019-09-28 20:51:19'),(3,'6020_003_WELLHEAD XMAS TREE SOLAR ALERT','Wellhead and Xmas tree product brochure by Solar Alert','External Reference','0','Presentation','Technical','2019-09-30',NULL,NULL,'<br>','https://mega.nz/#F!ICQBgAJS!V9oAlGQy4T2Ql1UTXVAZgQ',NULL,'Wellhead_&_Xmas_Tree.pdf',NULL,'08817200_1569836471.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-30 17:39:43','2019-09-30 17:43:39'),(4,'6020_004_AKER SOLUTIONS XMAS TREE','Web link for Subsea Xmas tree by Aker Solutions','External Reference','0','Reference','Technical','2019-10-01',NULL,NULL,'<br>','https://akersolutions.com/what-we-do/products-and-services/subsea-trees/',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-01 10:20:29',NULL),(5,'6020_005_INTERNAL LIFTING TOOL IHC (ILT)','Internal Lifting Tool (ILT) by IHC\r\n1. ILT 24-42\" 250T\r\n2. ILT 42-60\" 500T\r\n3. ILT 60-96\" 1200T','External Reference','0','Reference','Technical','2019-10-16',NULL,NULL,'<br>',NULL,NULL,NULL,'ILT_IHC.zip',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-16 18:30:39',NULL),(6,'6020_006_MARINE VESSEL SPREAD LIST','MARINE VESSEL SPREAD LIST','External Reference','0','E-Book','Technical','2019-10-16',NULL,NULL,'1. EOS 281 CARGO BARGE<br>2. EXPRESS 54 CREW BOAT<br><div>3. FORTUNA DLB</div><div>4. FORTUNA DLB (FULL)</div><div>5. MEO MONARCH 1 OSV</div><div>6. MEO MONARCH 2 OSV</div><div>7. MICLYN 258 CARGO BARGE&nbsp;</div><div>8. MICLYN 259 CARGO BARGE</div><div>9. MICLYN EMPEROR AHTS</div><div>10. MICLYN ORION AHT</div><div>11. MICLYN VICTORY AHT</div><div>12. SEISMIC SUPPORTER SSV</div>','https://mega.nz/#F!NGhSgYiY!12CDqwoQFeXPgRNaEmEeMw',NULL,NULL,'VESSEL_TYPES.zip',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-16 18:35:49','2019-10-16 18:39:42');
/*!40000 ALTER TABLE `KM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Leadership`
--

DROP TABLE IF EXISTS `Leadership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Leadership` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Status` varchar(40) NOT NULL,
  `Description` text,
  `other_details` text,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Leadership`
--

LOCK TABLES `Leadership` WRITE;
/*!40000 ALTER TABLE `Leadership` DISABLE KEYS */;
INSERT INTO `Leadership` (`id`, `Status`, `Description`, `other_details`, `filed`, `last_modified`) VALUES (1,'Open','Open Item for Review and verification',NULL,'2019-08-03 13:17:14',NULL),(2,'Ongoing','Ongoing Item for Review and verification',NULL,'2019-08-03 13:18:20',NULL),(3,'Pending','Pending Item for Review and verification',NULL,'2019-08-03 13:38:53',NULL);
/*!40000 ALTER TABLE `Leadership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LegalRegister`
--

DROP TABLE IF EXISTS `LegalRegister`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LegalRegister` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LRNumber` varchar(40) NOT NULL,
  `LegalItem` varchar(255) NOT NULL,
  `fo_LRDescription` text,
  `fo_Classification` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_Class` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `LRNumber_unique` (`LRNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LegalRegister`
--

LOCK TABLES `LegalRegister` WRITE;
/*!40000 ALTER TABLE `LegalRegister` DISABLE KEYS */;
/*!40000 ALTER TABLE `LegalRegister` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LogisticRequest`
--

DROP TABLE IF EXISTS `LogisticRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LogisticRequest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LogisticNumber` varchar(100) NOT NULL,
  `Market_Survey` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_ResourcesID` int(10) unsigned DEFAULT NULL,
  `fo_ProjectID` int(10) unsigned DEFAULT NULL,
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `fo_Deliverydate` date DEFAULT NULL,
  `fo_address` text,
  `fo_city` varchar(40) DEFAULT NULL,
  `fo_zip` char(8) DEFAULT NULL,
  `fo_Countrys` varchar(100) DEFAULT NULL,
  `fo_homephone` varchar(40) DEFAULT NULL,
  `fo_workphone` varchar(40) DEFAULT NULL,
  `fo_contactperson` varchar(100) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `LogisticNumber_unique` (`LogisticNumber`),
  KEY `fo_ResourcesID` (`fo_ResourcesID`),
  KEY `fo_ProjectID` (`fo_ProjectID`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LogisticRequest`
--

LOCK TABLES `LogisticRequest` WRITE;
/*!40000 ALTER TABLE `LogisticRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `LogisticRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Logistics`
--

DROP TABLE IF EXISTS `Logistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Logistics` (
  `ShipperID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `LogisticID` varchar(200) NOT NULL,
  `CompanyName` varchar(200) NOT NULL,
  `fo_AVList` tinyint(4) DEFAULT '0',
  `fo_Phone` varchar(24) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`ShipperID`),
  UNIQUE KEY `LogisticID_unique` (`LogisticID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Logistics`
--

LOCK TABLES `Logistics` WRITE;
/*!40000 ALTER TABLE `Logistics` DISABLE KEYS */;
INSERT INTO `Logistics` (`ShipperID`, `LogisticID`, `CompanyName`, `fo_AVList`, `fo_Phone`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_last_modified`) VALUES (1,'5020_001','GENERAL FREIGHT AGENT',1,NULL,NULL,'This option made available if the mode of transportation can be source via non specific logistic arrangement','<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 09:53:54','2019-08-26 14:41:22');
/*!40000 ALTER TABLE `Logistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MRM`
--

DROP TABLE IF EXISTS `MRM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MRM` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MRM`
--

LOCK TABLES `MRM` WRITE;
/*!40000 ALTER TABLE `MRM` DISABLE KEYS */;
INSERT INTO `MRM` (`id`, `DocconNumber`, `DocItem`, `fo_DocumentDescription`, `fo_Classification`, `fo_Impact`, `fo_Regdate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'6180_001','MANAGEMENT REVIEW MEETING FOR QMS','To evaluate overall QMS effectiveness. Actions arising from the management review are noted on the Action items page of the checklist. All subjects must be reviewed at least quarterly, bi-annually or annually as required. Each Manager prepares a report to be circulated prior to the meeting, which summarizes our organization\'s performance. Forward minutes of the management review meeting to those on the distribution list and those with actions.','Internal M','Quality','2019-09-18','P616',NULL,'<br>',NULL,NULL,'MANAGEMENT_REVIEW_MINUTE_OF_MEETING.pdf',NULL,'56250600_1568788098.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-18 14:26:22','2019-09-18 14:39:41');
/*!40000 ALTER TABLE `MRM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWConditionBased`
--

DROP TABLE IF EXISTS `MWConditionBased`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWConditionBased` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CondBaseID` varchar(200) NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CondBaseID_unique` (`CondBaseID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWConditionBased`
--

LOCK TABLES `MWConditionBased` WRITE;
/*!40000 ALTER TABLE `MWConditionBased` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWConditionBased` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWO`
--

DROP TABLE IF EXISTS `MWO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWO` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `MWONumber` varchar(200) NOT NULL,
  `Critical` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_InventoryID` int(10) unsigned DEFAULT NULL,
  `fo_Task` text NOT NULL,
  `fo_Category` text NOT NULL,
  `fo_JobInstruction` text NOT NULL,
  `fo_DetailInstruction` text,
  `fo_Resources` text,
  `fo_Duedate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MWONumber_unique` (`MWONumber`),
  KEY `fo_InventoryID` (`fo_InventoryID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWO`
--

LOCK TABLES `MWO` WRITE;
/*!40000 ALTER TABLE `MWO` DISABLE KEYS */;
INSERT INTO `MWO` (`id`, `MWONumber`, `Critical`, `fo_InventoryID`, `fo_Task`, `fo_Category`, `fo_JobInstruction`, `fo_DetailInstruction`, `fo_Resources`, `fo_Duedate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'5060_001_Q4 2019','1-High Urgency & High Impact',6,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:06:48',NULL),(2,'5060_001_Q1 2020','1-High Urgency & High Impact',6,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:07:59',NULL),(3,'5060_002_Q4 2019','1-High Urgency & High Impact',7,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:09:03',NULL),(4,'5060_002_Q1 2020','1-High Urgency & High Impact',7,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:09:27',NULL),(5,'5060_003_Q4 2019','1-High Urgency & High Impact',8,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:10:39',NULL),(6,'5060_003_Q1 2020','1-High Urgency & High Impact',8,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:11:42',NULL),(7,'5060_004_Q4 2019','1-High Urgency & High Impact',9,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:12:30','2019-09-06 12:12:50'),(8,'5060_004_Q1 2020','1-High Urgency & High Impact',9,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:13:23',NULL),(9,'5060_005_Q4 2019','1-High Urgency & High Impact',10,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:14:44',NULL),(10,'5060_005_Q1 2020','1-High Urgency & High Impact',10,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:15:48',NULL),(11,'5060_006_Q4 2019','1-High Urgency & High Impact',11,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:16:39',NULL),(12,'5060_006_Q1 2020','1-High Urgency & High Impact',11,'General Task','Asset','Facilities',NULL,NULL,'2019-09-06',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 12:17:01',NULL);
/*!40000 ALTER TABLE `MWO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWOCorrective`
--

DROP TABLE IF EXISTS `MWOCorrective`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWOCorrective` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CorrectiveID` varchar(200) NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CorrectiveID_unique` (`CorrectiveID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWOCorrective`
--

LOCK TABLES `MWOCorrective` WRITE;
/*!40000 ALTER TABLE `MWOCorrective` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWOCorrective` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWOPlanned`
--

DROP TABLE IF EXISTS `MWOPlanned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWOPlanned` (
  `WMOPlannedID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PlannedID` int(10) unsigned NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`WMOPlannedID`),
  UNIQUE KEY `PlannedID_unique` (`PlannedID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWOPlanned`
--

LOCK TABLES `MWOPlanned` WRITE;
/*!40000 ALTER TABLE `MWOPlanned` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWOPlanned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWOReactive`
--

DROP TABLE IF EXISTS `MWOReactive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWOReactive` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ReactiveID` varchar(200) NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ReactiveID_unique` (`ReactiveID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWOReactive`
--

LOCK TABLES `MWOReactive` WRITE;
/*!40000 ALTER TABLE `MWOReactive` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWOReactive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWOpreventive`
--

DROP TABLE IF EXISTS `MWOpreventive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWOpreventive` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PreventiveID` varchar(200) NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PreventiveID_unique` (`PreventiveID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWOpreventive`
--

LOCK TABLES `MWOpreventive` WRITE;
/*!40000 ALTER TABLE `MWOpreventive` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWOpreventive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWOproactive`
--

DROP TABLE IF EXISTS `MWOproactive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWOproactive` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ProactiveID` varchar(200) NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProactiveID_unique` (`ProactiveID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWOproactive`
--

LOCK TABLES `MWOproactive` WRITE;
/*!40000 ALTER TABLE `MWOproactive` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWOproactive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ManagementVisit`
--

DROP TABLE IF EXISTS `ManagementVisit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ManagementVisit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `MgtVstID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MgtVstID_unique` (`MgtVstID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ManagementVisit`
--

LOCK TABLES `ManagementVisit` WRITE;
/*!40000 ALTER TABLE `ManagementVisit` DISABLE KEYS */;
/*!40000 ALTER TABLE `ManagementVisit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ManagingVendor`
--

DROP TABLE IF EXISTS `ManagingVendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ManagingVendor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ManagingVendNumber` varchar(40) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_VendorID` int(11) unsigned DEFAULT NULL,
  `fo_DocumentDescription` varchar(255) NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Auditdate` date DEFAULT NULL,
  `fo_image` varchar(40) DEFAULT NULL,
  `fo_address` text,
  `fo_city` varchar(40) DEFAULT NULL,
  `fo_state` varchar(15) DEFAULT NULL,
  `fo_zip` char(8) DEFAULT NULL,
  `fo_workphone` varchar(40) DEFAULT NULL,
  `fo_mobile` varchar(40) DEFAULT NULL,
  `fo_contactperson` varchar(100) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ManagingVendNumber_unique` (`ManagingVendNumber`),
  KEY `fo_VendorID` (`fo_VendorID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ManagingVendor`
--

LOCK TABLES `ManagingVendor` WRITE;
/*!40000 ALTER TABLE `ManagingVendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `ManagingVendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Marketing`
--

DROP TABLE IF EXISTS `Marketing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Marketing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecordNumber` varchar(250) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Type` varchar(250) NOT NULL DEFAULT 'Unknown',
  `fo_Source` varchar(256) NOT NULL,
  `fo_Qualification` varchar(256) DEFAULT NULL,
  `fo_DateUpload` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecordNumber_unique` (`RecordNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Marketing`
--

LOCK TABLES `Marketing` WRITE;
/*!40000 ALTER TABLE `Marketing` DISABLE KEYS */;
INSERT INTO `Marketing` (`id`, `RecordNumber`, `DocItem`, `fo_DocumentDescription`, `fo_Type`, `fo_Source`, `fo_Qualification`, `fo_DateUpload`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'2020_001','Meeting: Lombrico Tank Cleaning Robot with Asia Water Jet (Singapore Office)','Outcome of the meeting for the Lombrico Tank cleaning robot with Mr Jacob of Asia Water Jet.','Meeting','Industrial Partner','Working','2019-10-07',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-08 12:41:17','2019-10-08 13:25:45');
/*!40000 ALTER TABLE `Marketing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MgtofChange`
--

DROP TABLE IF EXISTS `MgtofChange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MgtofChange` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `fo_Desc` text,
  `fo_class` text NOT NULL,
  `fo_regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MgtofChange`
--

LOCK TABLES `MgtofChange` WRITE;
/*!40000 ALTER TABLE `MgtofChange` DISABLE KEYS */;
/*!40000 ALTER TABLE `MgtofChange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MonthlyTimesheet`
--

DROP TABLE IF EXISTS `MonthlyTimesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MonthlyTimesheet` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TimesheetID` varchar(100) NOT NULL,
  `MTSID` int(10) unsigned DEFAULT '0',
  `fo_Class` varchar(40) NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TimesheetID_unique` (`TimesheetID`),
  KEY `MTSID` (`MTSID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MonthlyTimesheet`
--

LOCK TABLES `MonthlyTimesheet` WRITE;
/*!40000 ALTER TABLE `MonthlyTimesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `MonthlyTimesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NonConformance`
--

DROP TABLE IF EXISTS `NonConformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NonConformance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `worklocID` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `fo_ClosedIssue` tinyint(4) DEFAULT '0',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `worklocID` (`worklocID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NonConformance`
--

LOCK TABLES `NonConformance` WRITE;
/*!40000 ALTER TABLE `NonConformance` DISABLE KEYS */;
/*!40000 ALTER TABLE `NonConformance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ObsoleteRec`
--

DROP TABLE IF EXISTS `ObsoleteRec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ObsoleteRec` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(255) NOT NULL,
  `DCCID` int(10) unsigned DEFAULT '0',
  `fo_DCCITEM` int(10) unsigned DEFAULT '0',
  `fo_Description` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `DCCID` (`DCCID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ObsoleteRec`
--

LOCK TABLES `ObsoleteRec` WRITE;
/*!40000 ALTER TABLE `ObsoleteRec` DISABLE KEYS */;
/*!40000 ALTER TABLE `ObsoleteRec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrgContentContext`
--

DROP TABLE IF EXISTS `OrgContentContext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrgContentContext` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecordNumber` varchar(250) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Type` varchar(250) NOT NULL DEFAULT 'Unknown',
  `fo_genrec` varchar(256) NOT NULL,
  `fo_Update` varchar(256) DEFAULT NULL,
  `fo_DateUpload` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecordNumber_unique` (`RecordNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrgContentContext`
--

LOCK TABLES `OrgContentContext` WRITE;
/*!40000 ALTER TABLE `OrgContentContext` DISABLE KEYS */;
INSERT INTO `OrgContentContext` (`id`, `RecordNumber`, `DocItem`, `fo_DocumentDescription`, `fo_Type`, `fo_genrec`, `fo_Update`, `fo_DateUpload`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'2010_P601','P601 - DETERMINING CONTEXT OF THE ORGANIZATION','P601 - DETERMINING CONTEXT OF THE ORGANIZATION','Others','Internal Record','annualy Update','2019-09-04',NULL,NULL,'<br>','https://mega.nz/#F!SmJAAQpC!ixCzNkvq5JJ3oWLF6OCjZA',NULL,NULL,NULL,'74263500_1567603755.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 21:29:15','2019-09-04 23:21:59'),(2,'2010_P602','P602 - PERSONNEL ROLES & RESPONSIBILITIES','P602 - PERSONNEL ROLES & RESPONSIBILITIES','Others','Internal Record','annualy Update','2019-09-04',NULL,NULL,'<br>','https://mega.nz/#F!66IwgKIZ!yZl51y3taSedJlFtbRl89w',NULL,NULL,NULL,'48020900_1567609856.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 23:10:56','2019-09-04 23:22:22'),(3,'2010_P603','P603 - INCIDENT & EVENT NOTIFICATION','Internal and External issues for P603 - Incident & Event Notification','Others','Internal Record','annualy Update','2019-09-05',NULL,NULL,'<br>','https://mega.nz/#F!fm5AzCBT!iR4VwoqCv1mVP6mR4zJs4g',NULL,NULL,NULL,'34424600_1567651074.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 10:37:54',NULL),(4,'2010_P604','P604 - PARTICIPATION COMMUNICATION & CONSULTATION','Internal and External issues for P604 - Participation Communication and Consultation.','Others','Internal Record','annualy Update','2019-09-05',NULL,NULL,'<br>','https://mega.nz/#F!yqwmTABI!rb3xiO3uVzcQZ3xiFEgBKw',NULL,NULL,NULL,'83846600_1567651994.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 10:53:14','2019-09-05 10:54:39'),(5,'2010_P605','P605 - MANAGEMENT OF RISK','Internal and External issue for P605 - Management of RIsk','Others','Internal Record','annualy Update','2019-09-05','P605',NULL,'<br>','https://mega.nz/#F!2m4wiaBD!2H4-BHQQjOkC9JemylFDhg',NULL,NULL,NULL,'55735200_1567654345.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 11:32:25','2019-09-05 11:33:53'),(6,'2010_P606','P606 - MANAGEMENT OF CHANGE','Internal and External issues for P605 Management of Change','Others','Internal Record','annualy Update','2019-09-05','P606',NULL,'<br>','https://mega.nz/#F!vyhUGaoD!_cxm0QkrgNm32fz0EKbELw',NULL,NULL,NULL,'63334800_1567654687.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 11:38:07','2019-09-05 11:40:23'),(7,'2010_P607','P607 - CONTROL OF DOCUMENTS AND RECORDS','Internal and external Issues for P607 - Control of Documents and Records','Others','Internal Record','annualy Update','2019-09-05','P607',NULL,'<br>','https://mega.nz/#F!K3pyFQoT!cT0DSiiOJHA-gp7GRjKetQ',NULL,NULL,NULL,'96152500_1567655074.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 11:44:34','2019-09-05 11:45:58'),(8,'2010_P608','P608 - WORK ENVIRONMENT MONITORING AND CONTROL','Internal and External issues for P608 - Work Environment Monitoring and Control','Others','Internal Record','annualy Update','2019-09-05','P608',NULL,'<br>','https://mega.nz/#F!nm4EBCZT!0vVkSeKCIBlycwc4OwVbSw',NULL,NULL,NULL,'44894300_1567655444.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 11:50:44','2019-09-05 11:51:51'),(9,'2010_P609','P609 - LEGAL AND OTHER REQUIREMENT','Internal and external issue for Legal and Other Requirement','Others','Internal Record','annualy Update','2019-09-05','P609',NULL,'<br>','https://mega.nz/#F!a35mja5D!-tMF1DjF4E-RLUKmrnZVcg',NULL,NULL,NULL,'27169900_1567661700.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 13:35:00','2019-09-05 13:36:07');
/*!40000 ALTER TABLE `OrgContentContext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROCompletion`
--

DROP TABLE IF EXISTS `PROCompletion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROCompletion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CompletionNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_Classification` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CompletionNo_unique` (`CompletionNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROCompletion`
--

LOCK TABLES `PROCompletion` WRITE;
/*!40000 ALTER TABLE `PROCompletion` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROCompletion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROControlMonitoring`
--

DROP TABLE IF EXISTS `PROControlMonitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROControlMonitoring` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ContMonitNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_AuditInspection` text NOT NULL,
  `fo_Classification` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ContMonitNo_unique` (`ContMonitNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROControlMonitoring`
--

LOCK TABLES `PROControlMonitoring` WRITE;
/*!40000 ALTER TABLE `PROControlMonitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROControlMonitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROExecution`
--

DROP TABLE IF EXISTS `PROExecution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROExecution` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ExecutionNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_Classification` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ExecutionNo_unique` (`ExecutionNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROExecution`
--

LOCK TABLES `PROExecution` WRITE;
/*!40000 ALTER TABLE `PROExecution` DISABLE KEYS */;
INSERT INTO `PROExecution` (`id`, `ExecutionNo`, `ProjectsID`, `fo_Classification`, `fo_DocItem`, `fo_DocumentDescription`, `fo_Regdate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'1070_001',2,'Progress Report','MONTHLY PROGRESS REPORT NO. 3','This Monthly Progress Report is to highlight the progress reporting as of 20th\r\nMarch 2019.','2019-08-30',NULL,'CONTRACTOR Scope\r\nCONTRACTOR have been awarded by COMPANY to perform post trenching work,\r\nbackfilling and as-built survey at Sungai Johor for Pengerang Pipeline Project\r\n(POTCH).\r\nCONTRACTOR general scope of work comprise as follows;\r\n- Perform engineering analysis and investigation to ensure safe work execution\r\non live pipeline as per Engineering Plant\r\n- Obtain Approval and Interface with Local Authority\r\n- Perform live pipeline post trenching works from KP44+257 to KP45+971\r\n(Sungai Johor & Pulau Juling) with burial Top of Pipe (TOP) 2m\r\n- Perform backfilling works with aggregate at Sungai Johor, Pulau Juling and\r\nSelat Mendana and foreign soil backfilling at Kg. Sungai Latoh\r\n- Civil work slope protection at Penyabong\r\n- Perform as-built survey','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................4<br>1.1 CONTRACTOR Scope .................................................................................5<br>2.0 OBJECTIVE ...............................................................................................5<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................5<br>3.1 Definitions................................................................................................5<br>3.2 Abbreviations ...........................................................................................5<br>4.0 EXECUTIVE SUMMARY ..............................................................................6<br>4.1 Executive Summary..................................................................................6<br>4.2 Significant Accomplishments As of 20th March 2019 ................................6<br>4.3 Project Milestone .....................................................................................7<br>5.0 HSE EXECUTIVE SUMMARY .......................................................................9<br>5.1 Total Project Man Hours ...........................................................................9<br>5.2 Leading Indicator .....................................................................................9<br>5.3 Lagging Indicator...................................................................................10<br>5.4 HSE Highlights .......................................................................................11<br>5.4.1 HSE ACTIVITIES FOR THIS REPORTING PERIOD.................................. 11<br>5.4.2 HSE FUTURE PLAN ACTIVITIES ......................................................... 11<br>Area of Concern &amp; Corrective Action ................................................................11<br>6.0 PROGRESS REPORTING ..........................................................................12<br>6.1 Overall Progress Comparisons................................................................12<br>6.2 Engineering Breakdown .........................................................................12<br>6.3 Procurement Breakdown ........................................................................12<br>6.4 Construction Breakdown ........................................................................13<br>6.5 Overall S–Curve .....................................................................................13<br>6.6 Area of Concern &amp; Corrective Action ......................................................14<br>7.0 SCHEDULE ANALYSIS .............................................................................15<br>7.1 Overall Progress.....................................................................................15<br>7.2 One (1) Month Look Ahead Key Activities ..............................................15<br>7.3 Critical Path ...........................................................................................16<br>8.0 PROCUREMENT STATUS..........................................................................17<br>9.0 PAYMENT STATUS ..................................................................................18<br>9.1 Milestone Status.....................................................................................18<br>9.2 Change Order Register ...........................................................................18<br>10.0 QA/QC STATUS.......................................................................................19<br>10.1 Overall Progress.....................................................................................19<br>10.2 QA/QC Highlight ....................................................................................19<br>11.0 PROJECT RISK REGISTER .......................................................................20<br>11.1 Overall Progress.....................................................................................20<br>12.0 MALAYSIAN CONTENT ............................................................................21<br>12.1 Malaysian Participant Overall .................................................................21<br>13.0 REGULATORY LEDGER ............................................................................22<br>13.1 Malaysian Participant Overall .................................................................22<br>APPENDIX 1 – MASTER DELIVERABLE REGISTER .............................................23<br>APPENDIX 2 – PROJECT SCHEDULE ..................................................................26<br>APPENDIX 3 – PROJECT CRITICAL PATH ..........................................................32<br><div>APPENDIX 4 – PROJECT S CURVE .....................................................................35</div><div>APPENDIX 5 – PROGRESS PHOTOGRAPH..........................................................37<br>APPENDIX 6 – PROCUREMENT REGISTER .........................................................40<br>APPENDIX 7 – RISK REGISTER .........................................................................42<br>APPENDIX 8 – REGULATORY LEDGER ...............................................................62<br></div>','https://mega.nz/#F!nzQglAZJ!rbgYy5ImeXMcqzbN97Lp5w',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 11:52:16','2019-08-30 12:07:22');
/*!40000 ALTER TABLE `PROExecution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROInitiation`
--

DROP TABLE IF EXISTS `PROInitiation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROInitiation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `InitiationNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_InitiationForm` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `InitiationNo_unique` (`InitiationNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROInitiation`
--

LOCK TABLES `PROInitiation` WRITE;
/*!40000 ALTER TABLE `PROInitiation` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROInitiation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROPlanning`
--

DROP TABLE IF EXISTS `PROPlanning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROPlanning` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PlanningNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_RelatedDocument` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PlanningNo_unique` (`PlanningNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROPlanning`
--

LOCK TABLES `PROPlanning` WRITE;
/*!40000 ALTER TABLE `PROPlanning` DISABLE KEYS */;
INSERT INTO `PROPlanning` (`id`, `PlanningNo`, `ProjectsID`, `fo_RelatedDocument`, `fo_DocItem`, `fo_DocumentDescription`, `fo_Regdate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'1060_002_001',2,'Others','TRENCH BACKFILLING SCHEMATIC ON LAND','Client: PETRONAS Gas Berhad\r\nMain Contractor: KL Petrogas Sdn Bhd\r\n\r\nDrawing schematic of the trench backfilling on land for the POTCH project.','2019-08-26',NULL,NULL,'<br>','https://mega.nz/#F!62xQwYaZ!9_L7wkARbXmKpv4nX264EQ',NULL,NULL,NULL,'08792900_1567601015.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-26 14:06:28','2019-09-06 16:27:14'),(2,'1060_002_002',2,'Others','RIVERBANK PROTECTION CONSTRUCTION PROCEDURE','This report presents the riverbank protection construction procedure for Post\r\nTrenching Works at Sungai Johor for Pengerang Gas Pipeline Project (POTCH). The riverbank protection work covered for Penyabong side.\r\n\r\nThe riverbank protection construction procedure at Penyabong side shall comply\r\nwith the requirement of the design Riverbank Protection Design, Ref. [15].','2019-08-30',NULL,'[1] POTCH-CON-KLP-PGRO-CON-PRC-005; Diving Procedure\r\n[2] POTCH-CON-KLP-PGRO-CON-CER-003; Diving Equipment Certification and Documentation\r\n[3] POTCH-CON-KLP-PGRO-CON-CER-001; Backfill Machinery Certification Documentation\r\n[4] POTCH-EXE-KLP-PGRO-PMG-PLN-001; Construction Execution Plan (CEP)\r\n[5] POTCH-DD-KLP-PGRO-ENG-RPT-006; Drop Object Analysis\r\n[6] POTCH-DD-KLP-PGRO-ENG-DWG-029; Riverbank Protection at Penyabong Landfall\r\n[7] PTS 11.13.01; Geotechnical Engineering for Onshore Facilities \r\n[8] POTCH-CON-KLP-PGRO-CON-CER-001; Backfill Certification Documentation\r\n[9] POTCH-CON-KLP-PGRO-CON-PRC-004; As Built Survey Procedure\r\n[10] POTCH-EXE-KLP-PGRO-PMG-SCH-001; Project Schedule\r\n[11] POTCH-EXE-KLP-PGRO-PMG-PLN-004; Project Quality Plan\r\n[12] POTCH-EXE-KLP-PGRO-PMG-PLN-003; Project Planning Package\r\n[13] POTCH-EXE-KLP-PGRO-HSE-PLN-002; Project Emergency Response Plan and Preparedness\r\n[14] POTCH-DD-KLP-PGRO-ENG-RPT-005; Pipeline Erosion Study\r\n[15] POTCH-DD-KLP-PGRO-ENG-RPT-009; Riverbank Protection Design\r\n[16] Riprap Design and Construction Guide (March 2000), Canadian Cataloguing in Publication Data\r\n[17] POTCH-DD-KLP-PGRO-ENG-LYT-002; Working Area Plot Plan at Penyabong','<div>TABLE OF CONTENT</div><div>1.0 INTRODUCTION.........................................................................................&nbsp; 3<br>1.1 CONTRACTOR Scope ................................................................................. 4<br>2.0 OBJECTIVE ............................................................................................... 4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................ 4<br>3.1 Definitions ................................................................................................ 4<br>3.2Abbreviations ........................................................................................... 4<br>4.0 REFERENCES ............................................................................................ 5<br>5.0 SCOPE OF WORK ...................................................................................... 5<br>5.1 General .................................................................................................... 5<br>5.2 Scope of Work Riverbank Protection ........................................................ 5<br>6.0 MATERIAL &amp; EQUIPMENT ......................................................................... 6<br>6.1 Material .................................................................................................... 6<br>6.2 Equipment ................................................................................................ 6<br>7.0 PREPARATORY WORK ............................................................................... 6<br>7.1 Manpower ................................................................................................ 6<br>7.2 Equipment testing and preparation .......................................................... 7<br>7.3 Site Preparation ....................................................................................... 7<br>7.4 Mobilisation .............................................................................................. 8<br>8.0 OPERATION PROCEDURE .......................................................................... 8<br>8.1 Daily Inspection ....................................................................................... 8<br>8.2 Riverbank Protection Procedure ............................................................... 8<br>8.3 Contingency Procedure ............................................................................ 9<br>8.3.1 Weather ........................................................................................... 9<br>8.3.2 Equipment Breakdown ....................................................................... 9<br>8.3.3 Operational Limitations ...................................................................... 9<br>8.3.4 Emergency Response Plan .................................................................. 9<br>8.4 Final Acceptance .................................................................................... 10<br>8.5 Demobilisation ....................................................................................... 10<br></div>','https://mega.nz/#F!K6xlmAgR!-bFVU6wZ7Pgw64-56rBKKQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 11:13:53','2019-09-06 16:28:03'),(3,'1060_002_003',2,'Others','TRENCH BACKFILLING SCHEMATIC AT SELAT MENDANA','Drawing for the Trench backfilling schematic at Selat Mendana','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!Cvx1TaID!FAooYIf-EggervTNb8vCpA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 11:22:50','2019-09-06 16:28:27'),(4,'1060_002_004',2,'Others','JOB METHOD STATEMENT POST TRENCHING','OBJECTIVE\r\nThis document is to summarize details specific post-trenching work to be perform\r\nat Sungai Johor for Pengerang Gas Pipeline Project:\r\n• To ensure that the works are performed safely and in compliance with the\r\nproject requirement.\r\n• To ensure the trench depth at the as-laid pipeline is acceptable as required by\r\nclient.\r\n• To describe the safety aspect of the task, the key responsibilities of the\r\npersonnel involved, and consumable required.','2019-08-30',NULL,'REFERENCES\r\n[1] POTCH-DD-KLP-PGRO-ENG-PRC-001; Post Trenching Procedure\r\n[2] POTCH-EXE-KLP-PGRO-HSE-JHA-001; Job Hazard Analysis Post Trenching\r\n[3] POTCH-DD-KLP-PGRO-HSE-PLN-002; Project Emergency Plan and\r\nPreparedness\r\n[4] POTCH-CON-KLP-PGRO-CON-PRC-001; Post Trenching Equipment\r\nFunctional Test Procedure','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................3<br>1.1 CONTRACTOR Scope .................................................................................4<br>2.0 OBJECTIVE ...............................................................................................4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................4<br>3.1 Definitions................................................................................................4<br>3.2 Abbreviations ...........................................................................................4<br>4.0 REFERENCES ............................................................................................5<br>5.0 RESPONSIBILITES....................................................................................5<br>5.1 Post-Trenching Crew ................................................................................5<br>5.1.1 Trenching Superintendent ..................................................................5<br>5.1.2 Trenching Supervisor .........................................................................5<br>5.1.3 Trenching Project Engineer .................................................................5<br>5.1.4 Jetting Technicians ............................................................................6<br>5.1.5 Pump Technicians .............................................................................6<br>5.1.6 Instrumentation Technician ................................................................6<br>6.0 WORK PLAN .............................................................................................7<br>6.1 General ....................................................................................................7<br>6.2 Working Area &amp; Conditions ......................................................................7<br>6.3 Post-Trenching .........................................................................................7<br>6.3.1 Job Preparation .................................................................................7<br>6.3.2 Mobilization on Site ...........................................................................7<br>6.3.3 Equipment Distribution ......................................................................8<br>6.3.4 Operation .........................................................................................9<br>6.4 Housekeeping ..........................................................................................9<br>7.0 JOB HAZARD ANALYSIS (JHA)................................................................10<br>8.0 FLOW CHART ..........................................................................................11<br>8.1 Post Trenching Flow Chart .....................................................................11<br>9.0 QUALITY ASSURANCE &amp; QUALITY CHECK ...............................................12<br>9.1 Post Trenching .......................................................................................12<br>','https://mega.nz/#F!jr5jxCyJ!-YsJOT3arMmPF3ic9p7JIQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 11:30:37','2019-09-06 16:28:50'),(5,'1060_002_005',2,'Others','RIVERBANK PROTECTION DESIGN','This report presents the riverbank protection design for Post Trenching Works at\r\nSungai Johor for Pengerang Gas Pipeline Project (POTCH). The riverbank\r\nprotection work located at Penyabong side.','2019-08-30',NULL,'REFERENCES\r\n[1] POTCH-CON-KLP-PGRO-CON-PRC-005; Diving Procedure\r\n[2] POTCH-CON-KLP-PGRO-CON-CER-003; Diving Equipment Certification and\r\nDocumentation\r\n[3] POTCH-CON-KLP-PGRO-CON-CER-001; Backfill Machinery Certification\r\nDocumentation\r\n[4] POTCH-EXE-KLP-PGRO-PMG-PLN-001; Construction Execution Plan (CEP)\r\n[5] POTCH-DD-KLP-PGRO-ENG-RPT-006; Drop Object Analysis\r\n[6] PGB-A-001/REP/PL/002; Pipe Soil Interaction Study\r\n[7] EM 1110-2-1601; US Army Corps of Engineer, Hydraulic Design of Flood\r\nControl Channels\r\n[8] Geotextiles and Geomembranes, Knut Oberhagemann,\r\n[9] Soil Strength and Slope Stability, 2nd Edition. Wiley\r\n[10] River Mechanics, 2002. Cambridge.\r\n[11] Shore Protection Guidelines, Jabatan Kerja Raya Malaysia.\r\n[12] POTCH-DD-KLP-PGRO-ENG-DWG-029; Riverbank Protection at Penyabong\r\nLandfall\r\n[13] EM 1110-2-1614; US Army Corps of Engineer, Design of Coastal\r\nRevetments, Seawalls and Bulkheads\r\n[14] Riprap Design and Construction Guide, March 2000. Canadian Cataloguing\r\nin Publication Data','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................3<br>1.1 CONTRACTOR Scope .................................................................................4<br>2.0 OBJECTIVE ...............................................................................................4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................4<br>3.1 Definitions................................................................................................4<br>3.2 Abbreviations ...........................................................................................4<br>4.0 REFERENCES ............................................................................................5<br>5.0 DESIGN CODES &amp; STANDARDS .................................................................5<br>5.1 Malaysian Government &amp; Local Authority Laws &amp; Regulation...................5<br>5.2 PETRONAS Technical Standard (PTS) .......................................................5<br>5.3 International Codes &amp; Standards .............................................................6<br>5.3.1 American Society of Mechanical Engineers (ASME) ................................6<br>5.3.2 American Petroleum Institute (API) .....................................................6<br>5.3.3 Det Norske Veritas Germanischer Llyod (DNVGL) ..................................6<br>6.0 SUMMARY AND CONCLUSION ...................................................................7<br>6.1 Summary..................................................................................................7<br>6.2 Conclusion................................................................................................7<br>7.0 DESIGN DATA ...........................................................................................7<br>7.1 Soil Data...................................................................................................8<br>8.0 METHODOLOGY ........................................................................................8<br>8.1 General ....................................................................................................8<br>8.2 Slope Stability ..........................................................................................9<br>8.3 Side slope.................................................................................................9<br>8.4 Length of Riprap Protection .....................................................................9<br>8.5 Toe Protection ........................................................................................10<br>8.6 Aggregate size .......................................................................................10<br>8.7 Hydrodynamic Stability ..........................................................................11<br>8.8 Geotextiles .............................................................................................12<br>9.0 RESULTS &amp; DISCUSSION ........................................................................12<br>9.1 General ..................................................................................................12<br>9.2 Slope Stability ........................................................................................12<br>9.3 Side slope...............................................................................................12<br>9.4 Length of Riprap Protection ...................................................................12<br>9.5 Size of Aggregate ...................................................................................13<br>9.6 Volume of Aggregate..............................................................................13<br>9.7 Area of Geotextile ..................................................................................13<br>APPENDIX 1 – PIPE SOIL INTERACTION STUDY ...............................................14<br>APPENDIX 2 – SLOPE STABILITY .....................................................................19<br>APPENDIX 3 – AGGREGATE SIZE ......................................................................22<br>APPENDIX 4 – ROCK UNIT STABILITY ..............................................................25<br>APPENDIX 5 – HORIZONTAL LENGTH OF SLOPE ...............................................28<br>APPENDIX 6 – TOE WIDTH PROTECTION..........................................................30<br>APPENDIX 7 – HYDRODYNAMIC STABILITY .....................................................33<br>APPENDIX 8 – VOLUME OF AGGREGATE ...........................................................35<br>','https://mega.nz/#F!DupFUKTI!9_-Lx0oCPiW02MBSW4VMQQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 11:34:44','2019-09-06 16:29:17'),(6,'1060_002_006',2,'Others','BACKFILLING CALCULATION','This document present Backfilling Calculation for the Post Trenching Works at\r\nSungai Johor for Pengerang Gas Pipeline Project (POTCH). The calculation\r\nperformed includes volume calculation of soil required at Kg. Sungai Latoh and\r\nvolume calculation for aggregate required at Sg. Johor, Selat Mendana and Pulau\r\nJuling. This volume calculation is to ensure cover depth requirement along the\r\npipeline are achieved. The calculation for settlement of soil is carried out for Kg.\r\nSungai Latoh by using aggregate and suitable soil specification.','2019-08-30',NULL,'REFERENCES\r\n[1] Braja M. Das. Principle of Geotechnical Engineering, 7th Edition. Cengage\r\nLearning\r\n[2] PGB-A-001/REP/PL/002; Pipe Soil Interaction Study\r\n[3] PGB-A-001/REP/PM/001; Geotechnical Survey Report\r\n[4] POTCH-DD-KLP-PGRO-ENG-DES-001; Design Basis\r\n[5] POTCH-DD-KLP-PGRO-ENG-PRC-002; Backfilling Procedure\r\n[6] Comparison of Geotechnical Properties of Laterite, Kaolin and Peat, 2015.\r\nS.A.N. Mohd Yusoff','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................3<br>1.1 CONTRACTOR Scope .................................................................................4<br>2.0 OBJECTIVE ...............................................................................................4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................4<br>3.1 Definitions................................................................................................4<br>3.2 Abbreviations ...........................................................................................4<br>4.0 REFERENCES ............................................................................................5<br>5.0 DESIGN CODES &amp; STANDARDS .................................................................5<br>5.1 Malaysian Government &amp; Local Authority Laws &amp; Regulation ...................5<br>5.2 PETRONAS Technical Standard (PTS) .......................................................5<br>5.3 International Codes &amp; Standards .............................................................6<br>5.3.1 American Society of Mechanical Engineers (ASME) ................................6<br>5.3.2 American Petroleum Institute (API) .....................................................6<br>5.3.3 Det Norske Veritas Germanischer Llyod (DNVGL) ..................................6<br>5.3.4 British Standard (BS).........................................................................6<br>6.0 SUMMARY AND CONCLUSION ...................................................................7<br>6.1 Summary..................................................................................................7<br>6.2 Conclusion................................................................................................8<br>7.0 DESIGN DATA ...........................................................................................8<br>7.1 Soil Data...................................................................................................8<br>7.2 Backfill Material Data ...............................................................................8<br>8.0 METHODOLOGY ........................................................................................9<br>8.1 General ....................................................................................................9<br>8.2 Backfilling Calculation ..............................................................................9<br>8.3 Settlement Analysis ...............................................................................10<br>8.3.1 Elastic Settlement ........................................................................... 10<br>8.3.2 Primary Consolidation Settlement...................................................... 11<br>9.0 RESULTS &amp; DISCUSSION ........................................................................12<br>9.1 General ..................................................................................................12<br>9.2 Backfilling Calculation ............................................................................12<br>9.3 Elastic Settlement ..................................................................................12<br>9.4 Primary Consolidation Settlement ..........................................................12<br>APPENDIX 1 – SOIL DATA ................................................................................14<br>APPENDIX 2 – BACKFILLING CALCULATION.....................................................23<br>APPENDIX 3 – ELASTIC SETTLEMENT ...............................................................26<br>APPENDIX 4 – PRIMARY CONSOLIDATION SETTLEMENT..................................28<br>','https://mega.nz/#F!6rgX0QTA!Yo-wy2IQ_i2WhctSunuAbg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 11:37:44','2019-09-06 16:32:35'),(7,'1060_002_007',2,'Others','BACKFILLING PROCEDURE','This report presents the backfilling procedure for Post Trenching Works at Sungai\r\nJohor for Pengerang Gas Pipeline Project (POTCH). The backfilling work covered\r\nfor Sungai Johor, Pulau Juling, Selat Mendana and Kg. Sungai Latoh.','2019-08-30',NULL,'REFERENCES\r\n[1] POTCH-CON-KLP-PGRO-CON-PRC-005; Diving Procedure\r\n[2] POTCH-CON-KLP-PGRO-CON-CER-003; Diving Equipment Certification and\r\nDocumentation\r\n[3] POTCH-CON-KLP-PGRO-CON-CER-001; Backfill Certification\r\nDocumentation\r\n[4] POTCH-EXE-KLP-PGRO-PMG-PLN-001; Construction Execution Plan (CEP)\r\n[5] POTCH-DD-KLP-PGRO-ENG-RPT-006; Drop Object Analysis\r\n[6] POTCH-EXE-KLP-PGRO-HSE-PLN-001; Project HSE Plan\r\n[7] POTCH-DD-KLP-PGRO-ENG-RPT-004; Backfilling Calculation\r\n[8] POTCH-CON-KLP-PGRO-CON-PRC-006; Anchor Handling and Mooring\r\nProcedure\r\n[9] POTCH-DD-KLP-PGRO-ENG-DWG-033; Accessibility Area for Backfilling\r\nActivity at Kg Sungai Latoh\r\n[10] POTCH-EXE-KLP-PGRO-PMG-PLN-004; Project Quality Plan\r\n[11] POTCH-CON-KLP-PGRO-CON-PRC-008; Backfill Material Transportation\r\nProcedure\r\n[12] POTCH-DD-KLP-PGRO-ENG-DWG-034; Accessibility Area for Backfilling\r\nActivity at Selat Mendana\r\n[13] POTCH-DD-KLP-PGRO-ENG-DWG-035; Accessibility Area for Backfilling\r\nActivity at Sungai Johor\r\n[14] POTCH-EXE-KLP-PGRO-HSE-PLN-002; Project Emergency Response Plan\r\nand Preparedness\r\n[15] POTCH-CON-KLP-PGRO-CON-PRC-004; As Built Survey Procedure\r\n[16] POTCH-CON-KLP-PGRO-CON-RPT-003; As Built Survey Report\r\n[17] POTCH-EXE-KLP-PGRO-PMG-SCH-001; Project Schedule\r\n[18] POTCH-DD-KLP-PGRO-ENG-DWG-011; Trench Backfilling Schematic\r\nUnderwater\r\n[19] POTCH-DD-KLP-PGRO-ENG-LYT-005; Working Area Plot Plan at Kg Sungai\r\nLatoh\r\n[20] POTCH-CON-KLP-PGRO-CON-PRC-002; In-situ Survey Procedure\r\n[21] POTCH-DD-KLP-PGRO-ENG-DWG-010; Trench Backfilling Schematic on\r\nLand\r\n[22] POTCH-CON-KLP-PGRO-CON-PRC-003; Pre Survey Procedure\r\n[23] POTCH-EXE-KLP-PGRO-HSE-PLN-004; Traffic Management Plan\r\n[24] POTCH-DD-KLP-PGRO-ENG-DWG-032; Anchor Pattern','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................3<br>1.1 CONTRACTOR Scope .................................................................................4<br>2.0 OBJECTIVE ...............................................................................................4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................4<br>3.1 Definitions................................................................................................4<br>3.2 Abbreviations ...........................................................................................4<br>4.0 REFERENCES ............................................................................................5<br>5.0 SCOPE OF WORK ......................................................................................6<br>5.1 General ....................................................................................................6<br>5.2 Scope of Work Underwater.......................................................................6<br>5.3 Scope of Work on Land.............................................................................7<br>6.0 MATERIAL &amp; EQUIPMENT .........................................................................7<br>6.1 Material ....................................................................................................7<br>6.2 Equipment ................................................................................................7<br>7.0 PREPARATORY WORK...............................................................................8<br>7.1 Manpower ................................................................................................8<br>7.2 On Land....................................................................................................9<br>7.2.1 Equipment Testing &amp; Preparation ........................................................9<br>7.2.2 Site Preparation ................................................................................9<br>7.2.3 Mobilisation ......................................................................................9<br>7.3 Underwater ............................................................................................10<br>7.3.1 Marine Spread Preparation ............................................................... 10<br>7.3.2 Pre-survey ..................................................................................... 10<br>7.3.3 Mobilisation .................................................................................... 10<br>8.0 OPERATION PROCEDURE ........................................................................10<br>8.1 Daily Inspection .....................................................................................10<br>8.1.1 On Land ......................................................................................... 11<br>8.1.2 Underwater .................................................................................... 11<br>8.2 Backfilling Procedure .............................................................................11<br>8.2.1 On Land ......................................................................................... 11<br>8.2.2 Underwater .................................................................................... 12<br>8.3 Contingency Procedure ..........................................................................15<br>8.3.1 Weather ......................................................................................... 15<br>8.3.2 Equipment Breakdown ..................................................................... 15<br>8.3.3 Operational Limitations .................................................................... 15<br>8.3.4 Emergency Response Plan ................................................................ 16<br>8.4 Final Acceptance ....................................................................................16<br>8.5 Demobilisation .......................................................................................17<br>APPENDIX 1 – BACKFILLING DAILY REPORT....................................................18<br>APPENDIX 2 – FINAL ACCEPTANCE BACKFILLING REPORT ..............................20<br>APPENDIX 3 – BARGE AND TUG BOAT DATASHEET...........................................22<br>','https://mega.nz/#F!SzhRVQia!Kxh5VtQhyWitLPCQi3tsSA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 11:40:38','2019-09-06 16:36:04'),(8,'1060_002_008',2,'Others','POST-TRENCHING OVERALL LAYOUT AT SUNGAI JOHOR, PULAU JULING, SELAT MENDANA AND KG. SUNGAI LATOH','Drawing for the post-trenching overall layout at Sungai Johor, Pulau Juling, Selat Mendana and Kg. Sungai Latoh.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!DyxT3KoR!1XDPHVq0OsxOHe2OPF-2pA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:11:57','2019-09-06 16:41:33'),(9,'1060_002_009',2,'Others','OFFICE LAYOUT AND WORKING AREA AT PENYABONG','Drawing of the office layout and working area at Penyabong','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!arBGhQKQ!g6ZKjTecVIH5wuzMnIsnzw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:17:20','2019-09-25 17:06:43'),(10,'1060_002_010',2,'Others','WORKING AREA PLOT PLAN AT PULAU JULING AND SELAT MENDANA','Drawing for the working area plot plan at Pulau Juling and Selat Mendana','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!eiBQkAZR!kyVXwAquG4KEJL7B6ulCRw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:22:37','2019-09-25 17:09:01'),(11,'1060_002_011',2,'Others','WORKING AREA PLOT PLAN KG. SUNGAI LATOH','Drawing for the working area plot plan at Kg. Sungai Latoh.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!HvIWGCTQ!dSntTgVLrWjrXXI0Chyf4g',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:25:19','2019-09-25 17:09:22'),(12,'1060_002_012',2,'Others','POST-TRENCHING INITIATION DETAILS AT PENYABONG AND PULAU JULING, SUNGAI JOHOR.','Drawing schematic for the post-trenching initiation details at Penyabong and Pulau Juling, Sungai Johor.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!WnAWnKSL!PZhg15AYfQRoRMEMDsNkyg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:29:04','2019-09-25 17:11:19'),(13,'1060_002_013',2,'Others','POST-TRENCHING INITIATION SEQUENCE - 1 (SUNGAI JOHOR) & SEQUENCE - 2 (SUNGAI JOHOR)','Drawing schematic for the post-trenching initiation sequence 1 & 2 at Sungai Johor.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!T3AWlYJB!AvPO4Jl3DdTf920r6alwmw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:33:10','2019-09-25 17:11:43'),(14,'1060_002_014',2,'Others','BACKFILLING DETAIL AT KP 44+257 TO KP 45+971 SUNGAI JOHOR & PULAU JULING','Drawing schematic for the backfilling detail at KP 44+257 to KP 45+971 Sungai Johor and Pulau Juling.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!2uZmyYRS!b51YBtJwx0IcvrYf-8lUaw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:37:27','2019-09-25 17:12:09'),(15,'1060_002_015',2,'Others','BACKFILLING DETAIL AT KP 46+850 TO  KP 47+598 (SELAT MENDANA)','Drawing for the backfilling detail at KP 46+850 to KP 47+598 (Selat Mendana)','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!buAWwQZS!VWmKUmZM3vMmsCykfqVTMQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:41:28','2019-09-25 17:12:33'),(16,'1060_002_016',2,'Others','TRANSITION DETAIL AT SHORE PENYABONG AND SHORE PULAU JULING','Drawing schematic for the transition detail at shore Penyabong and shore Pulau Juling.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!DrYQDKaQ!A6wa7lamrWBs22CzCC5AGw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:43:56','2019-09-25 17:12:52'),(17,'1060_002_017',2,'Others','ANCHOR PATTERN BACKFILLING ACTIVITY AT SELAT MENDANA STAGE - 1,2 & 3','Drawing for the anchor pattern backfilling activity at Selat Mendana Stage 1,2 &3.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!arJCzCYB!1NCFe12SQ1miosaWR1OWWA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:48:30','2019-09-25 17:13:11'),(18,'1060_002_018',2,'Others','RIVERBANK PROTECTION AT PENYABONG LANDFALL','Drawing schematic for riverbank protection at Penyabong landfall.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!mjIS1SzT!czUoEciDWcUeREJfYXGqjQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:52:06','2019-09-25 17:13:40'),(19,'1060_002_019',2,'Others','PILE REMOVAL SCHEMATIC','Drawing schematic for pile removal','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!PzZkgaob!HoDlja_P4hrxkqmSXrCw5w',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:55:02','2019-09-25 17:14:00'),(20,'1060_002_020',2,'Others','ANCHOR PATTERN POST-TRENCHING ACTIVITY AT SUNGAI JOHOR','Drawing schematic for anchor pattern post-trenching activity at Sungai Johor.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!zzIy2QaD!HDXBOoAiSp6k-nacr-etfg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 12:57:58','2019-09-25 17:14:20'),(21,'1060_002_021',2,'Others','ACCESSIBILITY AREA FOR BACKFILLING ACTIVITY AT KG. SUNGAI LATOH','Drawing schematic for accessibility area for backfilling activity at Kg. Sungai Latoh.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!riZySAAB!WgsPmF8P11n3hPieYoOcOw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 13:01:05','2019-09-25 17:14:39'),(22,'1060_002_022',2,'Others','ACCESSIBILITY AREA FOR BACKFILLING ACTIVITY AT SELAT MENDANA','Drawing schematic for accessibility area for backfilling activity at Selat Mendana.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!L2YwjKwT!42-pE1CcQf2nI-7qbbFk3w',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 13:03:58','2019-09-25 17:15:02'),(23,'1060_002_023',2,'Others','ACCESSIBILITY AREA FOR BACKFILLING ACTIVITY FOR SUNGAI JOHOR AND PULAU JULING','Drawing schematic for accessibility area for backfilling activity for Sungai Johor and Pulau Juling.','2019-08-30',NULL,NULL,'<br>','https://mega.nz/#F!CuBigKIL!PdwCuPLWNOhsFgzzCPE-tg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 15:12:57','2019-09-25 17:15:21'),(24,'1060_002_024',2,'Others','JOB METHOD STATEMENT PRE-SURVEY (RIVER SECTION)','This document is to summarize details specific pre-survey work to be perform for\r\nPost Trenching Works at Sungai Johor for Pengerang Gas Pipeline Project.\r\n• To ensure that the works are performed safely and in compliance with the\r\nproject requirement.\r\n• To ensure the survey result is acceptable as required by client.\r\n• To describe the safety aspect of the task, the key responsibilities of the\r\npersonnel involved, and consumable required.','2019-08-30',NULL,'REFERENCES\r\n[1] POTCH-DD-KLP-PGRO-ENG-PRC-001; Post Trenching Procedure\r\n[2] POTCH-EXE-KLP-PGRO-HSE-JHA-003; Job Hazard Analysis Survey (River\r\nSection)\r\n[3] POTCH-DD-KLP-PGRO-HSE-PLN-002; Project Emergency Plan and\r\nPreparedness','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................3<br>1.1 CONTRACTOR Scope .................................................................................4<br>2.0 OBJECTIVE ...............................................................................................4<br>2.1 Survey Location........................................................................................4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................5<br>3.1 Definitions................................................................................................5<br>3.2 Abbreviations ...........................................................................................5<br>4.0 REFERENCES ............................................................................................5<br>5.0 RESPONSIBILITES....................................................................................6<br>5.1 Workshop Manager ..................................................................................6<br>5.2 Party Chief ...............................................................................................6<br>5.3 Hydrographic Surveyor ............................................................................6<br>5.4 Survey Engineer .......................................................................................7<br>5.5 Helmsman ................................................................................................7<br>5.6 Project Surveyor ......................................................................................7<br>5.7 Data Processor .........................................................................................8<br>6.0 WORK PLAN .............................................................................................8<br>6.1 General ....................................................................................................8<br>6.2 Working Area and Conditions ...................................................................8<br>6.3 In-situ Survey (Post Trenching &amp; Backfilling) ..........................................8<br>6.3.1 Job Preparation .................................................................................8<br>6.3.2 Mobilization on Site ...........................................................................9<br>6.3.3 Equipment........................................................................................9<br>6.3.4 GPS Verification ................................................................................9<br>6.3.5 Installation Survey Equipment ............................................................9<br>6.3.6 Data Acquisition ................................................................................9<br>6.4 Housekeeping ........................................................................................10<br>7.0 JOB HAZARD ANALYSIS..........................................................................10<br>8.0 FLOW CHART ..........................................................................................11<br>9.0 QUALITY ASSURANCE AND QUALITY CHECK...........................................11<br>10.0 RESULT...................................................................................................12<br>APPENDIX 1 – PROCESS FLOW : EQUIPMENT INSTALLATION ..........................13<br>APPENDIX 2 – PROCESS FLOW : SURVEY DATA ACQUISITION .........................15<br>','https://mega.nz/#F!vuIUQApB!cvVoMGis5gHnsgjE1sYOgg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 15:17:19','2019-09-25 17:15:40'),(25,'1060_002_025',2,'Others','PRE-SURVEY PROCEDURE','The objective of this document is to elaborate details of pre-survey procedure\r\nintended to be perform by CONTRACTOR for Post Trenching Works at Sungai Johor\r\nfor Pengerang Gas Pipeline Project (POTCH).','2019-08-30',NULL,'REFERENCES\r\n[1] IHO Standard for Hydrographic Survey SP 44 5th Edition; February 2008\r\n[2] POTCH ITB Document, Exhibit II - Specification; Bathymetry Survey\r\nReport; PGB-A-001/REP/PM/002\r\n[3] POTCH ITB Document Exhibit II - Specification; Engineering Drawing\r\nCompile Signed; PGB-A-001/DWG/PL/001\r\n[4] POTCH-EXE-KLP-PGRO-HSE-PLN-002; Project Emergency Response Plan\r\nand Preparedness','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................4<br>1.1 CONTRACTOR Scope .................................................................................5<br>2.0 OBJECTIVE ...............................................................................................5<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................5<br>3.1 Definitions................................................................................................5<br>3.2 Abbreviations ...........................................................................................5<br>4.0 REFERENCES ............................................................................................6<br>5.0 SCOPE OF WORK ......................................................................................6<br>5.1 Survey Objectives ....................................................................................6<br>5.2 Standard of Survey...................................................................................7<br>5.3 Survey Line Planning................................................................................8<br>5.3.1 MBES &amp; SSS Survey Line Plan.............................................................8<br>5.3.2 MBES &amp; SSS Coverage &amp; Overlap ........................................................9<br>6.0 GEODETIC PARAMETER ..........................................................................10<br>6.1 Geodetic Datum &amp; Grid Projection Parameters .......................................10<br>6.2 Vertical Datum .......................................................................................11<br>6.3 Time .......................................................................................................11<br>6.4 Positioning .............................................................................................11<br>6.5 Positioning System Requirement ...........................................................11<br>6.6 Multibeam Echo Sounders ......................................................................12<br>6.7 Hydrographic Data Acquisition System (HDAS) ......................................12<br>6.7.1 Helmsman Display........................................................................... 12<br>6.7.2 Quality Control................................................................................ 12<br>6.7.3 Data Logging Parameter................................................................... 12<br>6.7.4 Data Back-Up ................................................................................. 12<br>7.0 SURVEY METHODOLOGY &amp; SURVEY EQUIPMENT ....................................13<br>7.1 Survey Equipment ..................................................................................13<br>7.1.1 Summary of survey equipment ......................................................... 13<br>7.2 Survey Methodology...............................................................................13<br>7.2.1 Hydrographic Survey ....................................................................... 13<br>7.2.2 Bathymetry Survey ......................................................................... 13<br>7.2.3 Side Scan Sonar.............................................................................. 13<br>7.2.4 Tide Gauge..................................................................................... 14<br>7.3 Survey Method Statement ......................................................................14<br>7.4 Survey Equipment System Descriptions .................................................15<br>7.4.1 Position Fixing System – GNSS ......................................................... 15<br>7.4.2 Survey Data Logging System ............................................................ 15<br>7.4.3 Data Processing System ................................................................... 17<br>7.4.4 Data Exchange Format..................................................................... 19<br>7.4.5 Integrated Bathymetric and Side Scan System.................................... 19<br>7.4.6 Heading &amp; Motion Sensor ................................................................. 20<br>7.4.7 Single Beam Echo Sounder ............................................................... 20<br>7.4.8 Sound Velocity Profiler ..................................................................... 21<br>7.4.9 Self-Recording Tide Gauge ............................................................... 22<br>7.4.10 Acoustic Doppler Current Profiler (ADCP)............................................ 23<br><div>7.4.11 Communication Test ........................................................................ 24</div><div>7.4.12 Marine SSB Radio............................................................................ 24<br>7.4.13 Marine VHF Radio ............................................................................ 25<br>7.4.14 Draught Equipment ......................................................................... 26<br>7.4.15 Spare Equipment ............................................................................ 26<br>8.0 WORK PLAN ...........................................................................................27<br>8.1 Preparation &amp; Mobilization .....................................................................27<br>8.2 Installation of Survey Equipment ...........................................................27<br>8.3 Functional Tests of Multibeam Echo Sounder .........................................27<br>8.4 Calibration of Survey Gyro .....................................................................28<br>8.5 Calibration of Single Beam Echo Sounder ...............................................28<br>8.6 Transit to Survey Site.............................................................................28<br>8.7 Calibration of Multibeam Echo Sounder ..................................................29<br>8.8 Calibration of Multi Beam Echo Sounder .................................................31<br>8.9 Data Cleaning .........................................................................................31<br>8.10 Velocity of Sound in the Water Column ..................................................31<br>8.11 Data Acquisition .....................................................................................32<br>9.0 DATA PROCESSING.................................................................................33<br>9.1 General ..................................................................................................33<br>9.2 Personnel ...............................................................................................33<br>9.3 Post Processing Team ............................................................................33<br>9.4 Hydrographic Data Processing System ...................................................33<br>9.5 Post Processing Workflow ......................................................................34<br>9.6 Rendering of Data/Output......................................................................34<br>9.6.1 Hydrographic Survey Data Report ..................................................... 34<br>9.6.2 Hydrographic Survey Chart............................................................... 34<br>9.6.3 Field Record ................................................................................... 35<br>10.0 SURVEY PLATFORM ................................................................................36<br>11.0 EMERGENCY RESPONSE PLAN ................................................................37<br></div>','https://mega.nz/#F!u3QAyK4I!7VjCZ8EujIG6IgpgYo_JRA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 15:22:02','2019-09-25 17:16:01'),(26,'1060_002_026',2,'Others','JOB HAZARD ANALYSIS SWORD RUN','The objective of this document is to provide the hazard analysis as part of Permit\r\nTo Work (PTW) application requirement of Sword Run works for Post Trenching\r\nWorks at Sungai Johor for Pengerang Gas Pipeline Project (POTCH).','2019-08-30',NULL,'4.0 REFERENCES\r\n[1] ITB Document, Exhibit I – Scope of Work (Corrigendum No. 1)\r\n5.0 JOB HAZARD ANALYSIS (JHA)\r\nThis document shall compromise Job Hazard Analysis (JHA) for the following\r\nactivities:\r\n• Trenching Spread & Equipment Mobilization\r\n• Equipment Setup\r\n• Sword Run\r\n• Diving Operation\r\n• Housekeeping','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................3<br>1.1 CONTRACTOR Scope .................................................................................4<br>2.0 OBJECTIVE ...............................................................................................4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................4<br>3.1 Definitions................................................................................................4<br>3.2 Abbreviations ...........................................................................................4<br>4.0 REFERENCES ............................................................................................5<br>5.0 JOB HAZARD ANALYSIS............................................................................5<br>','https://mega.nz/#F!zuImVKpJ!hQhj-Jh7mtoKMueGO084rA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 15:25:57','2019-09-25 17:16:19'),(27,'1060_002_027',2,'Others','JOB METHOD STATEMENT SWORD RUN','This document is to summarize details specific Sword Run work to be perform at\r\nSungai Johor for Pengerang Gas Pipeline Project.\r\n• To ensure that the works are performed safely and in compliance with the\r\nproject requirement.\r\n• To describe the safety aspect of the task, the key responsibilities of the\r\npersonnel involved, and consumable required.','2019-08-30',NULL,'REFERENCES\r\n[1] POTCH-DD-KLP-PGRO-ENG-PRC-001; Post Trenching Procedure\r\n[2] POTCH-EXE-KLP-PGRO-HSE-JHA-007; Job Hazard Analysis Sword Run\r\n[3] POTCH-DD-KLP-PGRO-HSE-PLN-002; Project Emergency Plan and\r\nPreparedness\r\n[4] POTCH-CON-KLP-PGRO-CON-PRC-001; Post Trenching Equipment\r\nFunctional Test Procedure','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................3<br>1.1 CONTRACTOR Scope .................................................................................4<br>2.0 OBJECTIVE ...............................................................................................4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................5<br>3.1 Definitions................................................................................................5<br>3.2 Abbreviations ...........................................................................................5<br>4.0 REFERENCES ............................................................................................5<br>5.0 RESPONSIBILITES....................................................................................6<br>5.1 Post-trenching Crew ................................................................................6<br>5.1.1 Trenching Superintendent ..................................................................6<br>5.1.2 Trenching Supervisor .........................................................................6<br>5.1.3 Trenching Project Engineer .................................................................6<br>5.1.4 Jetting Technicians ............................................................................7<br>5.1.5 Pump Technicians .............................................................................7<br>5.1.6 Instrumentation Technician ................................................................7<br>6.0 WORK PLAN .............................................................................................8<br>6.1 General ....................................................................................................8<br>6.2 Working Area &amp; Conditions ......................................................................8<br>6.3 Sword Run................................................................................................8<br>6.3.1 Job Preparation .................................................................................8<br>6.3.2 Mobilization on Site ...........................................................................8<br>6.3.3 Equipment Distribution ......................................................................9<br>6.3.4 Operation ....................................................................................... 10<br>6.4 Housekeeping ........................................................................................10<br>7.0 JOB HAZARD ANALYSIS..........................................................................11<br>8.0 FLOW CHART ..........................................................................................11<br>8.1 Sword Survey Flow Chart .......................................................................11<br>','https://mega.nz/#F!jiZQGYjT!cy69pNlW-YPN5zHAOjPgGA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 15:30:55','2019-09-25 17:17:00'),(28,'1060_002_028',2,'Others','PROJECT RISK ASSESSMENT (PRA)','The objective of Pipeline Risk Assessment is to identify, analyse and quantify all\r\npossible risks during the project execution.','2019-08-30',NULL,'CONTRACTOR have jointly conducted the Pipeline Risk Assessment (PRA) with\r\nCOMPANY. The PRA session was held two days at Johor Bahru on 12 February\r\n2019.','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................3<br>1.1 PRA INRODUCTION ..................................................................................4<br>2.0 OBJECTIVE ...............................................................................................4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................4<br>3.1 Definitions................................................................................................4<br>3.2 Abbreviations ...........................................................................................4<br>4.0 PRA STATUS .............................................................................................4<br>5.0 PRA PROCESS...........................................................................................5<br>6.0 LIST OF PRA PARTICIPATION ..................................................................8<br>APPENDIX 1 – ATTENDANCE LIST ......................................................................9<br>APPENDIX 2 – PROJECT KEY ELEMENTS RISK ..................................................13<br>','https://mega.nz/#F!e7BkRA4b!tmLZyrlhjMPQuF3Iwf35vg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 15:54:18','2019-09-25 17:17:22'),(29,'1060_002_029',2,'Others','POST TRENCHING CONSTRUCTABILITY','This document describes the post trenching constructability for Post Trenching\r\nWorks at Sungai Johor for Pengerang Gas Pipeline Project (POTCH) from\r\nKP44+257 to KP45+971.','2019-08-30',NULL,'REFERENCES\r\n[1] POTCH-DD-KLP-PGRO-ENG-PRC-001 Post Trenching Procedure\r\n[2] POTCH-EXE-KLP-PGRO-HSE-PLN-004 Traffic Management\r\n[3] POTCH-EXE-KLP-PGRO-HSE-PLN-003 Environment Management Plan\r\n[4] POTCH-EXE-KLP-PGRO-HSE-PLN-001 Project HSE Plan\r\n[5]- POTCH Tender Doc, 14.0 Exhibit II\r\n– Specification – Engineering\r\nDrawing Compile Signed\r\n[6] - POTCH Tender Doc, 5.0 Exhibit I –\r\nScope of Work\r\n[7] - POTCH Tender Doc, 14.0 Exhibit II\r\n– Specification – Geotechnical\r\nSurvey Report\r\n[8] POTCH-EXE-KLP-PGRO-HSE-JMS-001 Job Method Statement Post\r\nTrenching\r\n[9] POTCH-EXE-KLP-PGRO-PMG-SCH-001 Project Schedule\r\n[10] PGB-A-001-DWG-PL-004 Pipeline Alignment Sheet','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................3<br>1.1 CONTRACTOR Scope .................................................................................4<br>2.0 OBJECTIVE ...............................................................................................4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................4<br>3.1 Definitions................................................................................................4<br>3.2 Abbreviations ...........................................................................................5<br>4.0 REFERENCES ............................................................................................5<br>5.0 EXECUTIVE SUMMARY ..............................................................................6<br>6.0 CONSTRUCTION IMPACTS AND CONSTRUCTABILITY ISSUES ...................7<br>6.1 Traffic Impacts.........................................................................................7<br>6.1.1 Marine Traffic ...................................................................................7<br>6.1.2 Traffic Impact &amp; Management .............................................................7<br>6.2 Environmental Impacts ............................................................................8<br>6.3 Construction Safety ..................................................................................8<br>7.0 POST TRENCHING CONSTRUCTABILITY....................................................9<br>7.1 General ....................................................................................................9<br>7.2 Water Jetting Methodology ......................................................................9<br>7.3 Post Trenching Requirement &amp; Specification..........................................10<br>7.4 Post Trenching Equipment .....................................................................10<br>7.4.1 Trenching Jet Sled SJS 6 .................................................................. 10<br>7.4.2 Supporting Equipment ..................................................................... 11<br>7.5 Post Trenching Operation Manpower .....................................................13<br>7.6 Post Trenching Construction ..................................................................14<br>','https://mega.nz/#F!WqYQzC7Q!XARExMDM3iwDScBF3CFIUg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 16:01:20','2019-09-25 17:17:39'),(30,'1060_002_030',2,'Others','BACKFILLING CONSTRUCTABILITY','This document details the backfilling constructability for Post Trenching Works at\r\nSungai Johor for Pengerang Gas Pipeline Project (POTCH). Backfilling\r\nconstructability perform for on land and underwater area.','2019-08-30',NULL,'REFERENCES\r\n[1] POTCH-CON-KLP-PGRO-CON-PLN-001; Rock Aggregate Transportation\r\nProcedure\r\n[2] POTCH-DD-KLP-PGRO-ENG-PRC-002; Backfilling Procedure\r\n[3] POTCH-EXE-KLP-PGRO-PMG-SCH-001; Project Schedule\r\n[4] POTCH-EXE-KLP-PGRO-HSE-PLN-003; Environment Management Plan\r\n[5] POTCH-CON-KLP-PGRO-ENG-RPT-006; Drop Object Analysis\r\n[6] POTCH-EXE-KLP-PGRO-HSE-PLN-004; Traffic Management Plan\r\n[7] POTCH-EXE-KLP-PGRO-HSE-PLN-001; Project HSE Plan','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................3<br>1.1 CONTRACTOR Scope .................................................................................4<br>2.0 OBJECTIVE ...............................................................................................4<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................4<br>3.1 Definitions................................................................................................4<br>3.2 Abbreviations ...........................................................................................4<br>4.0 REFERENCES ............................................................................................4<br>5.0 EXECUTIVE SUMMARY ..............................................................................5<br>6.0 CONSTRUCTION IMPACTS AND CONSTRUCTABILITY ISSUES ...................5<br>6.1 General ....................................................................................................5<br>6.2 Traffic Impacts.........................................................................................6<br>6.2.1 Marine Traffic ...................................................................................6<br>6.2.2 Traffic Impact &amp; Management .............................................................6<br>6.3 Environment Impacts ...............................................................................7<br>6.4 Construction Safety ..................................................................................7<br>7.0 BACKFILLING CONSTRUCTABILITY ..........................................................8<br>7.1 General ....................................................................................................8<br>7.2 Operation Flow Chart ...............................................................................9<br>7.2.1 On land (Kg Sungai Latoh) .................................................................9<br>7.2.2 Underwater (Sungai Johor, Pulau Juling &amp; Selat Mendana) ................... 10<br>7.3 Backfilling Equipment ............................................................................11<br>7.3.1 Flat Top Barge with Excavator........................................................... 11<br>7.3.2 Flat Top Barge with Fall Pipe............................................................. 12<br>7.3.3 10 Tonne Lorry ............................................................................... 13<br>7.3.4 Excavator....................................................................................... 14<br>','https://mega.nz/#F!2mQgWQpB!Hnqhc-G6V-UbHmYBVVahmw',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 16:05:00','2019-09-25 17:16:37'),(31,'1060_002_031',2,'Project Management Plan','PROJECT EXECUTION PLAN','The purpose of this Project Execution Plan (PEP) is to define the project execution\r\napproach. This will link to other documents plan that will be implemented during\r\nthe Project. This PEP will cover project coordination and administration, quality\r\nassurance and quality control requirements for the Scope of Work (SOW)\r\nperformed by CONTRACTOR.\r\nPEP is governing document that establishes the procedures, activities and tasks to\r\nexecute, monitor and control this Project.','2019-08-30',NULL,'REFERENCES\r\n[1] POTCH-EXE-KLP-PGRO-PMG-PLN-004; Project Quality Plan\r\n[2] POTCH-EXE-KLP-PGRO-PMG-PLN-003; Project Planning Package\r\n[3] POTCH-EXE-KLP-PGRO-PMG-ORG-001; Organization Chart\r\n[4] POTCH-EXE-KLP-PGRO-HSE-PLN-001; Project HSE Plan\r\n[5] POTCH-EXE-KLP-PGRO-PMG-PLN-005; Project Procurement Plan\r\n[6] POTCH-EXE-KLP-PGRO-PMG-PLN-001; Construction Execution Plan (CEP)\r\n[7] POTCH-EXE-KLP-PGRO-CON-PRC-001; Functional Test Procedure\r\n[8] POTCH-EXE-KLP-PGRO-CON-PRC-001; Project Risk Assessment\r\n[9] POTCH-EXE-KLP-PGRO-PMG-PLN-002; Regulatory Approval Plan\r\n[10] POTCH-CON-KLP-PGRO-CON-PLN-001; Transportation Plan','TABLE OF CONTENT<br>1.0 INTRODUCTION........................................................................................4<br>1.1 CONTRACTOR Scope .................................................................................5<br>2.0 OBJECTIVE ...............................................................................................5<br>3.0 DEFINITIONS &amp; ABBREVIATIONS ............................................................5<br>3.1 Definitions................................................................................................5<br>3.2 Abbreviations ...........................................................................................5<br>4.0 REFERENCES ............................................................................................6<br>5.0 QUALITY POLICY &amp; HSE POLICY...............................................................6<br>6.0 QUALITY OBJECTIVES ..............................................................................6<br>7.0 QUALITY ASSURANCE...............................................................................6<br>7.1 Project Quality Audit ................................................................................7<br>7.2 Quality Assurance &amp; Control Mechanism ..................................................7<br>8.0 PROJECT SCHEDULE &amp; MILESTONES.........................................................7<br>9.0 PROJECT COORDINATION &amp; ADMINISTRATION .......................................8<br>9.1 Project Details..........................................................................................8<br>9.2 Contact &amp; Address ....................................................................................8<br>9.3 Project Organization ................................................................................8<br>9.4 Project Team Contact ...............................................................................8<br>9.5 Roles &amp; Responsibilities ...........................................................................9<br>9.6 Project Communication ............................................................................9<br>9.6.1 Introduction .....................................................................................9<br>9.6.2 Commercial/Contractual.....................................................................9<br>9.6.3 Technical (Technical issues which affect man-hour, cost &amp; schedule) ..... 10<br>9.6.4 Walkie Talkie / Mobile Phone ............................................................ 10<br>9.6.5 Technical Issues.............................................................................. 10<br>9.6.6 Technical Instruction (TI) ................................................................. 10<br>9.6.7 Official Complaints .......................................................................... 10<br>9.6.8 Outgoing Correspondence ................................................................ 11<br>9.6.9 Incoming Correspondence ................................................................ 11<br>9.6.10 E-mail Correspondence .................................................................... 11<br>9.7 Project Meetings ....................................................................................11<br>9.7.1 Internal Meeting ............................................................................. 11<br>9.7.2 Weekly Progress Meeting ................................................................. 11<br>9.7.3 Monthly Progress Meeting ................................................................ 12<br>9.7.4 Technical Meeting............................................................................ 12<br>10.0 PROJECT CONTROL &amp; REPORTING ..........................................................12<br>10.1 Project Planning .....................................................................................12<br>10.2 Progress Monitoring ...............................................................................12<br>10.3 Timesheet Control ..................................................................................13<br>10.4 Progress Reporting ................................................................................13<br>11.0 DOCUMENT &amp; DATA CONTROL ................................................................13<br>11.1 Document Control &amp; Distribution ...........................................................13<br>11.2 Submission &amp; Receipt Data ....................................................................14<br>11.3 Document/Drawing Numbering, Revision System &amp; Document/Drawing<br>Formats..................................................................................................14<br><div>11.3.1 Document/Drawing Numbering ......................................................... 14</div><div>11.3.2 Revision System ............................................................................. 15<br>11.3.3 Revision History .............................................................................. 15<br>11.3.4 Document/Drawing Format............................................................... 15<br>11.3.5 Indication of Change........................................................................ 15<br>11.4 Outgoing Correspondence ......................................................................16<br>11.5 Archival &amp; Disposal ................................................................................17<br>11.6 Electronic Document Management System (EDMS) ................................17<br>12.0 DESIGN CONTROL ..................................................................................17<br>12.1 Design Planning .....................................................................................17<br>12.2 Design Input ..........................................................................................17<br>12.3 Technical Clarification ............................................................................18<br>12.4 Design Output Verification .....................................................................18<br>12.5 Incorporation of Comments ...................................................................18<br>12.6 Design Reviews ......................................................................................18<br>12.7 Document Approval ................................................................................19<br>12.8 Design Validation ...................................................................................19<br>12.9 Management of Change ..........................................................................19<br>12.9.1 Design or SOW Changes .................................................................. 19<br>12.9.2 Site Modifications/Change ................................................................ 20<br>13.0 HEALTH, SAFETY &amp; ENVIRONMENT.........................................................20<br>14.0 PROCUREMENT .......................................................................................21<br>15.0 CONSTRUCTION EXECUTION ..................................................................21<br>16.0 FUNCTIONAL TEST .................................................................................22<br>17.0 RISK MANAGEMENT................................................................................22<br>18.0 LIAISON WITH OTHER PARTIES .............................................................22<br>18.1 Local Authorities Approval .....................................................................23<br>19.0 TRANSPORTATION .................................................................................23<br>20.0 FINAL DOCUMENTATION ........................................................................23<br>APPENDIX 1 - QUALITY POLICY &amp; HSE POLICY ................................................24<br>APPENDIX 2 - QUALITY OBJECTIVES................................................................27<br>APPENDIX 3 - CONTRACTOR QMS DOCUMENTATION ........................................29<br>APPENDIX 4 - PROJECT ORGANIZATION CHART...............................................34<br>APPENDIX 5 - PROJECT TEAM CONTACT ...........................................................36<br>APPENDIX 6 - PROJECT TEAM KEY PERSONNEL ROLES &amp; RESPONSIBLITIES ...38<br>APPENDIX 7 - DISTRIBUTION MATRIX.............................................................42<br>APPENDIX 8 - DOCUMENT/DRAWING FORMAT ................................................44<br>APPENDIX 9 - DOCUMENT MANAGEMENT PROCEDURE FOR PCD-PGB/GTR<br>PROJECT...........................................................................................................51<br></div><div><br></div>','https://mega.nz/#F!yiYS1ShI!gj3FzEmqsU22n86eqPKeHA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 16:11:21','2019-09-25 17:17:58');
/*!40000 ALTER TABLE `PROPlanning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROVariation`
--

DROP TABLE IF EXISTS `PROVariation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROVariation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `VariationNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_Classification` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `VariationNo_unique` (`VariationNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROVariation`
--

LOCK TABLES `PROVariation` WRITE;
/*!40000 ALTER TABLE `PROVariation` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROVariation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PersonnalFile`
--

DROP TABLE IF EXISTS `PersonnalFile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PersonnalFile` (
  `PersonalFileID` int(11) NOT NULL AUTO_INCREMENT,
  `FileID` varchar(200) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `ProjectTeamID` int(11) DEFAULT NULL,
  `fo_PersonalFileDesc` varchar(40) DEFAULT NULL,
  `fo_Description` text,
  `fo_Date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`PersonalFileID`),
  UNIQUE KEY `FileID_unique` (`FileID`),
  KEY `EmployeeID` (`EmployeeID`),
  KEY `ProjectTeamID` (`ProjectTeamID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PersonnalFile`
--

LOCK TABLES `PersonnalFile` WRITE;
/*!40000 ALTER TABLE `PersonnalFile` DISABLE KEYS */;
/*!40000 ALTER TABLE `PersonnalFile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProjectTeam`
--

DROP TABLE IF EXISTS `ProjectTeam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProjectTeam` (
  `ProjectTeamID` int(11) NOT NULL AUTO_INCREMENT,
  `EmpNo` varchar(256) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_TermEmployment` varchar(50) DEFAULT NULL,
  `fo_Photo` varchar(40) DEFAULT NULL,
  `fo_Position` varchar(200) DEFAULT NULL,
  `fo_BirthDate` date DEFAULT NULL,
  `fo_HireDate` date DEFAULT NULL,
  `fo_Address` varchar(50) DEFAULT NULL,
  `fo_City` varchar(100) DEFAULT NULL,
  `fo_Region` varchar(100) DEFAULT NULL,
  `fo_PostalCode` varchar(10) DEFAULT NULL,
  `fo_Country` varchar(100) DEFAULT NULL,
  `fo_HomePhone` varchar(24) DEFAULT NULL,
  `fo_Extension` varchar(4) DEFAULT NULL,
  `fo_Notes` text,
  `fo_ReportsTo` int(11) DEFAULT NULL,
  `fo_Acknowledgement` int(11) DEFAULT '0',
  `fo_Induction` tinyint(4) DEFAULT '0',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`ProjectTeamID`),
  UNIQUE KEY `EmpNo_unique` (`EmpNo`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `fo_ReportsTo` (`fo_ReportsTo`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProjectTeam`
--

LOCK TABLES `ProjectTeam` WRITE;
/*!40000 ALTER TABLE `ProjectTeam` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProjectTeam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PurchaseOrder`
--

DROP TABLE IF EXISTS `PurchaseOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PurchaseOrder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `POID` varchar(100) NOT NULL,
  `OrderID` int(10) unsigned DEFAULT '0',
  `fo_Vendor` int(11) unsigned DEFAULT '0',
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `fo_Price` decimal(10,2) DEFAULT '0.00',
  `fo_Description` text,
  `fo_Discount` float(10,2) DEFAULT '0.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `POID_unique` (`POID`),
  KEY `OrderID` (`OrderID`),
  KEY `fo_Vendor` (`fo_Vendor`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurchaseOrder`
--

LOCK TABLES `PurchaseOrder` WRITE;
/*!40000 ALTER TABLE `PurchaseOrder` DISABLE KEYS */;
INSERT INTO `PurchaseOrder` (`id`, `POID`, `OrderID`, `fo_Vendor`, `fo_ShipVia`, `fo_Price`, `fo_Description`, `fo_Discount`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'7016_002_003_0004_001',4,1,1,500.00,'Description of services: \r\nPackage B2 & B3\r\nDokumentasi Sumber Manusia\r\nPerhubungan Pekerja\r\nPengambilan Pekerja\r\nPengurusan Prestasi & Ganjaran\r\nPembangunan Pekerja',0.00,NULL,'1.3.0 Dokumentasi Sumber Manusia\r\n1.3.1. Surat Tawaran\r\n1.3.2. Surat Kenaikan Gaji\r\n1.3.3. Surat Amaran\r\n1.3.4. Deskripsi Kerja\r\n\r\n\r\n1.4. Perhubungan Pekerja\r\n1.4.1. Menyediakan Polisi Syarikat\r\n1.4.2. Menyediakan Peraturan Pejabat, Kedai, DLL\r\n1.4.3. Menyediakan Garis Panduan Kerja (S.O.P.)\r\n\r\n\r\n1.5. Pengambilan Pekerja\r\n1.5.1. Bantuan Penyediaan Iklan Jawatan Kosong\r\n1.5.2. Pemilihan Pekerja\r\n\r\n\r\n1.6. Pengurusan Prestasi & Ganjaran\r\n1.6.1. Rundingan Pengurusan Prestasi Pekerja\r\n1.6.2. Rundingan Ganjaran Pekerja\r\n1.6.3. Rundingan Aktiviti & Program Pekerja\r\n\r\n\r\n1.7. Pembangunan Pekerja\r\n1.7.1. Rundingan Laluan Kerjaya\r\n1.7.2. Rancangan Latihan','<span style=\"box-sizing: border-box; color: rgb(51, 51, 51); font-family: &amp;quot;Open Sans&amp;quot;,&amp;quot;sans-serif&amp;quot;; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; line-height: 107%; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\"><a title=\"Link added by VigLink\" style=\"background-color: transparent; box-sizing: border-box; color: rgb(51, 122, 183); text-decoration: none;\" href=\"http://i.viglink.com/?key=37914f02b1bde5fd8021612f09567851&amp;insertId=1f9f0585dbf8d5e2&amp;type=H&amp;exp=60%3ACI1C55A%3A15&amp;libId=k0mlcguu0100zexu000DLbokk627x&amp;loc=https%3A%2F%2Fwww.contractortalk.com%2Ff16%2Fwork-order-terms-conditions-7805%2F&amp;v=1&amp;iid=1f9f0585dbf8d5e2&amp;opt=true&amp;out=https%3A%2F%2Fwww.amazon.com%2Fdp%2F1074158954&amp;ref=https%3A%2F%2Fwww.google.com%2F&amp;title=Work%20Order%20Terms%20And%20Conditions%20-%20Business%20-%20Contractor%20Talk&amp;txt=%3Cspan%3EGENERAL%20%3C%2Fspan%3E%3Cspan%3EPROVISIONS%3C%2Fspan%3E\" target=\"_blank\"><span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box; color: rgb(8, 75, 130); font-family: &amp;quot;Verdana&amp;quot;,&amp;quot;sans-serif&amp;quot;; line-height: 107%;\"><font size=\"2\" style=\"box-sizing: border-box;\"><span style=\"border-bottom-color: currentColor; border-bottom-style: none; border-bottom-width: medium; border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; border-left-color: currentColor; border-left-style: none; border-left-width: medium; border-right-color: currentColor; border-right-style: none; border-right-width: medium; border-top-color: currentColor; border-top-style: none; border-top-width: medium; box-sizing: border-box; outline-color: invert; outline-style: none; outline-width: 0px;\">GENERAL&nbsp;</span><span style=\"border-bottom-color: currentColor; border-bottom-style: none; border-bottom-width: medium; border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; border-left-color: currentColor; border-left-style: none; border-left-width: medium; border-right-color: currentColor; border-right-style: none; border-right-width: medium; border-top-color: currentColor; border-top-style: none; border-top-width: medium; box-sizing: border-box; outline-color: invert; outline-style: none; outline-width: 0px;\">PROVISIONS</span></font></span></a></span><span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box; color: black; font-family: &amp;quot;Verdana&amp;quot;,&amp;quot;sans-serif&amp;quot;; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; line-height: 107%; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\"><font size=\"2\" style=\"box-sizing: border-box;\">:</font></span></span><span style=\"box-sizing: border-box; color: black; font-family: &amp;quot;Verdana&amp;quot;,&amp;quot;sans-serif&amp;quot;; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; line-height: 107%; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\"><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\"><font size=\"1\" style=\"box-sizing: border-box;\">\r\n<span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">1. All work shall\r\nbe completed in a work-man like manner and in compliance with all codes or\r\nother applicable laws.</span></span><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">\r\n<span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">2. To the extent\r\nrequired by law, all work shall be performed by individuals duly licensed and\r\nauthorized by law to perform said work.</span></span><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">\r\n<span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">3. Vendor at its\r\ndiscretion may engage sub-vendors to perform work hereunder, provided Contract\r\nshall fully pay said sub-vendors and in all instances remain fully responsible\r\nfor proper completion of this Contract.</span></span><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">\r\n<span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">4. All change\r\norders will be in writing and signed by both Purchaser and Vendor, and shall be\r\nincorporated in, and become part of the Contract/PO.</span></span><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">\r\n<span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">5. Vendor warrants\r\nit is accurately insured for injury to its employees and others incurring loss\r\nor injury as a result of Vendor, its employees or sub-vendors.</span></span><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">\r\n<span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">6. Vendor shall at\r\nits own expense obtain all required permits necessary for the work to be\r\nperformed.</span></span><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">\r\n<span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">7. CONFIDENTIALITY.\r\nVendor agrees to keep confidential the terms and conditions of the Order and\r\nall proprietary information disclosed by or on behalf of Purchaser or otherwise\r\nlearned or obtained by Vendor in connection with the Order or the performance\r\nhereof. Vendor will not use any of this information other than in connection\r\nwith the performance of the Order and will not disclose any of this information\r\nexcept to the extent required by law and then only after prior notice to\r\nPurchaser.</span></span><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">\r\n<span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">8. In the event Purchaser\r\nshall fail to pay any periodic or installment payment due hereunder, Vendor may\r\ncease work without penalty or breach of Contract pending payment or resolution\r\nof any dispute.</span></span><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">\r\n<span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">9. Vendor shall not\r\nbe liable for any delays due to circumstances beyond reasonable control\r\nincluding but not limited to: strikes, weather delays, casualty, acts of God or\r\nnature, Fire nor arson, or general unavailability of materials.</span></span><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">\r\n<span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">10. Vendor warrants\r\nall work for a period of _(1) ONE YEAR_ following completion of Contract\r\nobligations.</span></span><br style=\"box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\">\r\n</font><span style=\"background-attachment: scroll; background-clip: border-box; background-color: white; background-image: none; background-origin: padding-box; background-position-x: 0%; background-position-y: 0%; background-repeat: repeat; background-size: auto; box-sizing: border-box;\"><span style=\"box-sizing: border-box; float: none; orphans: 2; -webkit-text-stroke-width: 0px; widows: 2; word-spacing: 0px;\"><font size=\"2\" style=\"box-sizing: border-box;\"><font size=\"1\" style=\"box-sizing: border-box;\">11. Additional\r\nTerms and Conditions to be included with original Contract when applicable</font></font></span></span></span><br>',NULL,NULL,NULL,NULL,'92197300_1568692237.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-17 11:50:37',NULL);
/*!40000 ALTER TABLE `PurchaseOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QA`
--

DROP TABLE IF EXISTS `QA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QA` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Class` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QA`
--

LOCK TABLES `QA` WRITE;
/*!40000 ALTER TABLE `QA` DISABLE KEYS */;
INSERT INTO `QA` (`id`, `DocconNumber`, `BaseLocation`, `fo_DocItem`, `fo_DocumentDescription`, `fo_Class`, `fo_Classification`, `fo_Regdate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_last_modified`) VALUES (1,'6060_001_IP01',1,'IP01 Interested Parties','List of interested parties for organization','Internal use','Process','2019-08-03','Rack 2B, Level 1 File 6060',NULL,'<br>','https://mega.nz/#F!PrBk2aZR!t_7AP67cpkc35Tlu9leg3w',NULL,'PG-QMS-QAC-F6012_QMS_Interested_Parties_',NULL,'27439900_1564886988.png',NULL,NULL,NULL,NULL,4,NULL,'2019-08-03 10:57:15','2019-08-04 10:51:57'),(2,'6060_002_IE01',1,'F6011 INTERNAL EXTERNAL ISSUES','INTERNAL AND EXTERNAL ISSUES','Internal use','Personnel','2019-01-01',NULL,NULL,'<br>','https://mega.nz/#F!3uwGzI5Y!-KdvUkYGeHbCfL9SSlREuw',NULL,'PG-QMS-QAC-F6011_Internal__External_Issu',NULL,'14734600_1564888914.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 11:21:54','2019-08-04 11:23:37'),(3,'6060_003_OM01',1,'OM01 ORGANIZATIONAL PROCESS MANAGEMENT PLAN','ORGANIZATIONAL PROCESS MANAGEMENT PLAN','Internal use','Personnel','2019-01-01',NULL,NULL,'<br>','https://mega.nz/#F!O6hinKZA!AXZZPnzlWvpRNzZrMDQL-g',NULL,'PG-QMS-QAC-OPMP1_ORGANIZATIONAL_PROCESS_',NULL,'84424900_1564890062.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 11:41:02',NULL),(4,'6060_004_OD01',1,'OD01 ORGANIZATIONAL CONTEXT DIAGRAM','ORGANIZATIONAL CONTEXT DIAGRAM','Internal use','Personnel','2019-08-04',NULL,NULL,'<br>','https://mega.nz/#F!7zhGkCCY!7xgbCH4Dh_CaUUXdzseKiw',NULL,'Context_&_Strategy_Plan.pdf',NULL,'66142000_1564890878.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 11:54:38',NULL),(5,'6060_005_CM01',1,'CM01 COMMUNICATION MATRIX','COMMUNICATION MATRIX','Internal use','Personnel','2019-01-01',NULL,NULL,'<br>','https://mega.nz/#F!OrByRKQa!rs5r_qIL0fP0UYmAicDqJQ',NULL,'PG-QMS-QAC-F6041_COMMUNICATION_MATRIX-Ay',NULL,'16088000_1564891427.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 12:03:47','2019-08-04 12:04:16'),(6,'6060_006_RO01',1,'P605 ADDRESSING RISK AND OPPORTUNITIES','ADDRESSING RISK AND OPPORTUNITIES','Internal use','Personnel','2019-09-04',NULL,NULL,'<br>','https://mega.nz/#F!fnAiUSrA!l9AI_-2-eDKbH8SaRHh37Q',NULL,'PG-QMS-QAC-F6051_Addressing_Risks_&_Oppo',NULL,'29803300_1567604773.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 21:46:13','2019-09-04 21:55:26'),(7,'6060_007_TP01',1,'F3035 ANNUAL TRAINING PLAN 2019','KL Petrogas Annual training plan and activities for 2019','Internal use','Training &','2019-09-17',NULL,NULL,'<br>',NULL,NULL,'PG-QMS-HRA-F3035_Training_Plan_2019.pdf',NULL,'90799900_1568693162.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-17 12:06:02',NULL),(8,'6060_008_ISO9001',1,'ISO 9001:2015 CERTIFICATE OF REGISTRATION','ISO 9001:2015 Certificate of registration for KL Petrogas by Certification International (CI Malaysia)','Internal use','Process','2019-09-09',NULL,NULL,'<br>','https://mega.nz/#F!4HgnBaCb!xWUC-8z3laLA1xuBdAL20g',NULL,'KLP_ISO.pdf',NULL,'22828900_1569289505.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-24 09:43:21','2019-09-25 14:11:52');
/*!40000 ALTER TABLE `QA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QuarterlyMeeting`
--

DROP TABLE IF EXISTS `QuarterlyMeeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QuarterlyMeeting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `QmID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `QmID_unique` (`QmID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QuarterlyMeeting`
--

LOCK TABLES `QuarterlyMeeting` WRITE;
/*!40000 ALTER TABLE `QuarterlyMeeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `QuarterlyMeeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Quotation`
--

DROP TABLE IF EXISTS `Quotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Quotation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `QuoID` varchar(100) NOT NULL,
  `OrderID` int(10) unsigned DEFAULT '0',
  `fo_Vendor` int(11) unsigned DEFAULT '0',
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `fo_Price` decimal(10,2) DEFAULT '0.00',
  `fo_Description` text,
  `fo_Discount` float(10,2) DEFAULT '0.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `QuoID_unique` (`QuoID`),
  KEY `OrderID` (`OrderID`),
  KEY `fo_Vendor` (`fo_Vendor`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Quotation`
--

LOCK TABLES `Quotation` WRITE;
/*!40000 ALTER TABLE `Quotation` DISABLE KEYS */;
/*!40000 ALTER TABLE `Quotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Receivables`
--

DROP TABLE IF EXISTS `Receivables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Receivables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ClaimNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `ResourcesID` int(10) unsigned DEFAULT NULL,
  `fo_Classification` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_UnitPrice` float(10,2) DEFAULT '0.00',
  `fo_DocumentDescription` text NOT NULL,
  `fo_Registerdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ClaimNo_unique` (`ClaimNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ResourcesID` (`ResourcesID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Receivables`
--

LOCK TABLES `Receivables` WRITE;
/*!40000 ALTER TABLE `Receivables` DISABLE KEYS */;
/*!40000 ALTER TABLE `Receivables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Recruitment`
--

DROP TABLE IF EXISTS `Recruitment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Recruitment` (
  `RecruitID` int(11) NOT NULL AUTO_INCREMENT,
  `CompID` varchar(200) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `ProjectTeamID` int(11) DEFAULT NULL,
  `fo_RecruitmentSession` varchar(40) DEFAULT NULL,
  `fo_Description` text,
  `fo_Date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`RecruitID`),
  UNIQUE KEY `CompID_unique` (`CompID`),
  KEY `EmployeeID` (`EmployeeID`),
  KEY `ProjectTeamID` (`ProjectTeamID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Recruitment`
--

LOCK TABLES `Recruitment` WRITE;
/*!40000 ALTER TABLE `Recruitment` DISABLE KEYS */;
/*!40000 ALTER TABLE `Recruitment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReportComment`
--

DROP TABLE IF EXISTS `ReportComment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReportComment` (
  `RunningID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PostID` int(10) unsigned DEFAULT '0',
  `TextPost` text,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`RunningID`),
  KEY `PostID` (`PostID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReportComment`
--

LOCK TABLES `ReportComment` WRITE;
/*!40000 ALTER TABLE `ReportComment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ReportComment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RiskandOpportunity`
--

DROP TABLE IF EXISTS `RiskandOpportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RiskandOpportunity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RISKid` varchar(250) NOT NULL,
  `Item` varchar(250) NOT NULL,
  `fo_Description` text,
  `fo_Class` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_Riskregister` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RISKid_unique` (`RISKid`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RiskandOpportunity`
--

LOCK TABLES `RiskandOpportunity` WRITE;
/*!40000 ALTER TABLE `RiskandOpportunity` DISABLE KEYS */;
INSERT INTO `RiskandOpportunity` (`id`, `RISKid`, `Item`, `fo_Description`, `fo_Class`, `fo_Riskregister`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'6040_P601','P601 - DETERMINING CONTEXT OF THE ORGANIZATION','<br>','Quality','2019-09-04',NULL,NULL,'<br>','https://mega.nz/#F!Dr4yDYgR!plUXO24sphOeaOBRnCSbkw',NULL,NULL,NULL,'36322500_1567603183.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 21:19:43','2019-09-04 21:22:10'),(2,'6040_P602','P602 - PERSONNEL ROLES & RESPONSIBILITIES','P602 - PERSONNEL ROLES &amp; RESPONSIBILITIES<br>','Quality','2019-09-04',NULL,NULL,'<br>','https://mega.nz/#F!y7QmQKCS!kPA8nH2EIt2QagEzA8Cy7g',NULL,NULL,NULL,'56216800_1567609502.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 23:05:02','2019-09-04 23:20:17'),(3,'6040_P603','P603 - INCIDENT EVENT NOTIFICATION PROCEDURE','INCIDENT EVENT NOTIFICATION PROCEDURE<br>','Quality','2019-09-05','P603',NULL,'<br>','https://mega.nz/#F!jipC3Ixa!_vRZMx5PNc-_JLfKm_TeYw',NULL,NULL,NULL,'94697800_1567656151.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 12:02:31','2019-09-05 12:03:38'),(4,'6040_P604','P604 - COMMUNICATION, CONSULTATION & PARTICIPATION','COMMUNICATION, CONSULTATION &amp; PARTICIPATION<br>','Quality','2019-09-05','P604',NULL,'<br>','https://mega.nz/#F!C7pEFIIL!lbLrtbBZTNwRw4_gnoKG1w',NULL,NULL,NULL,'30914700_1567656568.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 12:09:28','2019-09-05 12:11:00'),(5,'6040_P605','P605 - ADDRESSING RISK AND OPPORTUNITIES PROCEDURE','ADDRESSING RISK AND OPPORTUNITIES PROCEDURE<br>','Quality','2019-09-05','P605',NULL,'<br>','https://mega.nz/#F!mrx2EaJK!sTqkeMi6V1KVfGoRwz5HKQ',NULL,NULL,NULL,'53038100_1567656922.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 12:15:22','2019-09-05 12:16:21'),(6,'6040_P606','P606 - MANAGEMENT OF CHANGE PROCEDURE','MANAGEMENT OF CHANGE PROCEDURE<br>','Quality','2019-09-05','P606',NULL,'<br>','https://mega.nz/#F!enoSBSaT!2URTkUbzdIwDhhM1xIyDtA',NULL,NULL,NULL,'78629000_1567657213.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 12:20:13','2019-09-05 12:21:20'),(7,'6040_P607','P607 - DOCUMENTED INFORMATION','DOCUMENTED INFORMATION<br>','Quality','2019-09-05','P607',NULL,'<br>','https://mega.nz/#F!Xq5QCSBK!dkd15bdoSeuQvxb7ZgEBDQ',NULL,NULL,NULL,'05074300_1567657518.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 12:25:18','2019-09-05 12:26:29'),(8,'6040_P608','P608 - WORK ENVIRONMENT MONITORING & CONTROL PROCEDURE','WORK ENVIRONMENT MONITORING &amp; CONTROL PROCEDURE<br>','Quality','2019-09-05','P608',NULL,'<br>','https://mega.nz/#F!r65CVKCC!IE9Hwy90Gqvh7Erv7PKrGg',NULL,NULL,NULL,'27737400_1567657935.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 12:32:15','2019-09-05 12:33:14'),(9,'6040_P609','P609 - LEGAL AND OTHER REQUIREMENTS PROCEDURE','LEGAL AND OTHER REQUIREMENTS PROCEDURE<br>','Quality','2019-09-05','P609',NULL,'<br>','https://mega.nz/#F!Ln5WXIwL!R00n8percS2ziqrQZ7MNVg',NULL,NULL,NULL,'79894000_1567659264.jpeg',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-05 12:54:24','2019-09-05 12:55:13');
/*!40000 ALTER TABLE `RiskandOpportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ScheduleWaste`
--

DROP TABLE IF EXISTS `ScheduleWaste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ScheduleWaste` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `worklocID` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `worklocID` (`worklocID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ScheduleWaste`
--

LOCK TABLES `ScheduleWaste` WRITE;
/*!40000 ALTER TABLE `ScheduleWaste` DISABLE KEYS */;
/*!40000 ALTER TABLE `ScheduleWaste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SoftboardComment`
--

DROP TABLE IF EXISTS `SoftboardComment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SoftboardComment` (
  `RunningID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PostID` int(10) unsigned DEFAULT '0',
  `TextPost` text,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`RunningID`),
  KEY `PostID` (`PostID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SoftboardComment`
--

LOCK TABLES `SoftboardComment` WRITE;
/*!40000 ALTER TABLE `SoftboardComment` DISABLE KEYS */;
/*!40000 ALTER TABLE `SoftboardComment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `StakeholderSatisfaction`
--

DROP TABLE IF EXISTS `StakeholderSatisfaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `StakeholderSatisfaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecordID` varchar(256) NOT NULL,
  `RecTitle` varchar(256) DEFAULT NULL,
  `fo_ProjectId` int(10) unsigned NOT NULL,
  `fo_Recources` int(10) unsigned NOT NULL,
  `fo_ClientID` int(10) unsigned NOT NULL,
  `fo_gender` varchar(10) NOT NULL,
  `fo_SurveyType` text NOT NULL,
  `fo_Stakeholder` varchar(256) DEFAULT NULL,
  `fo_Description` text,
  `fo_Regdate` date DEFAULT NULL,
  `fo_website` varchar(200) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecordID_unique` (`RecordID`),
  KEY `fo_ProjectId` (`fo_ProjectId`),
  KEY `fo_Recources` (`fo_Recources`),
  KEY `fo_ClientID` (`fo_ClientID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StakeholderSatisfaction`
--

LOCK TABLES `StakeholderSatisfaction` WRITE;
/*!40000 ALTER TABLE `StakeholderSatisfaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `StakeholderSatisfaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TeamSoftBoard`
--

DROP TABLE IF EXISTS `TeamSoftBoard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TeamSoftBoard` (
  `Postid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Title` varchar(250) NOT NULL,
  `image` varchar(40) DEFAULT NULL,
  `TextPost` text,
  `website` varchar(200) DEFAULT NULL,
  `Ref01` varchar(40) DEFAULT NULL,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`Postid`),
  UNIQUE KEY `Title_unique` (`Title`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TeamSoftBoard`
--

LOCK TABLES `TeamSoftBoard` WRITE;
/*!40000 ALTER TABLE `TeamSoftBoard` DISABLE KEYS */;
INSERT INTO `TeamSoftBoard` (`Postid`, `Title`, `image`, `TextPost`, `website`, `Ref01`, `filed`, `last_modified`) VALUES (1,'Welcome!!','41439300_1564842510.jpg','we welcome all to the online colaborative platform. This will be the starting point of the organization journey towards better coordination of the ISO compliance activity.\r\n\r\nFeel free to comment and promote constructive input to support the organization goal towards success.',NULL,NULL,'2019-08-03 22:28:30',NULL),(2,'KEY ISO 9001 Principles','80456700_1564842604.jpg','ISO 9001:2015 Standard is based on seven Quality Management Principles (QMPs). Quality Management Principles are a set of fundamental beliefs, norms, rules and values that are accepted as true and can be used as a basis for quality management.\r\n\r\nhttp://psaa.com.sa/iso-90012015-qmps/',NULL,NULL,'2019-08-03 22:30:04',NULL);
/*!40000 ALTER TABLE `TeamSoftBoard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ToolBoxMeeting`
--

DROP TABLE IF EXISTS `ToolBoxMeeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ToolBoxMeeting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tbmID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbmID_unique` (`tbmID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ToolBoxMeeting`
--

LOCK TABLES `ToolBoxMeeting` WRITE;
/*!40000 ALTER TABLE `ToolBoxMeeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `ToolBoxMeeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Training`
--

DROP TABLE IF EXISTS `Training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Training` (
  `TrainingID` int(11) NOT NULL AUTO_INCREMENT,
  `TraningNo` varchar(100) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `ProjectTeamID` int(11) DEFAULT NULL,
  `fo_TrainingSession` varchar(40) DEFAULT NULL,
  `fo_Classification` varchar(40) DEFAULT NULL,
  `fo_Description` text,
  `fo_Date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`TrainingID`),
  UNIQUE KEY `TraningNo_unique` (`TraningNo`),
  KEY `EmployeeID` (`EmployeeID`),
  KEY `ProjectTeamID` (`ProjectTeamID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Training`
--

LOCK TABLES `Training` WRITE;
/*!40000 ALTER TABLE `Training` DISABLE KEYS */;
/*!40000 ALTER TABLE `Training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VenPerformance`
--

DROP TABLE IF EXISTS `VenPerformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VenPerformance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `VendPerfNumber` varchar(40) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_SupplierID` int(11) unsigned DEFAULT NULL,
  `fo_NewList` tinyint(4) DEFAULT '0',
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_Perfdate` date DEFAULT NULL,
  `fo_image` varchar(40) DEFAULT NULL,
  `fo_address` text,
  `fo_city` varchar(40) DEFAULT NULL,
  `fo_state` varchar(15) DEFAULT NULL,
  `fo_zip` char(8) DEFAULT NULL,
  `fo_workphone` varchar(40) DEFAULT NULL,
  `fo_mobile` varchar(40) DEFAULT NULL,
  `fo_contactperson` varchar(100) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `VendPerfNumber_unique` (`VendPerfNumber`),
  KEY `fo_SupplierID` (`fo_SupplierID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VenPerformance`
--

LOCK TABLES `VenPerformance` WRITE;
/*!40000 ALTER TABLE `VenPerformance` DISABLE KEYS */;
/*!40000 ALTER TABLE `VenPerformance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkEnvMonitoring`
--

DROP TABLE IF EXISTS `WorkEnvMonitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkEnvMonitoring` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherDetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkEnvMonitoring`
--

LOCK TABLES `WorkEnvMonitoring` WRITE;
/*!40000 ALTER TABLE `WorkEnvMonitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `WorkEnvMonitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkLocation`
--

DROP TABLE IF EXISTS `WorkLocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkLocation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `BaseLocation` varchar(250) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Type` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_Sector` varchar(256) DEFAULT NULL,
  `fo_Zone` varchar(256) DEFAULT NULL,
  `fo_Country` varchar(15) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BaseLocation_unique` (`BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkLocation`
--

LOCK TABLES `WorkLocation` WRITE;
/*!40000 ALTER TABLE `WorkLocation` DISABLE KEYS */;
INSERT INTO `WorkLocation` (`id`, `BaseLocation`, `DocItem`, `fo_DocumentDescription`, `fo_Type`, `fo_Sector`, `fo_Zone`, `fo_Country`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'1020_001','MAIN HQ KLPETROGAS SDN BHD','WORK SITE OFFICE : \r\n Address: B-3A-32 Block B Merchant Square 1, Jalan Tropicana Selatan 1, PJU 3 47410 Petaling Jaya, Selangor .','Head Quaters','KLANG VALLEY','PETALING JAYA','Malaysia',NULL,'Phone: +603 7880 1225\r\n Fax: +603 7880 1226\r\n Email: info@klpetrogas.com\r\n Web: www.klpetrogas.com','<br>','https://mega.nz/#F!i7wkGa4D!ZLdKSE-ZKmRfKAt3mZ_2fQ','www.klpetrogas.com',NULL,NULL,'19616900_1564844792.PNG',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-03 23:06:32',NULL),(2,'1020_002','POTCH PROJECT SITE','POTCH Project Site, Pulau Juling, Penyabong','Work Site','JOHOR','PENGERANG','Malaysia',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 17:27:36',NULL);
/*!40000 ALTER TABLE `WorkLocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkOrder`
--

DROP TABLE IF EXISTS `WorkOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkOrder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `WONumber` varchar(40) NOT NULL,
  `Task` varchar(100) NOT NULL,
  `fo_Critical` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `fo_BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_JobInstruction` text NOT NULL,
  `fo_DetailInstruction` text,
  `fo_Resources` text,
  `fo_Duedate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `WONumber_unique` (`WONumber`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `fo_BaseLocation` (`fo_BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkOrder`
--

LOCK TABLES `WorkOrder` WRITE;
/*!40000 ALTER TABLE `WorkOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `WorkOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkPermit`
--

DROP TABLE IF EXISTS `WorkPermit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkPermit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecNum` varchar(100) NOT NULL,
  `WrLocID` int(10) unsigned DEFAULT '0',
  `fo_Type` varchar(250) NOT NULL DEFAULT 'Unknown',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecNum_unique` (`RecNum`),
  KEY `WrLocID` (`WrLocID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkPermit`
--

LOCK TABLES `WorkPermit` WRITE;
/*!40000 ALTER TABLE `WorkPermit` DISABLE KEYS */;
/*!40000 ALTER TABLE `WorkPermit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batches`
--

DROP TABLE IF EXISTS `batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `batch_no` varchar(40) NOT NULL,
  `fo_item` int(11) DEFAULT NULL,
  `fo_suppliers` int(11) unsigned DEFAULT NULL,
  `fo_manudate` date DEFAULT NULL,
  `fo_expdate` date DEFAULT NULL,
  `fo_Quantity` decimal(10,0) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `fo_otherdetails` text,
  `fo_comments` text,
  `fo_SharedLink1` varchar(200) DEFAULT NULL,
  `fo_SharedLink2` varchar(200) DEFAULT NULL,
  `fo_Ref01` varchar(40) DEFAULT NULL,
  `fo_Ref02` varchar(40) DEFAULT NULL,
  `fo_Photo` varchar(40) DEFAULT NULL,
  `fo_ap_filed` datetime DEFAULT NULL,
  `fo_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `batch_no_unique` (`batch_no`),
  KEY `fo_item` (`fo_item`),
  KEY `fo_suppliers` (`fo_suppliers`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batches`
--

LOCK TABLES `batches` WRITE;
/*!40000 ALTER TABLE `batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `CategoryID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(50) NOT NULL,
  `fo_Description` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Picture` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`CategoryID`),
  UNIQUE KEY `CategoryName_unique` (`CategoryName`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`CategoryID`, `CategoryName`, `fo_Description`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Picture`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'General item','<span style=\'display: inline !important; float: none; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: \"Open Sans\",sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\'>General Item. Available easily off the shelve</span><br>',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'31893300_1564881359.png','2019-08-04 09:15:59',NULL),(2,'Stationery','<span style=\'display: inline !important; float: none; background-color: rgb(255, 255, 255); color: rgb(51, 51, 51); font-family: \"Open Sans\",sans-serif; font-size: 11.93px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px;\'>General Stationery item</span><br>',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'66569800_1564881457.png','2019-08-04 09:17:37','2019-09-06 11:59:44'),(3,'Papers','printing papers',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'42079800_1564882008.png','2019-08-04 09:26:48','2019-09-06 12:00:03');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `EmployeeID` int(11) NOT NULL AUTO_INCREMENT,
  `EmpNo` varchar(256) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_TermEmployment` varchar(50) DEFAULT NULL,
  `fo_Photo` varchar(40) DEFAULT NULL,
  `fo_Position` varchar(200) DEFAULT NULL,
  `fo_BirthDate` date DEFAULT NULL,
  `fo_HireDate` date DEFAULT NULL,
  `fo_Address` varchar(50) DEFAULT NULL,
  `fo_City` varchar(100) DEFAULT NULL,
  `fo_Region` varchar(100) DEFAULT NULL,
  `fo_PostalCode` varchar(10) DEFAULT NULL,
  `fo_Country` varchar(100) DEFAULT NULL,
  `fo_HomePhone` varchar(24) DEFAULT NULL,
  `fo_Extension` varchar(4) DEFAULT NULL,
  `fo_Notes` text,
  `fo_ReportsTo` int(11) DEFAULT NULL,
  `fo_Acknowledgement` int(11) DEFAULT '0',
  `fo_Induction` tinyint(4) DEFAULT '0',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`EmployeeID`),
  UNIQUE KEY `EmpNo_unique` (`EmpNo`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `fo_ReportsTo` (`fo_ReportsTo`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` (`EmployeeID`, `EmpNo`, `Name`, `BaseLocation`, `fo_TermEmployment`, `fo_Photo`, `fo_Position`, `fo_BirthDate`, `fo_HireDate`, `fo_Address`, `fo_City`, `fo_Region`, `fo_PostalCode`, `fo_Country`, `fo_HomePhone`, `fo_Extension`, `fo_Notes`, `fo_ReportsTo`, `fo_Acknowledgement`, `fo_Induction`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'3010_001','Azmi Aziz',1,'Permanent',NULL,'Head, Business Development','1975-07-10','2019-08-27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-27 17:01:27','2019-08-27 17:08:03'),(2,'3010_002','Hashmi Mahmood',1,'Permanent',NULL,'Head, Transportation & Installation Engineering','1971-08-21','2019-08-27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-27 17:02:54','2019-09-24 17:16:47'),(3,'3010_003','Mohd Hatta Bin Zakaria',1,'Permanent',NULL,'Head, Legal & HR','1974-03-31','2019-08-27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-27 17:04:36','2019-08-27 17:09:40'),(4,'3010_004','Zulkifli Mohamad',1,'Permanent',NULL,'Head, Supply Chain Management','1969-03-19','2019-08-27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-27 17:05:26','2019-08-27 17:08:58'),(5,'3010_005','Azri Abas',1,'Permanent',NULL,'Head, Corporate & Finance',NULL,'2019-08-27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-27 17:06:14',NULL),(6,'3010_006','Mohd Amirul Mukmin Bin Endut',1,'Contract',NULL,'Junior Engineer','1994-08-10','2019-08-27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-27 17:11:26',NULL),(7,'3010_007','Wan Nursyafiina Binti Wan Ghazali',1,'Contract',NULL,'Junior Engineer','1994-02-22','2019-07-08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-27 17:12:31','2019-09-18 12:17:45');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_grouppermissions`
--

DROP TABLE IF EXISTS `membership_grouppermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_grouppermissions` (
  `permissionID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupID` int(11) DEFAULT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT '0',
  `allowEdit` tinyint(4) NOT NULL DEFAULT '0',
  `allowDelete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permissionID`)
) ENGINE=MyISAM AUTO_INCREMENT=353 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_grouppermissions`
--

LOCK TABLES `membership_grouppermissions` WRITE;
/*!40000 ALTER TABLE `membership_grouppermissions` DISABLE KEYS */;
INSERT INTO `membership_grouppermissions` (`permissionID`, `groupID`, `tableName`, `allowInsert`, `allowView`, `allowEdit`, `allowDelete`) VALUES (1,2,'OrgContentContext',1,3,3,3),(2,2,'Marketing',1,3,3,3),(3,2,'Client',1,3,3,3),(4,2,'Inquiry',1,3,3,3),(5,2,'DesignProposal',1,3,3,3),(6,2,'ContractDeployment',1,3,3,3),(7,2,'employees',1,3,3,3),(8,2,'Recruitment',1,3,3,3),(9,2,'PersonnalFile',1,3,3,3),(10,2,'Competency',1,3,3,3),(11,2,'Training',1,3,3,3),(12,2,'JD_JS',1,3,3,3),(13,2,'InOutRegister',1,3,3,3),(14,2,'vendor',1,3,3,3),(15,2,'ManagingVendor',1,3,3,3),(16,2,'VenPerformance',1,3,3,3),(17,2,'Logistics',1,3,3,3),(18,2,'Inventory',1,3,3,3),(19,2,'CalibrationCtrl',1,3,3,3),(20,2,'WorkOrder',1,3,3,3),(21,2,'MWO',1,3,3,3),(22,2,'MWOPlanned',1,3,3,3),(23,2,'MWOpreventive',1,3,3,3),(24,2,'MWOproactive',1,3,3,3),(25,2,'MWConditionBased',1,3,3,3),(26,2,'MWOReactive',1,3,3,3),(27,2,'MWOCorrective',1,3,3,3),(28,2,'LogisticRequest',1,3,3,3),(29,2,'orders',1,3,3,3),(30,2,'Quotation',1,3,3,3),(31,2,'PurchaseOrder',1,3,3,3),(32,2,'DeliveryOrder',1,3,3,3),(33,2,'AccountPayables',1,3,3,3),(34,2,'Item',1,3,3,3),(35,2,'categories',1,3,3,3),(36,2,'batches',1,3,3,3),(37,2,'transactions',1,3,3,3),(38,2,'CommConsParticipate',1,3,3,3),(39,2,'ToolBoxMeeting',1,3,3,3),(40,2,'Bi_WeeklyMeeting',1,3,3,3),(41,2,'QuarterlyMeeting',1,3,3,3),(42,2,'Campaign',1,3,3,3),(43,2,'DrillNInspection',1,3,3,3),(44,2,'ManagementVisit',1,3,3,3),(45,2,'EventNotification',1,3,3,3),(46,2,'ActCard',1,3,3,3),(47,2,'KM',1,3,3,3),(48,2,'LegalRegister',1,3,3,3),(49,2,'RiskandOpportunity',1,3,3,3),(50,2,'DocControl',1,3,3,3),(51,2,'DCN',1,3,3,3),(52,2,'ObsoleteRec',1,3,3,3),(53,2,'QA',1,3,3,3),(54,2,'ERP',1,3,3,3),(55,2,'WorkEnvMonitoring',1,3,3,3),(56,2,'ScheduleWaste',1,3,3,3),(57,2,'IncidentReporting',1,3,3,3),(58,2,'MgtofChange',1,3,3,3),(59,2,'IMStrackingNmonitoring',1,3,3,3),(60,2,'IMSDataAnalysis',1,3,3,3),(61,2,'Audit',1,3,3,3),(62,2,'NonConformance',1,3,3,3),(63,2,'ContinualImprovement',1,3,3,3),(64,2,'StakeholderSatisfaction',1,3,3,3),(65,2,'MRM',1,3,3,3),(66,2,'projects',1,3,3,3),(67,2,'WorkLocation',1,3,3,3),(68,2,'WorkPermit',1,3,3,3),(69,2,'ProjectTeam',1,3,3,3),(70,2,'resources',1,3,3,3),(71,2,'PROInitiation',1,3,3,3),(72,2,'PROPlanning',1,3,3,3),(73,2,'PROExecution',1,3,3,3),(74,2,'DailyProgressReport',1,3,3,3),(75,2,'MonthlyTimesheet',1,3,3,3),(76,2,'Breakdown',1,3,3,3),(77,2,'PROControlMonitoring',1,3,3,3),(78,2,'PROVariation',1,3,3,3),(79,2,'PROCompletion',1,3,3,3),(80,2,'Receivables',1,3,3,3),(81,2,'ClaimRecord',1,3,3,3),(82,2,'TeamSoftBoard',1,3,3,3),(83,2,'SoftboardComment',1,3,3,3),(84,2,'IMSReport',1,3,3,3),(85,2,'ReportComment',1,3,3,3),(86,2,'Leadership',1,3,3,3),(87,2,'Approval',1,3,3,3),(88,2,'IMSControl',1,3,3,3),(89,3,'OrgContentContext',0,3,0,0),(90,3,'Marketing',0,3,0,0),(91,3,'Client',0,3,0,0),(92,3,'Inquiry',0,3,0,0),(93,3,'DesignProposal',0,3,0,0),(94,3,'ContractDeployment',0,3,0,0),(95,3,'employees',0,3,0,0),(96,3,'Recruitment',0,3,0,0),(97,3,'PersonnalFile',0,3,0,0),(98,3,'Competency',0,3,0,0),(99,3,'Training',0,3,0,0),(100,3,'JD_JS',0,3,0,0),(101,3,'InOutRegister',0,3,0,0),(102,3,'vendor',0,3,0,0),(103,3,'ManagingVendor',0,3,0,0),(104,3,'VenPerformance',0,3,0,0),(105,3,'Logistics',0,3,0,0),(106,3,'Inventory',0,3,0,0),(107,3,'CalibrationCtrl',0,3,0,0),(108,3,'WorkOrder',0,3,0,0),(109,3,'MWO',0,3,0,0),(110,3,'MWOPlanned',0,3,0,0),(111,3,'MWOpreventive',0,3,0,0),(112,3,'MWOproactive',0,3,0,0),(113,3,'MWConditionBased',0,3,0,0),(114,3,'MWOReactive',0,3,0,0),(115,3,'MWOCorrective',0,3,0,0),(116,3,'LogisticRequest',0,3,0,0),(117,3,'orders',0,3,0,0),(118,3,'Quotation',0,3,0,0),(119,3,'PurchaseOrder',0,3,0,0),(120,3,'DeliveryOrder',0,3,0,0),(121,3,'AccountPayables',0,3,0,0),(122,3,'Item',0,3,0,0),(123,3,'categories',0,3,0,0),(124,3,'batches',0,0,0,0),(125,3,'transactions',0,3,0,0),(126,3,'CommConsParticipate',0,3,0,0),(127,3,'ToolBoxMeeting',0,3,0,0),(128,3,'Bi_WeeklyMeeting',0,3,0,0),(129,3,'QuarterlyMeeting',0,3,0,0),(130,3,'Campaign',0,3,0,0),(131,3,'DrillNInspection',0,3,0,0),(132,3,'ManagementVisit',0,3,0,0),(133,3,'EventNotification',0,3,0,0),(134,3,'ActCard',0,3,0,0),(135,3,'KM',0,3,0,0),(136,3,'LegalRegister',0,3,0,0),(137,3,'RiskandOpportunity',0,3,0,0),(138,3,'DocControl',0,3,0,0),(139,3,'DCN',0,3,0,0),(140,3,'ObsoleteRec',0,3,0,0),(141,3,'QA',0,3,0,0),(142,3,'ERP',0,3,0,0),(143,3,'WorkEnvMonitoring',0,3,0,0),(144,3,'ScheduleWaste',0,3,0,0),(145,3,'IncidentReporting',0,3,0,0),(146,3,'MgtofChange',0,3,0,0),(147,3,'IMStrackingNmonitoring',0,3,0,0),(148,3,'IMSDataAnalysis',0,3,0,0),(149,3,'Audit',0,3,0,0),(150,3,'NonConformance',0,3,0,0),(151,3,'ContinualImprovement',0,3,0,0),(152,3,'StakeholderSatisfaction',0,3,0,0),(153,3,'MRM',0,3,0,0),(154,3,'projects',0,3,0,0),(155,3,'WorkLocation',0,3,0,0),(156,3,'WorkPermit',0,3,0,0),(157,3,'ProjectTeam',0,3,0,0),(158,3,'resources',0,3,0,0),(159,3,'PROInitiation',0,3,0,0),(160,3,'PROPlanning',0,3,0,0),(161,3,'PROExecution',0,3,0,0),(162,3,'DailyProgressReport',0,3,0,0),(163,3,'MonthlyTimesheet',0,3,0,0),(164,3,'Breakdown',0,3,0,0),(165,3,'PROControlMonitoring',0,3,0,0),(166,3,'PROVariation',0,3,0,0),(167,3,'PROCompletion',0,3,0,0),(168,3,'Receivables',0,3,0,0),(169,3,'ClaimRecord',0,3,0,0),(170,3,'TeamSoftBoard',0,3,0,0),(171,3,'SoftboardComment',0,3,0,0),(172,3,'IMSReport',0,3,0,0),(173,3,'ReportComment',0,3,0,0),(174,3,'Leadership',0,3,0,0),(175,3,'Approval',0,3,0,0),(176,3,'IMSControl',0,3,0,0),(177,4,'OrgContentContext',1,3,3,0),(178,4,'Marketing',1,3,3,0),(179,4,'Client',1,3,3,0),(180,4,'Inquiry',1,3,3,0),(181,4,'DesignProposal',1,3,3,0),(182,4,'ContractDeployment',1,3,3,0),(183,4,'employees',1,3,3,0),(184,4,'Recruitment',1,3,3,0),(185,4,'PersonnalFile',1,3,3,0),(186,4,'Competency',1,3,3,0),(187,4,'Training',1,3,3,0),(188,4,'JD_JS',1,3,3,0),(189,4,'InOutRegister',1,3,3,0),(190,4,'vendor',1,3,3,0),(191,4,'ManagingVendor',1,3,3,0),(192,4,'VenPerformance',1,3,3,0),(193,4,'Logistics',1,3,3,0),(194,4,'Inventory',1,3,3,0),(195,4,'CalibrationCtrl',1,3,3,0),(196,4,'WorkOrder',1,3,3,0),(197,4,'MWO',1,3,3,0),(198,4,'MWOPlanned',1,3,3,0),(199,4,'MWOpreventive',1,3,3,0),(200,4,'MWOproactive',1,3,3,0),(201,4,'MWConditionBased',1,3,3,0),(202,4,'MWOReactive',1,3,3,0),(203,4,'MWOCorrective',1,3,3,0),(204,4,'LogisticRequest',1,3,3,0),(205,4,'orders',1,3,3,0),(206,4,'Quotation',1,3,3,0),(207,4,'PurchaseOrder',1,3,3,0),(208,4,'DeliveryOrder',1,3,3,0),(209,4,'AccountPayables',1,3,3,0),(210,4,'Item',1,3,3,0),(211,4,'categories',1,3,3,0),(212,4,'batches',1,3,3,0),(213,4,'transactions',1,3,0,0),(214,4,'CommConsParticipate',1,3,3,0),(215,4,'ToolBoxMeeting',1,3,3,0),(216,4,'Bi_WeeklyMeeting',1,3,3,0),(217,4,'QuarterlyMeeting',1,3,3,0),(218,4,'Campaign',1,3,3,0),(219,4,'DrillNInspection',1,3,3,0),(220,4,'ManagementVisit',1,3,3,0),(221,4,'EventNotification',1,3,3,0),(222,4,'ActCard',1,3,3,0),(223,4,'KM',1,3,3,0),(224,4,'LegalRegister',1,3,3,0),(225,4,'RiskandOpportunity',1,3,3,0),(226,4,'DocControl',1,3,3,0),(227,4,'DCN',1,3,3,0),(228,4,'ObsoleteRec',1,3,3,0),(229,4,'QA',1,3,3,0),(230,4,'ERP',1,3,3,0),(231,4,'WorkEnvMonitoring',1,3,3,0),(232,4,'ScheduleWaste',1,3,3,0),(233,4,'IncidentReporting',1,3,3,0),(234,4,'MgtofChange',1,3,3,0),(235,4,'IMStrackingNmonitoring',1,3,3,0),(236,4,'IMSDataAnalysis',1,3,3,0),(237,4,'Audit',1,3,3,0),(238,4,'NonConformance',1,3,3,0),(239,4,'ContinualImprovement',1,3,3,0),(240,4,'StakeholderSatisfaction',1,3,3,0),(241,4,'MRM',1,3,3,0),(242,4,'projects',1,3,3,0),(243,4,'WorkLocation',1,3,3,0),(244,4,'WorkPermit',1,3,3,0),(245,4,'ProjectTeam',1,3,3,0),(246,4,'resources',1,3,3,0),(247,4,'PROInitiation',1,3,3,0),(248,4,'PROPlanning',1,3,3,0),(249,4,'PROExecution',1,3,3,0),(250,4,'DailyProgressReport',1,3,3,0),(251,4,'MonthlyTimesheet',1,3,3,0),(252,4,'Breakdown',1,3,3,0),(253,4,'PROControlMonitoring',1,3,3,0),(254,4,'PROVariation',1,3,3,0),(255,4,'PROCompletion',1,3,3,0),(256,4,'Receivables',1,3,3,0),(257,4,'ClaimRecord',1,3,3,0),(258,4,'TeamSoftBoard',1,3,3,0),(259,4,'SoftboardComment',1,3,3,0),(260,4,'IMSReport',1,3,3,0),(261,4,'ReportComment',1,3,3,0),(262,4,'Leadership',0,0,0,0),(263,4,'Approval',0,0,0,0),(264,4,'IMSControl',0,3,0,0),(265,5,'OrgContentContext',1,3,3,0),(266,5,'Marketing',1,3,3,0),(267,5,'Client',1,3,3,0),(268,5,'Inquiry',1,3,3,0),(269,5,'DesignProposal',1,3,3,0),(270,5,'ContractDeployment',1,3,3,0),(271,5,'employees',1,3,3,0),(272,5,'Recruitment',1,3,3,0),(273,5,'PersonnalFile',0,0,0,0),(274,5,'Competency',1,3,3,0),(275,5,'Training',1,3,0,0),(276,5,'JD_JS',1,3,3,0),(277,5,'InOutRegister',1,3,3,0),(278,5,'vendor',1,3,3,0),(279,5,'ManagingVendor',1,3,3,0),(280,5,'VenPerformance',1,3,3,0),(281,5,'Logistics',1,3,3,0),(282,5,'Inventory',1,3,3,0),(283,5,'CalibrationCtrl',1,3,3,0),(284,5,'WorkOrder',1,3,3,0),(285,5,'MWO',1,3,3,0),(286,5,'MWOPlanned',1,3,3,0),(287,5,'MWOpreventive',1,3,3,0),(288,5,'MWOproactive',1,3,3,0),(289,5,'MWConditionBased',1,3,3,0),(290,5,'MWOReactive',1,3,3,0),(291,5,'MWOCorrective',1,3,3,0),(292,5,'LogisticRequest',1,3,3,0),(293,5,'orders',1,3,3,0),(294,5,'Quotation',1,3,3,0),(295,5,'PurchaseOrder',1,3,3,0),(296,5,'DeliveryOrder',1,3,3,0),(297,5,'AccountPayables',1,3,3,0),(298,5,'Item',1,3,3,0),(299,5,'categories',1,3,3,0),(300,5,'batches',1,3,3,0),(301,5,'transactions',1,3,3,0),(302,5,'CommConsParticipate',1,3,3,0),(303,5,'ToolBoxMeeting',1,3,3,0),(304,5,'Bi_WeeklyMeeting',1,3,3,0),(305,5,'QuarterlyMeeting',1,3,3,0),(306,5,'Campaign',1,3,3,0),(307,5,'DrillNInspection',1,3,3,0),(308,5,'ManagementVisit',1,3,3,0),(309,5,'EventNotification',1,3,3,0),(310,5,'ActCard',1,3,3,0),(311,5,'KM',1,3,3,0),(312,5,'LegalRegister',1,3,3,0),(313,5,'RiskandOpportunity',1,3,3,0),(314,5,'DocControl',1,3,3,0),(315,5,'DCN',1,3,3,0),(316,5,'ObsoleteRec',1,3,3,0),(317,5,'QA',1,3,3,0),(318,5,'ERP',1,3,3,0),(319,5,'WorkEnvMonitoring',1,3,3,0),(320,5,'ScheduleWaste',1,3,3,0),(321,5,'IncidentReporting',1,3,3,0),(322,5,'MgtofChange',1,3,3,0),(323,5,'IMStrackingNmonitoring',1,3,3,0),(324,5,'IMSDataAnalysis',1,3,3,0),(325,5,'Audit',1,3,3,0),(326,5,'NonConformance',1,3,3,0),(327,5,'ContinualImprovement',1,3,3,0),(328,5,'StakeholderSatisfaction',1,3,3,0),(329,5,'MRM',1,3,3,0),(330,5,'projects',1,3,3,0),(331,5,'WorkLocation',1,3,3,0),(332,5,'WorkPermit',1,3,3,0),(333,5,'ProjectTeam',1,3,3,0),(334,5,'resources',1,3,0,0),(335,5,'PROInitiation',1,3,3,0),(336,5,'PROPlanning',1,3,3,0),(337,5,'PROExecution',1,3,3,0),(338,5,'DailyProgressReport',1,3,3,0),(339,5,'MonthlyTimesheet',1,3,3,0),(340,5,'Breakdown',1,3,3,0),(341,5,'PROControlMonitoring',1,3,3,0),(342,5,'PROVariation',1,3,3,0),(343,5,'PROCompletion',1,3,3,0),(344,5,'Receivables',1,3,3,0),(345,5,'ClaimRecord',1,3,3,0),(346,5,'TeamSoftBoard',1,3,3,0),(347,5,'SoftboardComment',1,3,3,0),(348,5,'IMSReport',1,3,3,0),(349,5,'ReportComment',1,3,3,0),(350,5,'Leadership',1,1,1,0),(351,5,'Approval',0,0,0,0),(352,5,'IMSControl',0,0,0,0);
/*!40000 ALTER TABLE `membership_grouppermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_groups`
--

DROP TABLE IF EXISTS `membership_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_groups` (
  `groupID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `description` text,
  `allowSignup` tinyint(4) DEFAULT NULL,
  `needsApproval` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`groupID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_groups`
--

LOCK TABLES `membership_groups` WRITE;
/*!40000 ALTER TABLE `membership_groups` DISABLE KEYS */;
INSERT INTO `membership_groups` (`groupID`, `name`, `description`, `allowSignup`, `needsApproval`) VALUES (1,'anonymous','Anonymous group created automatically on 2019-06-17',0,0),(2,'Admins','Admin group created automatically on 2019-06-17',0,1),(3,'AUDITOR','AUDITOR CAN ONLY VIEW RECORDS',1,0),(4,'DCC','DOCUMENT CONTROL COORDINATOR',1,1),(5,'STAFF','STAFF MEMBER',1,1);
/*!40000 ALTER TABLE `membership_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_userpermissions`
--

DROP TABLE IF EXISTS `membership_userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_userpermissions` (
  `permissionID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `memberID` varchar(20) NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT '0',
  `allowEdit` tinyint(4) NOT NULL DEFAULT '0',
  `allowDelete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permissionID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_userpermissions`
--

LOCK TABLES `membership_userpermissions` WRITE;
/*!40000 ALTER TABLE `membership_userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `membership_userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_userrecords`
--

DROP TABLE IF EXISTS `membership_userrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_userrecords` (
  `recID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tableName` varchar(100) DEFAULT NULL,
  `pkValue` varchar(255) DEFAULT NULL,
  `memberID` varchar(20) DEFAULT NULL,
  `dateAdded` bigint(20) unsigned DEFAULT NULL,
  `dateUpdated` bigint(20) unsigned DEFAULT NULL,
  `groupID` int(11) DEFAULT NULL,
  PRIMARY KEY (`recID`),
  KEY `pkValue` (`pkValue`),
  KEY `tableName` (`tableName`),
  KEY `memberID` (`memberID`),
  KEY `groupID` (`groupID`)
) ENGINE=MyISAM AUTO_INCREMENT=372 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_userrecords`
--

LOCK TABLES `membership_userrecords` WRITE;
/*!40000 ALTER TABLE `membership_userrecords` DISABLE KEYS */;
INSERT INTO `membership_userrecords` (`recID`, `tableName`, `pkValue`, `memberID`, `dateAdded`, `dateUpdated`, `groupID`) VALUES (1,'IMSReport','1','adminpetrogas',1560860581,1560860581,2),(2,'IMSControl','1','adminpetrogas',1560860770,1560860770,2),(3,'IMSControl','2','adminpetrogas',1560861556,1560861556,2),(4,'IMSControl','3','adminpetrogas',1560861647,1560861647,2),(5,'IMSControl','4','adminpetrogas',1560861694,1560861694,2),(6,'QA','1','administrator',1564801035,1564887117,2),(7,'Leadership','1','adminpetrogas',1564809434,1564809434,2),(8,'Leadership','2','adminpetrogas',1564809500,1564809500,2),(9,'Leadership','3','adminpetrogas',1564810733,1564810733,2),(10,'TeamSoftBoard','1','adminpetrogas',1564842510,1564842510,2),(11,'TeamSoftBoard','2','adminpetrogas',1564842604,1564842604,2),(12,'projects','1','adminpetrogas',1564842993,1564843560,2),(13,'WorkLocation','1','adminpetrogas',1564844792,1564844792,2),(14,'Client','1','adminpetrogas',1564845490,1564845490,2),(15,'categories','1','adminpetrogas',1564881359,1564881359,2),(16,'categories','2','adminpetrogas',1564881457,1567742384,2),(17,'categories','3','adminpetrogas',1564882008,1567742403,2),(18,'vendor','1','adminpetrogas',1564883247,1564883247,2),(19,'Item','1','adminpetrogas',1564883350,1564883350,2),(20,'Logistics','1','adminpetrogas',1564883634,1566801682,2),(21,'DocControl','1','adminpetrogas',1564885818,1569298380,2),(22,'QA','2','adminpetrogas',1564888914,1564889017,2),(23,'QA','3','adminpetrogas',1564890062,1564890062,2),(24,'QA','4','adminpetrogas',1564890878,1564890878,2),(25,'QA','5','adminpetrogas',1564891427,1564891456,2),(26,'DocControl','2','adminpetrogas',1564892737,1569907945,2),(27,'DocControl','3','adminpetrogas',1564892978,1564893110,2),(28,'DocControl','4','adminpetrogas',1564893588,1566878327,2),(29,'DocControl','5','adminpetrogas',1564893785,1564910798,2),(30,'DocControl','6','adminpetrogas',1564899541,1564899576,2),(31,'DocControl','7','adminpetrogas',1564899919,1564899919,2),(32,'DocControl','8','adminpetrogas',1564900110,1564900110,2),(33,'DocControl','9','adminpetrogas',1564900410,1564900410,2),(34,'DocControl','10','adminpetrogas',1565099652,1566878439,2),(35,'DocControl','11','adminpetrogas',1565179899,1565180359,2),(36,'DocControl','12','adminpetrogas',1565180324,1565180324,2),(37,'DocControl','13','adminpetrogas',1565180634,1566878504,2),(38,'DocControl','14','adminpetrogas',1565190521,1565190521,2),(39,'DocControl','15','adminpetrogas',1565190918,1565190918,2),(40,'DocControl','16','adminpetrogas',1565191056,1565191056,2),(41,'DocControl','17','adminpetrogas',1565191300,1566878578,2),(42,'DocControl','18','adminpetrogas',1565191422,1566894833,2),(43,'DocControl','19','adminpetrogas',1565191767,1565191767,2),(44,'DocControl','20','adminpetrogas',1565191914,1566878650,2),(45,'DocControl','21','adminpetrogas',1565192343,1565192343,2),(46,'DocControl','22','adminpetrogas',1565192424,1566056771,2),(47,'DocControl','23','adminpetrogas',1565265285,1566897917,2),(48,'DocControl','24','adminpetrogas',1565265475,1565265475,2),(49,'DocControl','25','adminpetrogas',1565265719,1565265719,2),(50,'DocControl','26','adminpetrogas',1565266022,1566879218,2),(51,'DocControl','27','adminpetrogas',1565266333,1565266333,2),(52,'DocControl','28','adminpetrogas',1565266476,1565266476,2),(53,'DocControl','29','adminpetrogas',1565359553,1565359553,2),(54,'DocControl','30','adminpetrogas',1565359704,1566879297,2),(55,'DocControl','31','adminpetrogas',1565360008,1565360008,2),(56,'DocControl','32','adminpetrogas',1565360154,1565360154,2),(57,'DocControl','33','adminpetrogas',1565360298,1565360298,2),(58,'DocControl','34','adminpetrogas',1565360447,1565360491,2),(59,'DocControl','35','adminpetrogas',1565360651,1567478453,2),(60,'DocControl','36','adminpetrogas',1565360783,1565360783,2),(61,'DocControl','37','adminpetrogas',1565360888,1565360888,2),(62,'DocControl','38','adminpetrogas',1565423727,1566898185,2),(63,'DocControl','39','adminpetrogas',1565423902,1565423902,2),(64,'DocControl','40','adminpetrogas',1565424297,1565424297,2),(65,'DocControl','41','adminpetrogas',1565424475,1565424475,2),(66,'DocControl','42','adminpetrogas',1565444717,1566879459,2),(67,'DocControl','43','adminpetrogas',1565444838,1565444838,2),(68,'DocControl','44','adminpetrogas',1565444941,1565444941,2),(69,'DocControl','45','adminpetrogas',1565525978,1566879512,2),(70,'DocControl','46','adminpetrogas',1565526099,1565526099,2),(71,'DocControl','47','adminpetrogas',1565526220,1565526220,2),(72,'DocControl','48','adminpetrogas',1565526296,1565526296,2),(73,'DocControl','49','adminpetrogas',1565526381,1565526381,2),(74,'DocControl','50','adminpetrogas',1565526516,1566879567,2),(75,'DocControl','51','adminpetrogas',1565526666,1565526666,2),(76,'DocControl','52','adminpetrogas',1565526785,1565526785,2),(77,'DocControl','53','adminpetrogas',1565526873,1565526873,2),(78,'DocControl','54','adminpetrogas',1565528491,1566879904,2),(79,'DocControl','55','adminpetrogas',1565528622,1565528622,2),(80,'DocControl','56','adminpetrogas',1565528777,1565528777,2),(81,'DocControl','57','adminpetrogas',1565528985,1566879960,2),(82,'DocControl','58','adminpetrogas',1565529134,1565529134,2),(83,'DocControl','59','adminpetrogas',1565529273,1565529273,2),(84,'DocControl','60','adminpetrogas',1565529406,1566880034,2),(85,'DocControl','61','adminpetrogas',1565529522,1565529522,2),(86,'DocControl','62','adminpetrogas',1565533995,1566880086,2),(87,'DocControl','63','adminpetrogas',1565534082,1566056731,2),(88,'DocControl','64','adminpetrogas',1565534187,1565534187,2),(89,'DocControl','65','adminpetrogas',1565534380,1566898580,2),(90,'DocControl','66','adminpetrogas',1565534555,1565534555,2),(91,'DocControl','67','adminpetrogas',1565698700,1565698700,2),(92,'DocControl','68','adminpetrogas',1565698809,1565698809,2),(93,'DocControl','69','adminpetrogas',1565698886,1565698886,2),(94,'DocControl','70','adminpetrogas',1565699037,1566879706,2),(95,'DocControl','71','adminpetrogas',1565699125,1565699125,2),(96,'DocControl','72','adminpetrogas',1565699235,1567600621,2),(97,'DocControl','73','adminpetrogas',1565699615,1566879782,2),(98,'DocControl','74','adminpetrogas',1565699707,1565699707,2),(99,'DocControl','75','adminpetrogas',1565700067,1567600441,2),(100,'DocControl','76','adminpetrogas',1565700206,1567600500,2),(101,'DocControl','77','adminpetrogas',1565700408,1566879838,2),(102,'DocControl','78','adminpetrogas',1565700592,1565700592,2),(103,'DocControl','79','adminpetrogas',1565701221,1566056687,2),(104,'DocControl','80','adminpetrogas',1565764303,1566964640,2),(105,'DocControl','81','adminpetrogas',1565764428,1566056525,2),(106,'DocControl','82','adminpetrogas',1565764591,1565764591,2),(107,'DocControl','83','adminpetrogas',1565764701,1565764701,2),(108,'DocControl','84','adminpetrogas',1565764942,1566880199,2),(109,'DocControl','85','adminpetrogas',1565976770,1565976770,2),(110,'DocControl','86','adminpetrogas',1565976887,1565976887,2),(111,'DocControl','87','adminpetrogas',1565977005,1566880258,2),(112,'DocControl','88','adminpetrogas',1565977122,1565977122,2),(113,'DocControl','89','adminpetrogas',1565977924,1565977924,2),(114,'DocControl','90','adminpetrogas',1565978128,1566880318,2),(115,'DocControl','91','adminpetrogas',1565978249,1565978249,2),(116,'DocControl','92','adminpetrogas',1565978381,1565978381,2),(117,'DocControl','93','adminpetrogas',1565982903,1566975817,2),(127,'DocControl','97','adminpetrogas',1566451322,1566880632,2),(126,'DocControl','96','adminpetrogas',1566451139,1566880548,2),(125,'DocControl','95','adminpetrogas',1566450972,1566880493,2),(124,'DocControl','94','adminpetrogas',1566450768,1566880441,2),(123,'projects','2','adminpetrogas',1566445857,1567745245,2),(128,'DocControl','98','adminpetrogas',1566451535,1566880682,2),(129,'DocControl','99','adminpetrogas',1566451723,1566880736,2),(130,'DocControl','100','adminpetrogas',1566451873,1566880787,2),(131,'DocControl','101','adminpetrogas',1566452023,1566880841,2),(132,'DocControl','102','adminpetrogas',1566452165,1566880895,2),(133,'DocControl','103','adminpetrogas',1566452306,1566880953,2),(134,'DocControl','104','adminpetrogas',1566452535,1566881007,2),(135,'DocControl','105','adminpetrogas',1566452674,1566550470,2),(136,'DocControl','106','adminpetrogas',1566452808,1566550259,2),(137,'DocControl','107','adminpetrogas',1566453002,1566550163,2),(138,'DocControl','108','adminpetrogas',1566453167,1566550079,2),(139,'Client','2','adminpetrogas',1566455924,1566455924,2),(140,'Inquiry','1','adminpetrogas',1566456263,1566962271,2),(141,'vendor','2','adminpetrogas',1566462878,1568771905,2),(142,'Client','3','adminpetrogas',1566463682,1566463682,2),(144,'Audit','1','adminpetrogas',1566533671,1566533671,2),(145,'Audit','2','adminpetrogas',1566533771,1570503032,2),(146,'ContinualImprovement','1','adminpetrogas',1566534149,1566552436,2),(147,'ContinualImprovement','2','adminpetrogas',1566553590,1566887170,2),(148,'ContinualImprovement','3','adminpetrogas',1566554385,1567473020,2),(149,'DocControl','109','adminpetrogas',1566611020,1566611020,2),(150,'ContinualImprovement','4','adminpetrogas',1566790754,1566887557,2),(151,'ContinualImprovement','5','adminpetrogas',1566790913,1567472349,2),(152,'ContinualImprovement','6','adminpetrogas',1566791029,1566887908,2),(153,'ContinualImprovement','7','adminpetrogas',1566791096,1566888036,2),(154,'ContinualImprovement','8','adminpetrogas',1566791143,1566888176,2),(155,'PROPlanning','1','adminpetrogas',1566799588,1567758434,2),(156,'Client','4','adminpetrogas',1566799961,1566799961,2),(157,'Client','5','adminpetrogas',1566800687,1566800687,2),(158,'Client','6','adminpetrogas',1566800982,1569903689,2),(159,'Inquiry','2','adminpetrogas',1566890124,1566962037,2),(160,'DesignProposal','1','adminpetrogas',1566890550,1568706949,2),(161,'employees','1','adminpetrogas',1566896487,1566896883,2),(162,'employees','2','adminpetrogas',1566896574,1569316607,2),(163,'employees','3','adminpetrogas',1566896676,1566896980,2),(164,'employees','4','adminpetrogas',1566896726,1566896938,2),(165,'employees','5','adminpetrogas',1566896774,1566896774,2),(166,'employees','6','adminpetrogas',1566897086,1566897086,2),(167,'employees','7','adminpetrogas',1566897151,1568780265,2),(168,'Inquiry','3','adminpetrogas',1566961842,1567698546,2),(169,'Audit','3','adminpetrogas',1567055956,1570503268,2),(170,'PROPlanning','2','adminpetrogas',1567134833,1567758483,2),(171,'PROPlanning','3','adminpetrogas',1567135370,1567758507,2),(172,'PROPlanning','4','adminpetrogas',1567135837,1567758530,2),(173,'PROPlanning','5','adminpetrogas',1567136084,1567758557,2),(174,'PROPlanning','6','adminpetrogas',1567136264,1567758755,2),(175,'PROPlanning','7','adminpetrogas',1567136438,1567758964,2),(176,'PROExecution','1','adminpetrogas',1567137136,1567138042,2),(177,'PROPlanning','8','adminpetrogas',1567138317,1567759293,2),(178,'PROPlanning','9','adminpetrogas',1567138640,1569402403,2),(179,'PROPlanning','10','adminpetrogas',1567138957,1569402541,2),(180,'PROPlanning','11','adminpetrogas',1567139119,1569402562,2),(181,'PROPlanning','12','adminpetrogas',1567139344,1569402679,2),(182,'PROPlanning','13','adminpetrogas',1567139590,1569402703,2),(183,'PROPlanning','14','adminpetrogas',1567139847,1569402729,2),(184,'PROPlanning','15','adminpetrogas',1567140088,1569402753,2),(185,'PROPlanning','16','adminpetrogas',1567140236,1569402772,2),(186,'PROPlanning','17','adminpetrogas',1567140510,1569402791,2),(187,'PROPlanning','18','adminpetrogas',1567140726,1569402820,2),(188,'PROPlanning','19','adminpetrogas',1567140902,1569402840,2),(189,'PROPlanning','20','adminpetrogas',1567141078,1569402860,2),(190,'PROPlanning','21','adminpetrogas',1567141265,1569402879,2),(191,'PROPlanning','22','adminpetrogas',1567141438,1569402902,2),(192,'projects','3','adminpetrogas',1567148857,1567148864,2),(193,'PROPlanning','23','adminpetrogas',1567149177,1569402921,2),(194,'PROPlanning','24','adminpetrogas',1567149439,1569402940,2),(195,'PROPlanning','25','adminpetrogas',1567149722,1569402961,2),(196,'PROPlanning','26','adminpetrogas',1567149957,1569402979,2),(197,'PROPlanning','27','adminpetrogas',1567150255,1569403020,2),(198,'PROPlanning','28','adminpetrogas',1567151658,1569403042,2),(199,'PROPlanning','29','adminpetrogas',1567152080,1569403059,2),(200,'PROPlanning','30','adminpetrogas',1567152300,1569402997,2),(201,'PROPlanning','31','adminpetrogas',1567152681,1569403078,2),(202,'DocControl','110','adminpetrogas',1567342662,1567342662,2),(203,'DocControl','111','adminpetrogas',1567415661,1567415661,2),(204,'DocControl','112','adminpetrogas',1567415830,1567415830,2),(205,'DocControl','113','adminpetrogas',1567415948,1567415948,2),(206,'DocControl','114','adminpetrogas',1567435722,1567435722,2),(207,'DocControl','115','adminpetrogas',1567435798,1567435798,2),(208,'DocControl','116','adminpetrogas',1567435953,1567435953,2),(209,'DocControl','117','adminpetrogas',1567436331,1567438255,2),(210,'DocControl','118','adminpetrogas',1567436414,1567478666,2),(211,'DocControl','119','adminpetrogas',1567437181,1567438206,2),(212,'DocControl','120','adminpetrogas',1567437720,1567437720,2),(213,'DocControl','121','adminpetrogas',1567437825,1567437825,2),(214,'DocControl','122','adminpetrogas',1567437925,1567437925,2),(215,'DocControl','123','adminpetrogas',1567438110,1567438168,2),(216,'DocControl','124','adminpetrogas',1567439184,1567439184,2),(217,'DocControl','125','adminpetrogas',1567439329,1567439329,2),(218,'DocControl','126','adminpetrogas',1567439551,1567439551,2),(219,'DocControl','127','adminpetrogas',1567439763,1567439763,2),(220,'DocControl','128','adminpetrogas',1567439843,1570437702,2),(221,'DocControl','129','adminpetrogas',1567439909,1567439909,2),(222,'DocControl','130','adminpetrogas',1567440878,1567440878,2),(223,'DocControl','131','adminpetrogas',1567440970,1567440970,2),(224,'DocControl','132','adminpetrogas',1567441227,1567441227,2),(225,'DocControl','133','adminpetrogas',1567441431,1567441431,2),(226,'DocControl','134','adminpetrogas',1567441632,1567441632,2),(227,'DocControl','135','adminpetrogas',1567441875,1567441875,2),(228,'DocControl','136','adminpetrogas',1567442027,1567442027,2),(229,'DocControl','137','adminpetrogas',1567442292,1567442292,2),(230,'DocControl','138','adminpetrogas',1567442468,1567442468,2),(231,'DocControl','139','adminpetrogas',1567442611,1567442611,2),(232,'DocControl','140','adminpetrogas',1567475578,1567475578,2),(233,'DocControl','141','adminpetrogas',1567475682,1567475682,2),(234,'DocControl','142','adminpetrogas',1567475830,1567475830,2),(235,'DocControl','143','adminpetrogas',1567475940,1567475940,2),(236,'DocControl','144','adminpetrogas',1567476166,1567476166,2),(237,'DocControl','145','adminpetrogas',1567476250,1571288961,2),(238,'DocControl','146','adminpetrogas',1567476305,1567476305,2),(239,'DocControl','147','adminpetrogas',1567476389,1567476389,2),(240,'DocControl','148','adminpetrogas',1567476481,1567476481,2),(241,'DocControl','149','adminpetrogas',1567476546,1567476546,2),(242,'DocControl','150','adminpetrogas',1567476813,1567476813,2),(243,'DocControl','151','adminpetrogas',1567476943,1567476943,2),(244,'DocControl','152','adminpetrogas',1567477101,1567477101,2),(245,'DocControl','153','adminpetrogas',1567477205,1567477205,2),(246,'DocControl','154','adminpetrogas',1567477395,1567477395,2),(247,'DocControl','155','adminpetrogas',1567477475,1567477475,2),(248,'DocControl','156','adminpetrogas',1567477550,1567477550,2),(249,'projects','4','adminpetrogas',1567565060,1567565076,2),(250,'projects','5','adminpetrogas',1567565141,1567565141,2),(251,'Inventory','6','adminpetrogas',1567579732,1568690577,2),(252,'Inventory','7','adminpetrogas',1567580084,1568691225,2),(253,'Inventory','8','adminpetrogas',1567580304,1568691738,2),(254,'Inventory','9','adminpetrogas',1567580517,1567740808,2),(255,'Inventory','10','adminpetrogas',1567580788,1567740866,2),(256,'Inventory','11','adminpetrogas',1567581062,1567740841,2),(257,'RiskandOpportunity','1','adminpetrogas',1567603183,1567603330,2),(258,'OrgContentContext','1','adminpetrogas',1567603755,1567610519,2),(259,'QA','6','adminpetrogas',1567604773,1567605326,2),(260,'RiskandOpportunity','2','adminpetrogas',1567609502,1567610417,2),(261,'OrgContentContext','2','adminpetrogas',1567609856,1567610542,2),(262,'OrgContentContext','3','adminpetrogas',1567651074,1567651074,2),(263,'OrgContentContext','4','adminpetrogas',1567651994,1567652079,2),(264,'OrgContentContext','5','adminpetrogas',1567654345,1567654433,2),(265,'OrgContentContext','6','adminpetrogas',1567654687,1567654823,2),(266,'OrgContentContext','7','adminpetrogas',1567655074,1567655158,2),(267,'OrgContentContext','8','adminpetrogas',1567655444,1567655511,2),(268,'RiskandOpportunity','3','adminpetrogas',1567656151,1567656218,2),(269,'RiskandOpportunity','4','adminpetrogas',1567656568,1567656660,2),(270,'RiskandOpportunity','5','adminpetrogas',1567656922,1567656981,2),(271,'RiskandOpportunity','6','adminpetrogas',1567657213,1567657280,2),(272,'RiskandOpportunity','7','adminpetrogas',1567657518,1567657589,2),(273,'RiskandOpportunity','8','adminpetrogas',1567657935,1567657994,2),(274,'RiskandOpportunity','9','adminpetrogas',1567659264,1567659313,2),(275,'OrgContentContext','9','adminpetrogas',1567661700,1567661767,2),(276,'Client','7','adminpetrogas',1567694601,1567694601,2),(277,'Client','8','adminpetrogas',1567694797,1567694797,2),(278,'Inquiry','4','adminpetrogas',1567694906,1567694978,2),(279,'Client','9','adminpetrogas',1567695213,1569203493,2),(280,'Inquiry','5','adminpetrogas',1567695390,1569465433,2),(281,'orders','1','adminpetrogas',1567741161,1568256115,2),(282,'orders','2','adminpetrogas',1567741445,1568256152,2),(283,'orders','3','adminpetrogas',1567741501,1568256184,2),(284,'orders','4','adminpetrogas',1567741550,1568256225,2),(285,'orders','5','adminpetrogas',1567741591,1568256256,2),(286,'orders','6','adminpetrogas',1567741632,1568256302,2),(287,'MWO','1','adminpetrogas',1567742808,1567742808,2),(288,'MWO','2','adminpetrogas',1567742879,1567742879,2),(289,'MWO','3','adminpetrogas',1567742943,1567742943,2),(290,'MWO','4','adminpetrogas',1567742967,1567742967,2),(291,'MWO','5','adminpetrogas',1567743039,1567743039,2),(292,'MWO','6','adminpetrogas',1567743102,1567743102,2),(293,'MWO','7','adminpetrogas',1567743150,1567743170,2),(294,'MWO','8','adminpetrogas',1567743203,1567743203,2),(295,'MWO','9','adminpetrogas',1567743284,1567743284,2),(296,'MWO','10','adminpetrogas',1567743348,1567743348,2),(297,'MWO','11','adminpetrogas',1567743399,1567743399,2),(298,'MWO','12','adminpetrogas',1567743421,1567743421,2),(299,'InOutRegister','2','adminpetrogas',1567759610,1567760244,2),(300,'InOutRegister','3','adminpetrogas',1567759879,1567760217,2),(301,'InOutRegister','4','adminpetrogas',1567760149,1567760231,2),(302,'WorkLocation','2','adminpetrogas',1567762056,1567762056,2),(303,'Inventory','12','adminpetrogas',1568690475,1568690475,2),(304,'Inventory','13','adminpetrogas',1568691109,1568691109,2),(305,'Inventory','14','adminpetrogas',1568691656,1568691747,2),(306,'PurchaseOrder','1','adminpetrogas',1568692237,1568692237,2),(307,'QA','7','adminpetrogas',1568693162,1568693162,2),(308,'CommConsParticipate','1','adminpetrogas',1568693474,1568947896,2),(309,'DesignProposal','2','adminpetrogas',1568706330,1568778930,2),(310,'Client','10','adminpetrogas',1568707312,1568707312,2),(311,'Inquiry','6','adminpetrogas',1568707561,1569397962,2),(335,'InOutRegister','5','adminpetrogas',1569409111,1569409230,2),(313,'Inquiry','7','adminpetrogas',1568708011,1569397873,2),(336,'InOutRegister','6','adminpetrogas',1569409475,1569409475,2),(319,'vendor','5','nursafiina',1568778836,1568779320,5),(316,'vendor','3','nursafiina',1568775759,1568779446,5),(317,'vendor','4','nursafiina',1568778220,1568779363,5),(326,'DesignProposal','7','adminpetrogas',1568946822,1568946822,2),(320,'vendor','6','nursafiina',1568779278,1568779278,5),(321,'Inquiry','8','amirul',1568779445,1568779445,5),(322,'ContractDeployment','1','amirul',1568779706,1568780433,5),(323,'vendor','7','nursafiina',1568779779,1568779779,5),(324,'vendor','8','nursafiina',1568780106,1568780119,5),(325,'MRM','1','adminpetrogas',1568787987,1568788781,2),(327,'Inquiry','9','adminpetrogas',1569203614,1569461633,2),(328,'DesignProposal','8','adminpetrogas',1569203981,1569291532,2),(329,'CommConsParticipate','2','administrator',1569207662,1569207662,2),(330,'QA','8','administrator',1569289401,1569391912,2),(331,'Inquiry','10','administrator',1569290449,1571978429,2),(338,'InOutRegister','8','adminpetrogas',1569409804,1569409804,2),(337,'InOutRegister','7','adminpetrogas',1569409686,1569409686,2),(334,'DesignProposal','11','administrator',1569294003,1571221175,2),(339,'InOutRegister','9','adminpetrogas',1569409985,1569409985,2),(340,'Client','11','adminpetrogas',1569599878,1569599878,2),(341,'Inquiry','11','adminpetrogas',1569600546,1569654625,2),(342,'KM','1','adminpetrogas',1569672770,1569673574,2),(343,'KM','2','adminpetrogas',1569673807,1569675079,2),(344,'KM','3','administrator',1569836389,1569836619,2),(345,'KM','4','adminpetrogas',1569896429,1569896429,2),(346,'vendor','9','adminpetrogas',1569902795,1569902795,2),(347,'vendor','10','adminpetrogas',1569903017,1569903017,2),(348,'vendor','11','adminpetrogas',1569903267,1569903624,2),(349,'Marketing','1','administrator',1570509677,1570512345,2),(350,'DocControl','157','administrator',1570522430,1570522430,2),(351,'Client','12','administrator',1571220706,1571220706,2),(352,'Inquiry','12','administrator',1571220778,1571221083,2),(353,'DesignProposal','12','administrator',1571221456,1571221456,2),(354,'KM','5','administrator',1571221839,1571221839,2),(355,'KM','6','administrator',1571222149,1571222382,2),(356,'DesignProposal','13','administrator',1571222828,1571295492,2),(357,'DesignProposal','14','administrator',1571289525,1571289525,2),(358,'DesignProposal','15','administrator',1571289621,1571289621,2),(359,'DesignProposal','16','administrator',1571289798,1571289798,2),(360,'DesignProposal','17','administrator',1571289912,1571290421,2),(361,'vendor','12','administrator',1571584275,1571584275,2),(362,'vendor','13','administrator',1571584426,1571584426,2),(363,'vendor','14','administrator',1571584554,1571584554,2),(364,'vendor','15','administrator',1571584755,1571585132,2),(365,'vendor','16','administrator',1571585097,1571585097,2),(366,'vendor','17','administrator',1571906797,1571906797,2),(367,'vendor','18','administrator',1571906873,1571906873,2),(368,'DesignProposal','18','administrator',1571978573,1571978787,2),(369,'DesignProposal','19','administrator',1571978764,1571979041,2),(370,'DesignProposal','20','administrator',1571978953,1571979308,2),(371,'Inquiry','13','administrator',1571992526,1571992526,2);
/*!40000 ALTER TABLE `membership_userrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_users`
--

DROP TABLE IF EXISTS `membership_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_users` (
  `memberID` varchar(20) NOT NULL,
  `passMD5` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `signupDate` date DEFAULT NULL,
  `groupID` int(10) unsigned DEFAULT NULL,
  `isBanned` tinyint(4) DEFAULT NULL,
  `isApproved` tinyint(4) DEFAULT NULL,
  `custom1` text,
  `custom2` text,
  `custom3` text,
  `custom4` text,
  `comments` text,
  `pass_reset_key` varchar(100) DEFAULT NULL,
  `pass_reset_expiry` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`memberID`),
  KEY `groupID` (`groupID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_users`
--

LOCK TABLES `membership_users` WRITE;
/*!40000 ALTER TABLE `membership_users` DISABLE KEYS */;
INSERT INTO `membership_users` (`memberID`, `passMD5`, `email`, `signupDate`, `groupID`, `isBanned`, `isApproved`, `custom1`, `custom2`, `custom3`, `custom4`, `comments`, `pass_reset_key`, `pass_reset_expiry`) VALUES ('guest',NULL,NULL,'2019-06-17',1,0,1,NULL,NULL,NULL,NULL,'Anonymous member created automatically on 2019-06-17',NULL,NULL),('administrator','200ceb26807d6bf99fd6f4f0d1ca54d4','admin@supplynetworkagency.com','2019-06-17',2,0,1,NULL,NULL,NULL,NULL,'Admin member created automatically on 2019-06-17','a122f95fee8de0f78d0c2a4fab7d6a0f',1568117070),('adminpetrogas','5042ca83c928dfc80b9aaddb72daafa8','syamsul.azmee@supplynetworkagency.com','2019-06-18',2,0,1,NULL,NULL,NULL,NULL,'Admin member created automatically on 2019-06-18',NULL,NULL),('auditor','70c4cc2db135db1a7dc8e13ee6bde82a','admin@supplynetworkagency.com','2019-08-03',3,0,1,'AUDITOR','GENERAL','KUALA LUMPUR','MALAYSIA','',NULL,NULL),('document control','53088d40c288ee156553e732e5108770','admin@supplynetworkagency.com','2019-08-03',4,0,1,'AUDITOR','GENERAL','KUALA LUMPUR','MALAYSIA','',NULL,NULL),('staff','671424e52d4d1ec4c62930b2d2d4b57d','admin@supplynetworkagency.com','2019-08-03',5,0,1,'AUDITOR','GENERAL','KUALA LUMPUR','MALAYSIA','',NULL,NULL),('amirul','e807f1fcf82d132f9bb018ca6738a19f','amirul@klpetrogas.com','2019-09-17',5,0,1,'Amirul','Kota damansara','Damansara','Selangor','',NULL,NULL),('nursafiina','e807f1fcf82d132f9bb018ca6738a19f','nursafiina@klpetrogas.com','2019-09-17',5,0,1,'Nursafiina','Kota damansara','Selangor','Malaysia','',NULL,NULL),('azri.abas','e807f1fcf82d132f9bb018ca6738a19f','azri.abas@klpetrogas.com','2019-09-17',2,0,1,'Azri bin abas','Kota damansara','Selangor','Malaysia','',NULL,NULL),('zulkifli.mohamad','e807f1fcf82d132f9bb018ca6738a19f','Zulkifli.mohamad@klpetrogas.com','2019-09-17',2,0,1,'Zulkifli.mohamad','Kota damansara','Selangor','Malaysia','',NULL,NULL),('hatta','e807f1fcf82d132f9bb018ca6738a19f','hatta@klpetrogas.com','2019-09-17',2,0,1,'Hatta','Kota damansara','Selangor','Malaysia','',NULL,NULL),('azmiaziz','e807f1fcf82d132f9bb018ca6738a19f','azmiaziz@klpetrogas.com','2019-09-17',2,0,1,'Azmi aziz','Kota damansara','Selangor','Malaysia','',NULL,NULL),('hashmi','e807f1fcf82d132f9bb018ca6738a19f','Hashmi@klpetrogas.com','2019-09-17',2,0,1,'Hashmi','Kota damansara','Selangor','Malaysia','',NULL,NULL),('riza.aljeffery','e807f1fcf82d132f9bb018ca6738a19f','Riza.aljeffery@klpetrogas.com','2019-09-17',2,0,1,'Riza.aljeffery','Kota damansara','Selangor','Malaysia','',NULL,NULL);
/*!40000 ALTER TABLE `membership_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `OrderID` varchar(100) NOT NULL,
  `Market_Survey` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_Classification` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_Critical` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_Justification` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_ProjectID` int(10) unsigned NOT NULL,
  `fo_InventoryID` int(10) unsigned NOT NULL,
  `fo_ItemID` int(11) NOT NULL,
  `fo_ProductID` int(11) DEFAULT '0',
  `fo_Description` varchar(255) DEFAULT NULL,
  `fo_Detail` text,
  `fo_OrderDate` date DEFAULT NULL,
  `fo_RequiredDate` date DEFAULT NULL,
  `fo_ShippedDate` date DEFAULT NULL,
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `OrderID_unique` (`OrderID`),
  KEY `fo_ProjectID` (`fo_ProjectID`),
  KEY `fo_InventoryID` (`fo_InventoryID`),
  KEY `fo_ItemID` (`fo_ItemID`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`id`, `OrderID`, `Market_Survey`, `fo_Classification`, `fo_Critical`, `fo_Justification`, `fo_ProjectID`, `fo_InventoryID`, `fo_ItemID`, `fo_ProductID`, `fo_Description`, `fo_Detail`, `fo_OrderDate`, `fo_RequiredDate`, `fo_ShippedDate`, `fo_ShipVia`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'4010_0001','Request Order','Equipment','1-High Urgency & High Impact','1-System Function Ready',4,6,1,1,NULL,'<br>','2019-09-06','2019-09-06',NULL,1,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 11:39:21','2019-09-12 10:41:55'),(2,'4010_0002','Request Order','Equipment','1-High Urgency & High Impact','1-System Function Ready',4,7,1,1,NULL,'<br>','2019-09-06','2019-09-06',NULL,1,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 11:44:05','2019-09-12 10:42:32'),(3,'4010_0003','Request Order','Equipment','1-High Urgency & High Impact','1-System Function Ready',4,8,1,1,NULL,'<br>','2019-09-06','2019-09-06',NULL,1,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 11:45:01','2019-09-12 10:43:04'),(4,'4010_0004','Request Order','Equipment','1-High Urgency & High Impact','1-System Function Ready',4,9,1,1,NULL,'<br>','2019-09-06','2019-09-06',NULL,1,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 11:45:50','2019-09-12 10:43:45'),(5,'4010_0005','Request Order','Equipment','1-High Urgency & High Impact','1-System Function Ready',4,10,1,1,NULL,'<br>','2019-09-06','2019-09-06',NULL,1,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 11:46:31','2019-09-12 10:44:16'),(6,'4010_0006','Request Order','Equipment','1-High Urgency & High Impact','1-System Function Ready',4,11,1,1,NULL,'<br>','2019-09-06','2019-09-06',NULL,1,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-06 11:47:12','2019-09-12 10:45:02');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `projectID` varchar(200) NOT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `fo_ProjectIndication` text NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_StartDate` date DEFAULT NULL,
  `fo_EndDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `projectID_unique` (`projectID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` (`Id`, `projectID`, `Name`, `fo_ProjectIndication`, `fo_DocumentDescription`, `fo_StartDate`, `fo_EndDate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'1010_001','NON-PROJECT ACTIVITIES','Others','This to enable the function of all request order or form that is not related to any project','2019-01-01','2019-12-31',NULL,'NA','<br>',NULL,NULL,NULL,NULL,'46442000_1564843560.PNG',1,NULL,NULL,NULL,2,NULL,'2019-08-03 22:36:33','2019-08-03 22:46:00'),(2,'1010_002','POST TRENCHING WORKS AT SUNGAI JOHOR FOR PENGERANG GAS PIPELINE PROJECT (POTCH)','Main Contractor','The Sungai Johor and Selat Mendana crossings are a 1.8km and 500m river\r\ncrossing and are part of the 72km Pengerang Gas Pipeline Project (PGPP) constructed by the Consortium of PBJV-CPM. The crossings are separated by a 1.2km length mangrove swamp island, Pulau Juling. The pipeline has been commissioned mid-June 2017 and is currently supplying gas to Pengerang COGEN Plant and the PGU system. The whole 3.5km of the aforesaid length was installed with NPS 36 API X70 concrete coated pipes.\r\nThe pipeline installation at Sungai Johor and Selat Mendana crossings were completed in September 2016 and was left as laid, unburied on the riverbed ever since. The pipeline at the Sungai Johor crossing was supposed to be buried and protected with concrete mattress before final tie-ins to onshore section. However, due to delay by the Consortium, the pipeline at Sungai Johor crossing was then tied-in to the onshore portion in April 2017 to allow for gas-in and commissioning activities in June 2017 before the post-trenching works could be completed.\r\nCOMPANY intends to continue the post-trenching work at both Sungai Johor and Selat Mendana and further backfilling at Pulau Juling to obtain minimum 2m depth of cover from top of pipe. Since the pipeline had been tied-in, COMPANY has appointed an engineering consultant to perform the survey and stress analysis study to assess the fitness of the pipeline condition prior to performing post trenching activities. Based on the study, the consultant confirmed that the post trenching activities can be done.\r\nCOMPANY highlighted that the pipeline is already in operation with MAOP of 68.95barg and all works shall be performed on live pipeline with no shutdown window.','2019-01-09','2019-09-22',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'46065500_1566467629.png',2,NULL,NULL,NULL,2,NULL,'2019-08-22 11:50:57','2019-09-06 12:47:25'),(3,'1010_003','TANK CLEANING ROBOT','Main Contractor','Provision and supply of tank cleaning robots for possible contractors and clients.','2019-08-30',NULL,NULL,'Tank Cleaning Robots:\r\n1. Lombrico\r\n2. Mini Bull ROV','<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-30 15:07:37','2019-08-30 15:07:44'),(4,'1010_004','INTERNAL GENERAL & ADMINISTRATIVE PROJECT','Others','All internal project request to be position here. this can be created annually. based on annual budget','2019-09-04',NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'46413600_1567565060.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 10:44:20','2019-09-04 10:44:36'),(5,'1010_005','EXTERNAL GENERAL PROJECT','Others','All external project request to be position here. this can be created annually. based on annual budget','2019-09-04',NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,'49826600_1567565141.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-09-04 10:45:41',NULL);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resources`
--

DROP TABLE IF EXISTS `resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resources` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ResourcesID` varchar(200) NOT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `fo_Type` text NOT NULL,
  `fo_Description` text,
  `fo_Available` varchar(40) DEFAULT '1',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `ResourcesID_unique` (`ResourcesID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resources`
--

LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TransCode` varchar(256) NOT NULL,
  `fo_transaction_date` date DEFAULT NULL,
  `fo_item` int(11) DEFAULT NULL,
  `fo_ResourcesID` int(10) unsigned DEFAULT NULL,
  `fo_transactiontype` varchar(40) NOT NULL,
  `fo_quantity` decimal(10,2) DEFAULT '1.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TransCode_unique` (`TransCode`),
  KEY `fo_item` (`fo_item`),
  KEY `fo_ResourcesID` (`fo_ResourcesID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor` (
  `VendorID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `CompanyID` varchar(200) NOT NULL,
  `CopanyName` varchar(100) DEFAULT NULL,
  `fo_AVList` tinyint(4) DEFAULT '0',
  `fo_ContactTitle` varchar(100) DEFAULT NULL,
  `fo_Address` varchar(100) DEFAULT NULL,
  `fo_City` varchar(50) DEFAULT NULL,
  `fo_Region` varchar(50) DEFAULT NULL,
  `fo_PostalCode` varchar(10) DEFAULT NULL,
  `fo_Country` varchar(50) DEFAULT NULL,
  `fo_Phone` varchar(24) DEFAULT NULL,
  `fo_Fax` varchar(24) DEFAULT NULL,
  `fo_HomePage` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`VendorID`),
  UNIQUE KEY `CompanyID_unique` (`CompanyID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor`
--

LOCK TABLES `vendor` WRITE;
/*!40000 ALTER TABLE `vendor` DISABLE KEYS */;
INSERT INTO `vendor` (`VendorID`, `CompanyID`, `CopanyName`, `fo_AVList`, `fo_ContactTitle`, `fo_Address`, `fo_City`, `fo_Region`, `fo_PostalCode`, `fo_Country`, `fo_Phone`, `fo_Fax`, `fo_HomePage`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'5010_001','GENERAL VENDOR',1,'Local general vendor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-04 09:47:27',NULL),(2,'5010_002','ECOPRASINOS ENGINEERING SDN BHD',1,'Ir. Bennet Sugiarto','B-02-1, Jalan Medan PB5,Paragon Point,\r\nSeksyen 9','BANDAR BARU BANGI','SELANGOR','43650','Malaysia','+60-3-89273485','+60-3-89273486','https://www.ecoprasinos.com/home',NULL,'EcoPrasinos is full Consultant Engineer wholly owned by Malaysian Company founded in 24th August 2009 providing comprehensive array of engineering services from the smallest and simplest to the largest and most complex projects to a diverse global clientele. \r\n\r\nToday, EcoPrasinos is going to be a world leader in Offshore and Onshore pipeline projects. With the support from technical team who has more than 16 years experienced in subsea and pipeline Engineering. \r\n\r\nEcoPrasinos develops EDMS suite for managing, store, track documents and other media.The solution has been developed using Microsoft SharePoint 2016. The system has been implemented in EcoPrasinos Engineering Projects.','<section class=\"yaqOZd\" id=\"h.p_v05Q7o66Wh6O\" style=\"background-size: cover; box-sizing: border-box; color: rgb(0, 0, 0); display: table; font-family: sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; padding-bottom: 1.5rem; padding-top: 1.5rem; position: relative; table-layout: fixed; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; width: 100%; word-spacing: 0px;\"><div class=\"mYVXT\" style=\"box-sizing: border-box; display: table-cell; vertical-align: middle; width: 100%;\"><div tabindex=\"-1\" class=\"LS81yb VICjCf\" style=\"box-sizing: border-box; margin-bottom: 0px; margin-left: auto; margin-right: auto; margin-top: 0px; max-width: 1280px; outline-color: invert; outline-style: none; outline-width: 0px; padding-left: 48px; padding-right: 48px; width: 100%;\"><div class=\"hJDwNd-AhqUyc-uQSCkd purZT-AhqUyc-II5mzb pSzOP-AhqUyc-qWD73c JNdkSc\" style=\"box-sizing: border-box; display: inline-block; padding-left: 0px; padding-right: 0px; position: relative; vertical-align: top; width: 100%;\"><div class=\"JNdkSc-SmKAyb\" style=\"box-sizing: border-box; padding-left: 1.25%; padding-right: 1.25%;\" jscontroller=\"wKydJb\" jsaction=\"v9U29b:zTPCnb;\" jsname=\"F57UId\"><div class=\"oKdM2c\" style=\"box-sizing: border-box; margin-bottom: 0px; margin-top: 0px; max-width: 1280px; width: 100%;\"><div class=\"hJDwNd-AhqUyc-uQSCkd jXK9ad D2fZ2 OjCsFc wHaque GNzUNc\" id=\"h.p_pDfM2TJzWh6L\" style=\"box-sizing: border-box; display: inline-block; overflow-wrap: break-word; padding-left: 0px; padding-right: 0px; position: relative; vertical-align: top; white-space: pre-wrap; width: 100%;\"><div class=\"jXK9ad-SmKAyb\" style=\"box-sizing: border-box; width: 100%;\"><div class=\"tyJCtd mGzaTb baZpAe\" style=\"box-sizing: border-box; padding-bottom: 8px; padding-left: 8px; padding-right: 8px; padding-top: 8px; position: relative; width: 100%;\"><h3 tabindex=\"-1\" class=\"zfr3Q OmQG5e\" id=\"h.p_Mzxqmb3HWh6N\" style=\"box-sizing: border-box; color: rgba(28, 160, 177, 1); font-family: Roboto,sans-serif; font-size: 17px; font-style: inherit; font-weight: 700; letter-spacing: 1px; line-height: 1.63; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px; outline-color: invert; outline-style: none; outline-width: medium; padding-bottom: 0px; padding-top: 0px; pointer-events: none; position: relative; text-align: center; text-decoration: inherit;\"><div class=\"TyBUR\" style=\"box-sizing: border-box; display: inline-block; max-width: 100%; pointer-events: all; position: relative;\" jscontroller=\"SO2Cv\" jsaction=\"touchstart:UrsOsc; click:KjsqPd; focusout:QZoaZ;Mf6qBf:jbFSOd;Wliphb:SzACGe;\">Among the range of services which Ecoprasinos Engineering provides are : </div></h3></div></div></div></div></div></div></div></div></section><section class=\"yaqOZd\" id=\"h.p_bLW6fYTCWk7X\" style=\"background-size: cover; box-sizing: border-box; color: rgb(0, 0, 0); display: table; font-family: sans-serif; font-size: 16px; font-style: normal; font-variant: normal; font-weight: 400; letter-spacing: normal; orphans: 2; padding-bottom: 1.5rem; padding-top: 1.5rem; position: relative; table-layout: fixed; text-align: left; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; width: 100%; word-spacing: 0px;\"><div class=\"yaqOZd IFuOkc\" style=\"background-size: cover; box-sizing: border-box; display: table-cell; height: 100%; left: 0px; pointer-events: none; position: absolute; table-layout: fixed; top: 0px; width: 100%;\"><br></div><div class=\"mYVXT\" style=\"box-sizing: border-box; display: table-cell; vertical-align: middle; width: 100%;\"><div tabindex=\"-1\" class=\"LS81yb VICjCf\" style=\"box-sizing: border-box; margin-bottom: 0px; margin-left: auto; margin-right: auto; margin-top: 0px; max-width: 1280px; outline-color: invert; outline-style: none; outline-width: 0px; padding-left: 48px; padding-right: 48px; width: 100%;\"><div class=\"hJDwNd-AhqUyc-II5mzb purZT-AhqUyc-II5mzb pSzOP-AhqUyc-qWD73c JNdkSc\" style=\"box-sizing: border-box; display: inline-block; padding-left: 0px; padding-right: 0px; position: relative; vertical-align: top; width: 33.33%;\"><div class=\"JNdkSc-SmKAyb\" style=\"box-sizing: border-box; padding-left: 3.75%; padding-right: 3.75%;\" jscontroller=\"wKydJb\" jsaction=\"v9U29b:zTPCnb;\" jsname=\"F57UId\"><div class=\"oKdM2c\" style=\"box-sizing: border-box; margin-bottom: 0px; margin-top: 0px; max-width: 1280px; width: 100%;\"><div class=\"hJDwNd-AhqUyc-II5mzb pSzOP-AhqUyc-qWD73c jXK9ad D2fZ2 OjCsFc wHaque GNzUNc\" id=\"h.p_yhCbIazHWk7S\" style=\"box-sizing: border-box; display: inline-block; overflow-wrap: break-word; padding-left: 0px; padding-right: 0px; position: relative; vertical-align: top; white-space: pre-wrap; width: 100%;\"><div class=\"jXK9ad-SmKAyb\" style=\"box-sizing: border-box; width: 100%;\"><div class=\"tyJCtd mGzaTb baZpAe\" style=\"box-sizing: border-box; padding-bottom: 8px; padding-left: 8px; padding-right: 8px; padding-top: 8px; position: relative; width: 100%;\"><ul class=\"n8H08c UVNKR\" style=\"box-sizing: border-box; list-style-type: square; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px; padding-bottom: 0px; padding-left: 20px; padding-top: 0px; text-align: left;\"><li class=\"TYR86d zfr3Q\" id=\"h.p_mUIUrywhWk7V\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\">Feasibility and Economics Study</li><li class=\"TYR86d zfr3Q\" id=\"h.p_DScHbCETWnRs\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">Field Development Studies </li><li class=\"TYR86d zfr3Q\" id=\"h.p_vRHjhPimWnRt\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">Concept Development</li><li class=\"TYR86d zfr3Q\" id=\"h.p_8wE_J-6vWnRv\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">Preliminary and Details Design</li><li class=\"TYR86d zfr3Q\" id=\"h.p_NOG7JtdBWnRw\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">Subsea Repairs and Interventions studies </li></ul></div></div></div></div></div></div><div class=\"hJDwNd-AhqUyc-II5mzb purZT-AhqUyc-II5mzb pSzOP-AhqUyc-qWD73c JNdkSc\" style=\"box-sizing: border-box; display: inline-block; padding-left: 0px; padding-right: 0px; position: relative; vertical-align: top; width: 33.33%;\"><div class=\"JNdkSc-SmKAyb\" style=\"box-sizing: border-box; padding-left: 3.75%; padding-right: 3.75%;\" jscontroller=\"wKydJb\" jsaction=\"v9U29b:zTPCnb;\" jsname=\"F57UId\"><div class=\"oKdM2c\" style=\"box-sizing: border-box; margin-bottom: 0px; margin-top: 0px; max-width: 1280px; width: 100%;\"><div class=\"hJDwNd-AhqUyc-II5mzb pSzOP-AhqUyc-qWD73c jXK9ad D2fZ2 OjCsFc wHaque GNzUNc\" id=\"h.p_6KsDCC9yWsjl\" style=\"box-sizing: border-box; display: inline-block; overflow-wrap: break-word; padding-left: 0px; padding-right: 0px; position: relative; vertical-align: top; white-space: pre-wrap; width: 100%;\"><div class=\"jXK9ad-SmKAyb\" style=\"box-sizing: border-box; width: 100%;\"><div class=\"tyJCtd mGzaTb baZpAe\" style=\"box-sizing: border-box; padding-bottom: 8px; padding-left: 8px; padding-right: 8px; padding-top: 8px; position: relative; width: 100%;\"><ul class=\"n8H08c UVNKR\" style=\"box-sizing: border-box; list-style-type: square; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px; padding-bottom: 0px; padding-left: 20px; padding-top: 0px;\"><li class=\"TYR86d zfr3Q\" id=\"h.p_jDjaP-pRWsjr\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\">Preparations of Tender Documents Services</li><li class=\"TYR86d zfr3Q\" id=\"h.p_OqIWkoYDWsjv\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">Preparations of Fabrications and Installations Procedures and subsequent construction and installation, supervision / assistance</li><li class=\"TYR86d zfr3Q\" id=\"h.p_A3d1TZimWsjw\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">Procurement Service</li><li class=\"TYR86d zfr3Q\" id=\"h.p_f4nb76KEWsjy\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">Alliance Partnership With Fabrication, Construction, and Installation to Provide Full EPC Services&nbsp;&nbsp;&nbsp; </li></ul></div></div></div></div></div></div><div class=\"hJDwNd-AhqUyc-II5mzb purZT-AhqUyc-II5mzb pSzOP-AhqUyc-qWD73c JNdkSc\" style=\"box-sizing: border-box; display: inline-block; padding-left: 0px; padding-right: 0px; position: relative; vertical-align: top; width: 33.33%;\"><div class=\"JNdkSc-SmKAyb\" style=\"box-sizing: border-box; padding-left: 3.75%; padding-right: 3.75%;\" jscontroller=\"wKydJb\" jsaction=\"v9U29b:zTPCnb;\" jsname=\"F57UId\"><div class=\"oKdM2c\" style=\"box-sizing: border-box; margin-bottom: 0px; margin-top: 0px; max-width: 1280px; width: 100%;\"><div class=\"hJDwNd-AhqUyc-II5mzb pSzOP-AhqUyc-qWD73c jXK9ad D2fZ2 OjCsFc wHaque GNzUNc\" id=\"h.p_l0ffBRTdWo0K\" style=\"box-sizing: border-box; display: inline-block; overflow-wrap: break-word; padding-left: 0px; padding-right: 0px; position: relative; vertical-align: top; white-space: pre-wrap; width: 100%;\"><div class=\"jXK9ad-SmKAyb\" style=\"box-sizing: border-box; width: 100%;\"><div class=\"tyJCtd mGzaTb baZpAe\" style=\"box-sizing: border-box; padding-bottom: 8px; padding-left: 8px; padding-right: 8px; padding-top: 8px; position: relative; width: 100%;\"><ul class=\"n8H08c UVNKR\" style=\"box-sizing: border-box; list-style-type: square; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px; padding-bottom: 0px; padding-left: 20px; padding-top: 0px; text-align: left;\"><li class=\"TYR86d zfr3Q\" id=\"h.p_hWcxsdZZWo0M\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\">Installation Studies </li><li class=\"TYR86d zfr3Q\" id=\"h.p_QURGD4XLWwmd\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">Materials Selection Studies </li><li class=\"TYR86d zfr3Q\" id=\"h.p_tz5GGkxwWwme\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">EPC Project Managements Service</li><li class=\"TYR86d zfr3Q\" id=\"h.p_eZUagvUtWwmi\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">Pipeline Abandonment Studies</li><li class=\"TYR86d zfr3Q\" id=\"h.p_q5bG5Wx9Wwmj\" style=\"box-sizing: border-box; color: rgba(33, 33, 33, 1); font-family: \" inherit;\"=\"\" relative;=\"\" 0px;=\"\" medium;=\"\" none;=\"\" invert;=\"\" 1.56;=\"\" 400;=\"\" inherit;=\"\" 16px;=\"\" sans\",sans-serif;=\"\" open=\"\" 6px;=\"\">Commissioning Assistance Together With Operation and Maintenance Services&nbsp;&nbsp; </li></ul></div></div></div></div></div></div></div></div></section><p class=\"zfr3Q\" id=\"h.p_w2scPV3A_qyt\" style=\"margin: 16px 0px 0px; outline: invert; text-align: justify; color: rgba(33, 33, 33, 1); text-transform: none; line-height: 1.56; text-indent: 0px; letter-spacing: normal; font-size: 16px; font-variant: normal; word-spacing: 0px; white-space: pre-wrap; position: relative; box-sizing: border-box; orphans: 2; -webkit-text-stroke-width: 0px;\"><b></b><i></i><u></u><sub></sub><sup></sup><strike></strike><br></p><b></b><i></i><u></u><sub></sub><sup></sup><strike></strike><br>',NULL,NULL,NULL,NULL,'07846200_1568771905.png',NULL,NULL,NULL,NULL,NULL,NULL,'2019-08-22 16:34:38','2019-09-18 09:58:25'),(3,'5010_003','FS SPECIALIST SDN.BHD.',1,'HQ','FS SPECIALIST SDN. BHD. NO.103, GROUND FLOOR, JALAN BATU TIGA LAMA,','SELANGOR','BERKELEY TOWN CENTRE KLANG,','41300','Malaysia','+603-3343 5632/33435778','+603 3341 3815','https://fsspecialist.com.my/hose/',NULL,'FS Specialist Sdn Bhd established since year 2008. Due to the rapid expansion of company, currently we have total of 6 divisions to handle the respective product. They are Hoses & Fittings Division, Sealant Device Division, Mechanical Seal Division, Instrumentation Valves & Fittings Division, Projects Division, M&E Services Division.EXCLUSIVE SOLE DISTRIBUTOR (MALAYSIA)\r\n\r\n\r\nBrand Product Origin\r\nTrelleborg                                   Hose & Fittings                               France\r\nHansun Instrument                     Fittings & Valves                               Korea\r\nDepac                                           Mechanical Seal                               Austria\r\nBalflex                                          Hoses & Fittimgs                               Portugal\r\nTudertechnica        Chemical Hose & Silicone Rubber Hose         Italy\r\n\r\n\r\nOthers Brand Offer :\r\n\r\nElaflex Hose , Alfagomma Hose IVG Hose, A-Lok Fittings, Manuli Hose, Gutteling Composite Hose, Dantec, Dunlop Hose, Yokohama Hose, Parker Hose, Sandvik Tubing, Parker Tube Fittings, Hy-Lok Fittings, DK-Lok Fittings, Unigawa Hose. S-Lok Fittings.\r\n\r\nJohn Crane, Burgmann, AES, Sealol, Anchor, Pac Seal, Chesterton, NOK, Flowserve','<br>','https://fsspecialist.com.my/hose/about-us/','https://fsspecialist.com.my/hose/products/',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2019-09-18 11:02:39','2019-09-18 12:04:06'),(7,'5010_007','NORIMAX SDN BHD',1,'IR SYAFIQ',' No. 2, Jalan TPP 5/17, Taman\r\n Perindustrian Puchong, Seksyen 5,','Selangor','Puchong,','47160','Malaysia','03-8060 2334','0380622334','http://www.norimax.com.my/',NULL,'INTEGRATED MATERIAL ENGINEERING SPECIALIST, FOCUSING ON THE PROVISION OF MATERIAL PROTECTION AND CORROSION CONTROL PRODUCT AND SERVICES','<br>','http://www.norimax.com.my/about.php','http://www.norimax.com.my/products.php',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2019-09-18 12:09:39',NULL),(4,'5010_004','AA PRODUCT SDN BHD',1,'HQ','A-3-30, 3rd Floor, Jalan TPP 1/6, Taman Industri Puchong,','selangor','puchong','47100','Malaysia','03-8062 6900','03-80311019','http://www.aaproduct.com/',NULL,'AA Products Sdn Bhd was incorporated in 1985, creating a strong and successful business entity by providing sincere and effective services to our valued customers.\r\nWith more than 31 years of professional experience in Industrial Pumps and Valves, we still continue to explore and improve our Sales & Services for Pumps, Valves & Accessories businesses.\r\n \r\nWe have always corporate with establishing brands, that are reliable and of quality products to ensure that our customer’s interest is well taken care. We have set up Sales and Service Centre in Penang, Klang Valley and Singapore and we are dedicated to high value services and we always maintain our commitment to our customers.\r\n\r\nWHAT WE HAVE\r\n\r\nAir Operated Double Diaphragm Pumps, Chemical Pumps, Magnetic Drive Pumps, Dosing and Metering Pumps, Gear Pumps, Lobe Pumps, Submersible Pumps, ISO Standard Centrifugal Pumps, Din Standard Centrifugal Pumps, ANSI Standard Centrifugal Pumps, API 610 Centrifugal Pumps, API 685 Magnetic Drive Pump and API 674 & 675 Plunger and Diaphragm Pumps, Fire Pump Systems, Chemical Injection Skids, High Pressure Cleaner Pumps, Solenoid Valves, Semi Finished Engineering Plastic (Rods and Sheet of UHMW PE, HD PE, PTFE, Nylon, PP and etc.), Pallet Trucks, Industrial Vacuum Cleaners, Grass Cutters, Light Construction Equipments (Concrete Mixer, Tamper, Rammers, Vibrators, Winches, Bar Cutters and Benders), Filtration Systems (For Plating, Chemical and etc.), Steel Fabrication and Machining Services (CNC Turning & Machine Center.)\r\nPTFE (Teflon) Products\r\nEngineering Plastic Rods and Sheet\r\nPressure Cleaners\r\nAir Tools\r\nChemical Hand Pumps\r\nSolenoid Valves\r\nPolyethylene Chemical\r\nWater Tanks\r\nWe have qualified engineers and designers to provide the best solution and support to our customer.','<br>','http://www.aaproduct.com/about-us','http://www.aaproduct.com/brands','AA_Products_Company_Profile.pdf',NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2019-09-18 11:43:40','2019-09-18 12:02:43'),(5,'5010_005','ACOMECH ENGINEERING SDN.BHD',1,'HQ','18, Jalan Belati 1,\r\nOff Jalan Kempas Lama,\r\nTaman Perindustrian Maju Jaya,','Johor,','Skudai,','81300','Malaysia','+607-5545172','+607-5585666','http://www.acomech.com.my/',NULL,'Acomech Engineering Sdn Bhd was incorporated in 2001. Our principal activities are related to primarily in supply, installation and service.\r\nIndustry equipment including:\r\nPumps, Valves, Motors and other engineering products.\r\nMixers and Agitators.\r\nHeat exchanger and storage tank.\r\nGeneral Fabrication Work.\r\nWith the establishment with overseas partnership, our service also including sourcing and supply of spare parts.\r\nOur focus has been on reliability, quality, on time delivery and job completion to our client\'s satisfaction.','<br>','http://www.acomech.com.my/index.php?ws=pages&pages_id=4519','http://www.acomech.com.my/index.php?ws=productsbycat',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2019-09-18 11:53:56','2019-09-18 12:02:00'),(6,'5010_006','LJ VEST SDN BHD',1,'HQ','21, JALAN IM 14/7,\r\n KAWASAN INDUSTRIAL \r\nRINGAN SEKTOR 3,\r\n INDERA MAHKOTA','Pahang','Kuantan','25200','Malaysia','09-5701264/09-5701263','09-5701267/09-5701266','http://www.ljvest.com/index.html',NULL,'ommitted to provide services & to supply at competitive cost to oil and gas industries & contractors. We supply hardware and machineries to projects in the most efficient method to supplement each of our client\'s opportunity for success. With more than 10 years in experience in this field on all of our key personnel, we will continue to mobilize effectively and efficiently to all of our customer\'s projects, in the most comprehensive and responsive manner.','<br>','http://www.ljvest.com/our-products.html','http://www.ljvest.com/about-us.html',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2019-09-18 12:01:18',NULL),(8,'5010_008','KA PETRA SDN BHD',1,'NORIAH LATIFF','3-1 Jalan Putra Mahkota 7/8D,  Putra Heights, Malaysia','Selangor Darul Ehsan','Subang Jaya','47650','Malaysia','+6 03 5192 1660','+6 03 5192 7660','http://kapetra.com.my/',NULL,'SHIP TO SHIP TRANSFER','<br>','http://kapetra.com.my/about-us/','http://kapetra.com.my/ship-to-ship-transfer-1/',NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2019-09-18 12:15:06','2019-09-18 12:15:19'),(9,'5010_009','ONESUBSEA MALAYSIA SYSTEMS SDN BHD',1,NULL,'Pelabuhan Tanjung Pelepas Johor Bahru 81560','GELANG PATAH','JOHOR','81560','Malaysia',NULL,NULL,'https://www.onesubsea.slb.com/',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-01 12:06:35',NULL),(10,'5010_010','TECHNIPFMC',1,NULL,'Wisma TechnipFMC 241 Jalan Tun Razak, Kuala Lumpur, 50400, Malaysia','KUALA LUMPUR','KUALA LUMPUR','50400','Malaysia','+60 3-2116 7888',NULL,'https://www.technipfmc.com/en/where-we-operate/asia-pacific/malaysia',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-01 12:10:17',NULL),(11,'5010_011','AKER SOLUTIONS',1,NULL,'Level 16, Integra Tower, The Intermark, 348, Jalan Tun Razak, 50400 Kuala Lumpur\r\nMalaysia','KUALA LUMPUR','KUALA LUMPUR','50400','Malaysia','+603 2381 8388',NULL,'https://akersolutions.com/',NULL,'Subsea systems','Lifecycle of the Oilfield<ul class=\"life-cycle-headers\"><li class=\"life-cycle-headers-item\"><h4 class=\"h4 heading\">Exploration</h4></li><li class=\"life-cycle-headers-item\"><h4 class=\"h4 heading\">Development</h4></li><li class=\"life-cycle-headers-item wide\"><h4 class=\"h4 heading\">Production</h4></li><li class=\"life-cycle-headers-item\"><h4 class=\"h4 heading\">Decommissioning</h4></li></ul><section class=\"life-cycle-list\" id=\"_jsLifeCycleTablePlaceholder\"><h4 class=\"h4 sub-heading\" id=\"products-and-services\">Products and Services</h4><ul class=\"life-cycle-projects\"><li class=\"life-cycle-col size-1-2-3-4\"><h5 class=\"h5 sub-heading-project\">Field Planning, Feasibility and Concept Studies</h5><div class=\"info\"><p>Improving the productivity of new and existing oil and gas fields has never been more important. Aker Solutions finds ways to increase value at every stage of an oilfield’s lifecycle.</p></div></li><li class=\"life-cycle-col size-1-2-3-4\"><h5 class=\"h5 sub-heading-project\">Floater Designs<br></h5><div class=\"info\"><p>Our proven floater designs enable oil and gas production, storage and offloading in the world’s most challenging offshore environments.</p></div></li><li class=\"life-cycle-col size-1-2-3-4\"><h5 class=\"h5 sub-heading-project\">Digital Solutions&nbsp;</h5><div class=\"info\"><p>Our digital solutions bring together Aker Solutions’ heritage in providing software with the company’s deep domain expertise to deliver digital offerings that increase efficiency, quality, safety and reduce total cost of ownership.</p></div></li><li class=\"life-cycle-col size-1-2-3-4\"><h5 class=\"h5 sub-heading-project\">Offshore Wind Solutions</h5><div class=\"info\"><p>Our offshore wind solutions combine Aker Solutions’ experience in developing and managing large and complex offshore projects with the proven WindFloat® technology from our partner Principle Power.</p></div></li><li class=\"life-cycle-col size-1-2-3-4\"><h5 class=\"h5 sub-heading-project\">Design and Delivery of Deepwater Riser<br></h5><div class=\"info\"><p>Aker Solutions provides riser solutions for any water depth and any environmental conditions.&nbsp;</p></div></li><li class=\"life-cycle-col size-1-2\"><h5 class=\"h5 sub-heading-project\">Specialist Engineering, Project Management and Procurement Services<br></h5><div class=\"info\"><p>Aker Solutions provides customers value-adding services through its deep specialist engineering and procurement competencies and vast experience in managing complex projects.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Design of Offshore Oil and Gas Production Facilities</h5><div class=\"info\"><p>Aker Solutions’ offshore facility designs provide safe and efficient oil and gas production with an excellent availability ratio. Our facilities can be installed in any water depth, location or climate.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Design of Onshore Receiving and Processing Facilities</h5><div class=\"info\"><p>Aker Solutions has designed onshore oil and gas terminals, gas power plants, refineries and petrochemical facilities worldwide.</p></div></li><li class=\"life-cycle-col size-2-3-4\"><h5 class=\"h5 sub-heading-project\">Jacket Designs</h5><div class=\"info\"><p>Aker Solutions offers jacket design services that span from structures installed in shallow waters to large launch-installed deepwater jackets for harsh environments.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Subsea Production Systems<br></h5><div class=\"info\"><p>Aker Solutions offers an extensive portfolio of subsea production systems and products with technical capabilities to optimize the field life and production profile for our clients</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Subsea Trees<br></h5><div class=\"info\"><p>Our subsea trees are made to safely and effectively endure the toughest conditions on the planet, operating in ultra-deep waters under extreme pressures and temperatures.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Control Systems<br></h5><div class=\"info\"><p>Our remote control and monitoring systems allow safe and efficient subsea production operations in all climates and water depths.</p></div></li><li class=\"life-cycle-col size-1-2-3\"><h5 class=\"h5 sub-heading-project\">Wellheads<br></h5><div class=\"info\"><p>Aker Solutions is a leading supplier of engineering, manufacturing, installation and life-of-field support of subsea wellheads worldwide.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Umbilicals<br></h5><div class=\"info\"><p>Our unique and robust umbilical systems provide predictable performance during installation and service in any water depth or climate, anywhere.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Subsea Structures<br></h5><div class=\"info\"><p>We provide standardized and custom designs of subsea structures for any water depth, climate and installation method, anywhere in the world.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Tie-In Systems<br></h5><div class=\"info\"><p>Our tie-in systems are designed for quick, cost-effective installations in shallow and deep waters. An extensive portfolio of field proven components, provide a large range of possible applications and installation methods.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Subsea Compression Systems<br></h5><div class=\"info\"><p>Aker Solutions’ subsea compression systems provide robust and flexible solutions with the highest flowrates and pressure ratio capabilities in the industry.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Subsea Pump Systems<br></h5><div class=\"info\"><p>Our subsea pumps produce the highest boost in the industry and can increase production in all field scenarios.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Subsea Power Distribution Systems<br></h5><div class=\"info\"><p>Aker Solutions supplies complete and cost-effective power distribution solutions for subsea processing and boosting installations.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Subsea Processing Systems</h5><div class=\"info\"><p>We offer robust, flexible and cost efficient subsea processing systems based on both groundbreaking and proven technologies.</p></div></li><li class=\"life-cycle-col size-2-3-4\"><h5 class=\"h5 sub-heading-project\">Lifecycle Services</h5><div class=\"info\"><p>Through regional service bases and central support we deliver services to optimize our client’s assets, enhance production rates and increase oil recovery.</p></div></li><li class=\"life-cycle-col size-2-3-4\"><h5 class=\"h5 sub-heading-project\">Intervention and Workover Systems</h5><div class=\"info\"><p>Aker Solutions’ workover systems can be used on any subsea tree, from any vendor, in any conditions and water depth.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Carbon Capture, Utilization and Storage</h5><div class=\"info\"><p>Aker Solutions\' cost-efficient carbon capture technology is commercially ready and can be applied on various types of industrial emissions. We offer key competence via studies and project execution, including technology and products throughout the entire Carbon Capture and Storage (CCS) value chain.</p></div></li><li class=\"life-cycle-col size-2-3\"><h5 class=\"h5 sub-heading-project\">Hook-Up and Completion</h5><div class=\"info\"><p>Aker Solutions provides cost-effective, predictable and safe completion deliveries that prepare for the start-up of oil and gas production.</p></div></li><li class=\"life-cycle-col size-2-3-4\"><h5 class=\"h5 sub-heading-project\">Maintenance</h5><div class=\"info\"><p>Aker Solutions plans, manages and carries out maintenance through the life of an offshore oil and gas asset.</p></div></li><li class=\"life-cycle-col size-2-3-4\"><h5 class=\"h5 sub-heading-project\">Modifications</h5><div class=\"info\"><p>Aker Solutions is one of the world’s leading contractors for upgrading and modifying oil and gas production, receiving and processing facilities.</p></div></li><li class=\"life-cycle-col size-2-3-4\"><h5 class=\"h5 sub-heading-project\">Asset Integrity Management</h5><div class=\"info\"><p>We offer safe operations, increased reliability, improved production and lower costs through our integrated provision.</p></div></li><li class=\"life-cycle-col size-3-4\"><h5 class=\"h5 sub-heading-project\">Decommissioning</h5><div class=\"info\"><p>Aker Solutions has the expertise and experience for safe and cost-efficient decommissioning of offshore oil and gas facilities, from studies and engineering to removal, dismantling and recycling.</p></div></li><li class=\"life-cycle-col size-2-3-4\"><h5 class=\"h5 sub-heading-project\">Yards and Fabrication<br></h5></li></ul></section>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-01 12:14:27','2019-10-01 12:20:24'),(12,'5010_012','ADSI ENGINEERING SDN BHD (ADSIE)',1,NULL,'Sub Lot 49, Lot 7522,Block 32\r\nGateway Industrial Park\r\nJalan Tun Hussein Onn\r\n97000 Bintulu, Sarawa','BINTULU','SARAWAK','97000','Malaysia','+6086 351074',NULL,'https://www.adsie.com.my/',NULL,'ADSI Engineering Sdn Bhd’s principal business include delivering services to the oil and gas industry in the area of electrical and instrumentation engineering.','<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-20 23:11:15',NULL),(13,'5010_013','MICLYN EXPRESS OFFSHORE PTE LTD (MEO)',1,NULL,'10 Hoe Chiang Road\r\n#09-01 Keppel Towers\r\nSingapore 089315','HOE CHIANG ROAD','SINGAPORE','089315','Malaysia','+65-6545 6211','+65-6820 0167','http://www.meogroup.com',NULL,'Fax: +65-6545 9211 (EOS)\r\nmarketing@meogroup.com\r\nrecruitment.sg@meogroup.com','<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-20 23:13:46',NULL),(14,'5010_014','MAJU GEOHYDRO SDN BHD',1,NULL,'Unit B-8-3, Megan Avenue II\r\nJalan Yap Kwan Seng\r\n50450 Kuala Lumpur.','KUALA LUMPUR','KUALA LUMPUR','50450','Malaysia','+60 (3) 2171 1869','+60 (3) 2166 3869','http://www.mgh.com.my/v2/',NULL,'survey@mgh.com.my','<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-20 23:15:54',NULL),(15,'5010_015','IHC IQIP SINGAPORE PTE LTD',1,NULL,'No. 7 Tuas South Street, Block B\r\nSingapore 637078','TUAS','SINGAPORE','637078','Singapore','+65 62 64 84 33','+65 62 64 19 33','https://www.ihciqip.com/',NULL,'sales.iqip.sg@ihciqip.com','IHC ILT Internal lifting tools and hydrohammers',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-20 23:19:15','2019-10-20 23:25:32'),(16,'5010_016','MENCK PTE LTD',1,NULL,'107 Tuas South Avenue 8\r\nOffshore Marine Center\r\n637036 Singapore','TUAS','SINGAPORE','637036','Singapore','+ 65 6262 22 82','+ 65 6262 4351','https://www.menck.com/',NULL,'info@menck.com','Menck ple driving hydraulic hammer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-20 23:24:57',NULL),(17,'5010_017','ZENITH ORION GEOSURVEY SDN BHD',1,NULL,'Petaling Jaya','PETALING JAYA','SELANGOR',NULL,'Malaysia',NULL,NULL,'http://zog.com.my/',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-24 16:46:37',NULL),(18,'5010_018','SHAHGHAI SALVAGE COMPANY',NULL,NULL,'Shanghai, China',NULL,'Shanghai',NULL,'China',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-10-24 16:47:53',NULL);
/*!40000 ALTER TABLE `vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'priggm80_pgs66'
--

--
-- Dumping routines for database 'priggm80_pgs66'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-27 17:39:54
