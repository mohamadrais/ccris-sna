-- MySQL dump 10.13  Distrib 5.7.27, for Linux (x86_64)
--
-- Host: localhost    Database: priggm80_pjd05
-- ------------------------------------------------------
-- Server version	5.7.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AccountPayables`
--

DROP TABLE IF EXISTS `AccountPayables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AccountPayables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `APID` varchar(100) NOT NULL,
  `OrderID` int(10) unsigned DEFAULT '0',
  `fo_Vendor` int(11) unsigned DEFAULT '0',
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `fo_UnitPrice` float(10,2) DEFAULT '0.00',
  `fo_Description` text,
  `fo_Discount` float(10,2) DEFAULT '0.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `APID_unique` (`APID`),
  KEY `OrderID` (`OrderID`),
  KEY `fo_Vendor` (`fo_Vendor`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AccountPayables`
--

LOCK TABLES `AccountPayables` WRITE;
/*!40000 ALTER TABLE `AccountPayables` DISABLE KEYS */;
/*!40000 ALTER TABLE `AccountPayables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ActCard`
--

DROP TABLE IF EXISTS `ActCard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ActCard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ACID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ACID_unique` (`ACID`),
  KEY `ccpID` (`ccpID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ActCard`
--

LOCK TABLES `ActCard` WRITE;
/*!40000 ALTER TABLE `ActCard` DISABLE KEYS */;
/*!40000 ALTER TABLE `ActCard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Approval`
--

DROP TABLE IF EXISTS `Approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Approval` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Status` varchar(40) NOT NULL,
  `Description` text,
  `other_details` text,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Approval`
--

LOCK TABLES `Approval` WRITE;
/*!40000 ALTER TABLE `Approval` DISABLE KEYS */;
INSERT INTO `Approval` (`id`, `Status`, `Description`, `other_details`, `filed`, `last_modified`) VALUES (1,'Open','Open item for Approval',NULL,'2018-06-05 15:10:58',NULL),(2,'Ongoing','Ongoing item for Approval',NULL,'2018-06-05 15:11:19',NULL),(3,'Pending','Pending item for Approval',NULL,'2018-06-05 15:11:36',NULL),(4,'Close','Close item for Approval',NULL,'2018-06-05 15:12:10',NULL);
/*!40000 ALTER TABLE `Approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Audit`
--

DROP TABLE IF EXISTS `Audit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Audit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AuditNo` varchar(40) NOT NULL,
  `Rectitle` varchar(256) DEFAULT NULL,
  `fo_Desc` text,
  `fo_Auditor` varchar(10) NOT NULL,
  `fo_Classification` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `fo_AuditMemo` tinyint(4) DEFAULT '0',
  `fo_AuditPlan` tinyint(4) DEFAULT '0',
  `fo_AuditNote` tinyint(4) DEFAULT '0',
  `fo_AuditReport` tinyint(4) DEFAULT '0',
  `fo_NoObservation` smallint(6) DEFAULT '0',
  `fo_NoMinorNC` smallint(6) DEFAULT '0',
  `fo_NoMajorNC` smallint(6) DEFAULT '0',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `AuditNo_unique` (`AuditNo`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Audit`
--

LOCK TABLES `Audit` WRITE;
/*!40000 ALTER TABLE `Audit` DISABLE KEYS */;
/*!40000 ALTER TABLE `Audit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Bi_WeeklyMeeting`
--

DROP TABLE IF EXISTS `Bi_WeeklyMeeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Bi_WeeklyMeeting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `BwmID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BwmID_unique` (`BwmID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bi_WeeklyMeeting`
--

LOCK TABLES `Bi_WeeklyMeeting` WRITE;
/*!40000 ALTER TABLE `Bi_WeeklyMeeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `Bi_WeeklyMeeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Breakdown`
--

DROP TABLE IF EXISTS `Breakdown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Breakdown` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recID` varchar(256) NOT NULL,
  `MTSID` int(10) unsigned DEFAULT NULL,
  `ResourceId` int(10) unsigned DEFAULT NULL,
  `Title` varchar(256) NOT NULL,
  `fo_Description` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherDetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `recID_unique` (`recID`),
  KEY `MTSID` (`MTSID`),
  KEY `ResourceId` (`ResourceId`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Breakdown`
--

LOCK TABLES `Breakdown` WRITE;
/*!40000 ALTER TABLE `Breakdown` DISABLE KEYS */;
/*!40000 ALTER TABLE `Breakdown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CalibrationCtrl`
--

DROP TABLE IF EXISTS `CalibrationCtrl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CalibrationCtrl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CalibrationID` varchar(250) NOT NULL,
  `Calibtitle` varchar(256) DEFAULT NULL,
  `fo_InventoryID` int(10) unsigned DEFAULT NULL,
  `fo_CalCom` int(11) unsigned DEFAULT NULL,
  `fo_DurCal` text,
  `fo_Delivdate` date DEFAULT NULL,
  `fo_contact_person` varchar(100) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CalibrationID_unique` (`CalibrationID`),
  KEY `fo_InventoryID` (`fo_InventoryID`),
  KEY `fo_CalCom` (`fo_CalCom`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CalibrationCtrl`
--

LOCK TABLES `CalibrationCtrl` WRITE;
/*!40000 ALTER TABLE `CalibrationCtrl` DISABLE KEYS */;
/*!40000 ALTER TABLE `CalibrationCtrl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Campaign`
--

DROP TABLE IF EXISTS `Campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Campaign` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CampaignID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CampaignID_unique` (`CampaignID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Campaign`
--

LOCK TABLES `Campaign` WRITE;
/*!40000 ALTER TABLE `Campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `Campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClaimRecord`
--

DROP TABLE IF EXISTS `ClaimRecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ClaimRecord` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CRID` varchar(100) NOT NULL,
  `ReceivablesID` int(10) unsigned DEFAULT '0',
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_UnitPrice` float(10,2) DEFAULT '0.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CRID_unique` (`CRID`),
  KEY `ReceivablesID` (`ReceivablesID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClaimRecord`
--

LOCK TABLES `ClaimRecord` WRITE;
/*!40000 ALTER TABLE `ClaimRecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `ClaimRecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Client`
--

DROP TABLE IF EXISTS `Client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Client` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ClientID` varchar(250) NOT NULL,
  `CompanyName` varchar(255) DEFAULT NULL,
  `fo_ContactName` varchar(200) DEFAULT NULL,
  `fo_ContactTitle` varchar(200) DEFAULT NULL,
  `fo_Address` varchar(250) DEFAULT NULL,
  `fo_City` varchar(100) DEFAULT NULL,
  `fo_Region` varchar(100) DEFAULT NULL,
  `fo_PostalCode` varchar(10) DEFAULT NULL,
  `fo_Country` varchar(15) DEFAULT NULL,
  `fo_Phone` varchar(24) DEFAULT NULL,
  `fo_Fax` varchar(24) DEFAULT NULL,
  `fo_Email` varchar(80) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherDetails` text,
  `ot_Comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ClientID_unique` (`ClientID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Client`
--

LOCK TABLES `Client` WRITE;
/*!40000 ALTER TABLE `Client` DISABLE KEYS */;
INSERT INTO `Client` (`id`, `ClientID`, `CompanyName`, `fo_ContactName`, `fo_ContactTitle`, `fo_Address`, `fo_City`, `fo_Region`, `fo_PostalCode`, `fo_Country`, `fo_Phone`, `fo_Fax`, `fo_Email`, `ot_FileLoc`, `ot_otherDetails`, `ot_Comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'2030_001','Edgenta PROPEL Berhad','Rashid','Managing Director','Pejabat Wilayah Selatan,\r\nNo. 1, 1A & 1B, Jalan Bukit Tropika Utama 1,\r\nTaman Bukit Tropika,','YONG PENG','Central','83700','Malaysia','+607 467 5700','+607 467 5701',NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 15:40:41',NULL);
/*!40000 ALTER TABLE `Client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CommConsParticipate`
--

DROP TABLE IF EXISTS `CommConsParticipate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CommConsParticipate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ccpID` varchar(40) NOT NULL,
  `WorkLocationID` int(10) unsigned DEFAULT NULL,
  `fo_WorkDate` date DEFAULT NULL,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ccpID_unique` (`ccpID`),
  KEY `WorkLocationID` (`WorkLocationID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CommConsParticipate`
--

LOCK TABLES `CommConsParticipate` WRITE;
/*!40000 ALTER TABLE `CommConsParticipate` DISABLE KEYS */;
/*!40000 ALTER TABLE `CommConsParticipate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Competency`
--

DROP TABLE IF EXISTS `Competency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Competency` (
  `CompetencyID` int(11) NOT NULL AUTO_INCREMENT,
  `CompID` varchar(200) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `ProjectTeamID` int(11) DEFAULT NULL,
  `fo_CompetencySession` varchar(40) DEFAULT NULL,
  `fo_Description` text,
  `fo_Date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`CompetencyID`),
  UNIQUE KEY `CompID_unique` (`CompID`),
  KEY `EmployeeID` (`EmployeeID`),
  KEY `ProjectTeamID` (`ProjectTeamID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Competency`
--

LOCK TABLES `Competency` WRITE;
/*!40000 ALTER TABLE `Competency` DISABLE KEYS */;
/*!40000 ALTER TABLE `Competency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ContinualImprovement`
--

DROP TABLE IF EXISTS `ContinualImprovement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ContinualImprovement` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CAPARno` varchar(40) NOT NULL,
  `RecTitle` varchar(256) DEFAULT NULL,
  `fo_Class` varchar(100) NOT NULL,
  `fo_CAPAR` text NOT NULL,
  `fo_Desc` text,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CAPARno_unique` (`CAPARno`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContinualImprovement`
--

LOCK TABLES `ContinualImprovement` WRITE;
/*!40000 ALTER TABLE `ContinualImprovement` DISABLE KEYS */;
/*!40000 ALTER TABLE `ContinualImprovement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ContractDeployment`
--

DROP TABLE IF EXISTS `ContractDeployment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ContractDeployment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(250) NOT NULL,
  `InquiryID` int(10) unsigned DEFAULT NULL,
  `fo_Type` text NOT NULL,
  `fo_Tajuk` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_ExeDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `InquiryID` (`InquiryID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContractDeployment`
--

LOCK TABLES `ContractDeployment` WRITE;
/*!40000 ALTER TABLE `ContractDeployment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ContractDeployment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DCN`
--

DROP TABLE IF EXISTS `DCN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DCN` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(255) NOT NULL,
  `DCCID` int(10) unsigned DEFAULT '0',
  `fo_DCCITEM` int(10) unsigned DEFAULT '0',
  `fo_Description` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `DCCID` (`DCCID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DCN`
--

LOCK TABLES `DCN` WRITE;
/*!40000 ALTER TABLE `DCN` DISABLE KEYS */;
/*!40000 ALTER TABLE `DCN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DailyProgressReport`
--

DROP TABLE IF EXISTS `DailyProgressReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DailyProgressReport` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ProgressReportId` varchar(100) NOT NULL,
  `DPRID` int(10) unsigned DEFAULT '0',
  `fo_Class` varchar(40) NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProgressReportId_unique` (`ProgressReportId`),
  KEY `DPRID` (`DPRID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DailyProgressReport`
--

LOCK TABLES `DailyProgressReport` WRITE;
/*!40000 ALTER TABLE `DailyProgressReport` DISABLE KEYS */;
/*!40000 ALTER TABLE `DailyProgressReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DeliveryOrder`
--

DROP TABLE IF EXISTS `DeliveryOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DeliveryOrder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DOID` varchar(100) NOT NULL,
  `OrderID` int(10) unsigned DEFAULT '0',
  `fo_Vendor` int(11) unsigned DEFAULT '0',
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `fo_Description` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DOID_unique` (`DOID`),
  KEY `OrderID` (`OrderID`),
  KEY `fo_Vendor` (`fo_Vendor`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DeliveryOrder`
--

LOCK TABLES `DeliveryOrder` WRITE;
/*!40000 ALTER TABLE `DeliveryOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `DeliveryOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DesignProposal`
--

DROP TABLE IF EXISTS `DesignProposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DesignProposal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `InquiryID` int(10) unsigned DEFAULT NULL,
  `fo_Type` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Intro` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_RecSub` tinyblob NOT NULL,
  `fo_Submissiondate` date DEFAULT NULL,
  `fo_contact_person` varchar(100) DEFAULT NULL,
  `fo_Price` decimal(10,2) DEFAULT '0.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `InquiryID` (`InquiryID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DesignProposal`
--

LOCK TABLES `DesignProposal` WRITE;
/*!40000 ALTER TABLE `DesignProposal` DISABLE KEYS */;
/*!40000 ALTER TABLE `DesignProposal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DocControl`
--

DROP TABLE IF EXISTS `DocControl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DocControl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(250) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Class` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_DocumentType` text NOT NULL,
  `fo_Rev` varchar(256) DEFAULT '00',
  `fo_date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DocControl`
--

LOCK TABLES `DocControl` WRITE;
/*!40000 ALTER TABLE `DocControl` DISABLE KEYS */;
/*!40000 ALTER TABLE `DocControl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DrillNInspection`
--

DROP TABLE IF EXISTS `DrillNInspection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DrillNInspection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DillID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DillID_unique` (`DillID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DrillNInspection`
--

LOCK TABLES `DrillNInspection` WRITE;
/*!40000 ALTER TABLE `DrillNInspection` DISABLE KEYS */;
/*!40000 ALTER TABLE `DrillNInspection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ERP`
--

DROP TABLE IF EXISTS `ERP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ERP` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Registerdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ERP`
--

LOCK TABLES `ERP` WRITE;
/*!40000 ALTER TABLE `ERP` DISABLE KEYS */;
/*!40000 ALTER TABLE `ERP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EventNotification`
--

DROP TABLE IF EXISTS `EventNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EventNotification` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ENID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ENID_unique` (`ENID`),
  KEY `ccpID` (`ccpID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EventNotification`
--

LOCK TABLES `EventNotification` WRITE;
/*!40000 ALTER TABLE `EventNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `EventNotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IMSControl`
--

DROP TABLE IF EXISTS `IMSControl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IMSControl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Status` varchar(40) NOT NULL,
  `Description` text,
  `other_details` text,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IMSControl`
--

LOCK TABLES `IMSControl` WRITE;
/*!40000 ALTER TABLE `IMSControl` DISABLE KEYS */;
INSERT INTO `IMSControl` (`id`, `Status`, `Description`, `other_details`, `filed`, `last_modified`) VALUES (1,'Open','Open item for IMS Control',NULL,'2018-06-05 15:12:37',NULL),(2,'Ongoing','Ongoing item for IMS Control',NULL,'2018-06-05 15:13:13',NULL),(3,'Pending','Pending item for IMS Control',NULL,'2018-06-05 15:13:29',NULL),(4,'Close','Close item for IMS Control',NULL,'2018-06-05 15:13:48',NULL);
/*!40000 ALTER TABLE `IMSControl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IMSDataAnalysis`
--

DROP TABLE IF EXISTS `IMSDataAnalysis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IMSDataAnalysis` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `worklocID` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `worklocID` (`worklocID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IMSDataAnalysis`
--

LOCK TABLES `IMSDataAnalysis` WRITE;
/*!40000 ALTER TABLE `IMSDataAnalysis` DISABLE KEYS */;
/*!40000 ALTER TABLE `IMSDataAnalysis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IMSReport`
--

DROP TABLE IF EXISTS `IMSReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IMSReport` (
  `Postid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Title` varchar(40) NOT NULL,
  `image` varchar(40) DEFAULT NULL,
  `TextPost` text,
  `website` varchar(200) DEFAULT NULL,
  `Ref01` varchar(40) DEFAULT NULL,
  `ClosedIssue` tinyint(4) DEFAULT '0',
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`Postid`),
  UNIQUE KEY `Title_unique` (`Title`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IMSReport`
--

LOCK TABLES `IMSReport` WRITE;
/*!40000 ALTER TABLE `IMSReport` DISABLE KEYS */;
INSERT INTO `IMSReport` (`Postid`, `Title`, `image`, `TextPost`, `website`, `Ref01`, `ClosedIssue`, `filed`, `last_modified`) VALUES (1,'Please Report all complaint here','86641600_1528182912.jpg','Dear all, appreciate to kindly report all complaint from stakeholder onto this table. \r\n\r\nthe issue shall be taken into consideration for further improvement on the organization\r\n\r\nthank you',NULL,NULL,NULL,'2018-06-05 15:15:12',NULL);
/*!40000 ALTER TABLE `IMSReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IMStrackingNmonitoring`
--

DROP TABLE IF EXISTS `IMStrackingNmonitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IMStrackingNmonitoring` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `WorklocID` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `WorklocID` (`WorklocID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IMStrackingNmonitoring`
--

LOCK TABLES `IMStrackingNmonitoring` WRITE;
/*!40000 ALTER TABLE `IMStrackingNmonitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `IMStrackingNmonitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `InOutRegister`
--

DROP TABLE IF EXISTS `InOutRegister`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `InOutRegister` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecordNumber` varchar(40) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` varchar(255) NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Delivdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecordNumber_unique` (`RecordNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `InOutRegister`
--

LOCK TABLES `InOutRegister` WRITE;
/*!40000 ALTER TABLE `InOutRegister` DISABLE KEYS */;
/*!40000 ALTER TABLE `InOutRegister` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `IncidentReporting`
--

DROP TABLE IF EXISTS `IncidentReporting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `IncidentReporting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `IncidentReporting`
--

LOCK TABLES `IncidentReporting` WRITE;
/*!40000 ALTER TABLE `IncidentReporting` DISABLE KEYS */;
/*!40000 ALTER TABLE `IncidentReporting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Inquiry`
--

DROP TABLE IF EXISTS `Inquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Inquiry` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `InqNumber` varchar(100) NOT NULL,
  `ClientID` int(10) unsigned DEFAULT NULL,
  `fo_InquiryDate` date DEFAULT NULL,
  `fo_DueDate` date DEFAULT NULL,
  `fo_kelasifikasi` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_DeliveryDate` date DEFAULT NULL,
  `fo_Logistic` int(11) unsigned DEFAULT NULL,
  `fo_Freight` float(10,2) DEFAULT '0.00',
  `fo_ShipName` int(10) unsigned DEFAULT NULL,
  `fo_ShipAddress` int(10) unsigned DEFAULT NULL,
  `fo_ShipCity` int(10) unsigned DEFAULT NULL,
  `fo_ShipRegion` int(10) unsigned DEFAULT NULL,
  `fo_ShipPostalCode` int(10) unsigned DEFAULT NULL,
  `fo_ShipCountry` int(10) unsigned DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `InqNumber_unique` (`InqNumber`),
  KEY `ClientID` (`ClientID`),
  KEY `fo_Logistic` (`fo_Logistic`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Inquiry`
--

LOCK TABLES `Inquiry` WRITE;
/*!40000 ALTER TABLE `Inquiry` DISABLE KEYS */;
INSERT INTO `Inquiry` (`id`, `InqNumber`, `ClientID`, `fo_InquiryDate`, `fo_DueDate`, `fo_kelasifikasi`, `fo_DeliveryDate`, `fo_Logistic`, `fo_Freight`, `fo_ShipName`, `fo_ShipAddress`, `fo_ShipCity`, `fo_ShipRegion`, `fo_ShipPostalCode`, `fo_ShipCountry`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'2040_001',1,'2018-03-05','2018-04-05','Tender Bidding','2018-06-01',1,0.00,1,1,1,1,1,1,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,4,NULL,4,NULL,4,NULL,'2018-06-05 15:43:47','2018-06-05 15:46:00');
/*!40000 ALTER TABLE `Inquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Inventory`
--

DROP TABLE IF EXISTS `Inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Inventory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `InventoryID` varchar(100) NOT NULL,
  `asstitle` varchar(256) DEFAULT NULL,
  `Description` text,
  `fo_Type` varchar(100) DEFAULT NULL,
  `fo_Manufacturer` varchar(250) DEFAULT NULL,
  `fo_ModelNumber` varchar(250) DEFAULT NULL,
  `fo_SerialNumber` varchar(250) DEFAULT NULL,
  `fo_Condition` text,
  `fo_history` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_Quantity` int(11) DEFAULT '0',
  `fo_UnitPrice` float(10,2) DEFAULT '0.00',
  `fo_Remarks` text,
  `fo_date` date DEFAULT NULL,
  `fo_ItemLocation` varchar(100) DEFAULT NULL,
  `fo_image` varchar(40) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `InventoryID_unique` (`InventoryID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Inventory`
--

LOCK TABLES `Inventory` WRITE;
/*!40000 ALTER TABLE `Inventory` DISABLE KEYS */;
INSERT INTO `Inventory` (`id`, `InventoryID`, `asstitle`, `Description`, `fo_Type`, `fo_Manufacturer`, `fo_ModelNumber`, `fo_SerialNumber`, `fo_Condition`, `fo_history`, `fo_Quantity`, `fo_UnitPrice`, `fo_Remarks`, `fo_date`, `fo_ItemLocation`, `fo_image`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_last_modified`) VALUES (1,'5030-001','NOT APPLICABLE','<span style=\"font-size: 11.998px;\">Generic line item for asset. This is prepared for general default setting</span><br>','Others','Not Applicable','Not Applicable','Not Applicable','Unknown','None',0,0.00,NULL,'2018-06-05',NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,4,NULL,4,NULL,4,NULL,'2018-06-05 16:16:48',NULL),(2,'5030_002','PRODUA KEMBARA SUV','White Kembara SUV<div>For Operational use</div>','Asset','PRODUA','KEMBARA','JDT1020','Functional','Repaired',1,70000.00,NULL,'2018-06-05',NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:21:11',NULL);
/*!40000 ALTER TABLE `Inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Item`
--

DROP TABLE IF EXISTS `Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Item` (
  `ProductID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` varchar(200) NOT NULL,
  `ProductName` varchar(50) DEFAULT NULL,
  `fo_SupplierID` int(11) unsigned DEFAULT NULL,
  `fo_CategoryID` int(11) DEFAULT NULL,
  `fo_QuantityPerUnit` varchar(50) DEFAULT NULL,
  `fo_UnitPrice` float(10,2) DEFAULT '0.00',
  `fo_UnitsInStock` smallint(6) DEFAULT '0',
  `fo_UnitsOnOrder` smallint(6) DEFAULT '0',
  `fo_ReorderLevel` smallint(6) DEFAULT '0',
  `fo_Description` text,
  `fo_Discontinued` tinyint(4) DEFAULT '0',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`ProductID`),
  UNIQUE KEY `ItemID_unique` (`ItemID`),
  KEY `fo_SupplierID` (`fo_SupplierID`),
  KEY `fo_CategoryID` (`fo_CategoryID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Item`
--

LOCK TABLES `Item` WRITE;
/*!40000 ALTER TABLE `Item` DISABLE KEYS */;
/*!40000 ALTER TABLE `Item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `JD_JS`
--

DROP TABLE IF EXISTS `JD_JS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `JD_JS` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecordNumber` varchar(40) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` varchar(255) NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_ProjectTeamID` int(11) DEFAULT NULL,
  `fo_JDDesc` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecordNumber_unique` (`RecordNumber`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `fo_ProjectTeamID` (`fo_ProjectTeamID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `JD_JS`
--

LOCK TABLES `JD_JS` WRITE;
/*!40000 ALTER TABLE `JD_JS` DISABLE KEYS */;
INSERT INTO `JD_JS` (`id`, `RecordNumber`, `DocItem`, `fo_DocumentDescription`, `fo_Classification`, `fo_EmployeeID`, `fo_ProjectTeamID`, `fo_JDDesc`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'3020_001','Marketing Executive','Business & Development','Executive',2,1,'<br>',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:43:52',NULL);
/*!40000 ALTER TABLE `JD_JS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KM`
--

DROP TABLE IF EXISTS `KM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KM` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocumentName` varchar(250) NOT NULL,
  `fo_Description` text,
  `fo_Reference` varchar(40) NOT NULL,
  `fo_Volume` varchar(100) NOT NULL,
  `fo_Classification` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_Class` varchar(100) DEFAULT 'Unknown',
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocumentName_unique` (`DocumentName`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KM`
--

LOCK TABLES `KM` WRITE;
/*!40000 ALTER TABLE `KM` DISABLE KEYS */;
/*!40000 ALTER TABLE `KM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Leadership`
--

DROP TABLE IF EXISTS `Leadership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Leadership` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Status` varchar(40) NOT NULL,
  `Description` text,
  `other_details` text,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Leadership`
--

LOCK TABLES `Leadership` WRITE;
/*!40000 ALTER TABLE `Leadership` DISABLE KEYS */;
INSERT INTO `Leadership` (`id`, `Status`, `Description`, `other_details`, `filed`, `last_modified`) VALUES (1,'Open','Open Item for Review and verification',NULL,'2018-06-05 15:05:26','2018-06-05 15:09:00'),(2,'Ongoing','Ongoing Item for Review and verification',NULL,'2018-06-05 15:09:26',NULL),(3,'Pending','Pending Item for Review and verification',NULL,'2018-06-05 15:10:09',NULL),(4,'Close','Close Item for Review and verification',NULL,'2018-06-05 15:10:26',NULL);
/*!40000 ALTER TABLE `Leadership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LegalRegister`
--

DROP TABLE IF EXISTS `LegalRegister`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LegalRegister` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LRNumber` varchar(40) NOT NULL,
  `LegalItem` varchar(255) NOT NULL,
  `fo_LRDescription` text,
  `fo_Classification` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_Class` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `LRNumber_unique` (`LRNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LegalRegister`
--

LOCK TABLES `LegalRegister` WRITE;
/*!40000 ALTER TABLE `LegalRegister` DISABLE KEYS */;
/*!40000 ALTER TABLE `LegalRegister` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LogisticRequest`
--

DROP TABLE IF EXISTS `LogisticRequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `LogisticRequest` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `LogisticNumber` varchar(100) NOT NULL,
  `Market_Survey` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_ResourcesID` int(10) unsigned DEFAULT NULL,
  `fo_ProjectID` int(10) unsigned DEFAULT NULL,
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `fo_Deliverydate` date DEFAULT NULL,
  `fo_address` text,
  `fo_city` varchar(40) DEFAULT NULL,
  `fo_zip` char(8) DEFAULT NULL,
  `fo_Countrys` varchar(100) DEFAULT NULL,
  `fo_homephone` varchar(40) DEFAULT NULL,
  `fo_workphone` varchar(40) DEFAULT NULL,
  `fo_contactperson` varchar(100) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `LogisticNumber_unique` (`LogisticNumber`),
  KEY `fo_ResourcesID` (`fo_ResourcesID`),
  KEY `fo_ProjectID` (`fo_ProjectID`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LogisticRequest`
--

LOCK TABLES `LogisticRequest` WRITE;
/*!40000 ALTER TABLE `LogisticRequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `LogisticRequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Logistics`
--

DROP TABLE IF EXISTS `Logistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Logistics` (
  `ShipperID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `LogisticID` varchar(200) NOT NULL,
  `CompanyName` varchar(200) NOT NULL,
  `fo_AVList` tinyint(4) DEFAULT '0',
  `fo_Phone` varchar(24) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`ShipperID`),
  UNIQUE KEY `LogisticID_unique` (`LogisticID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Logistics`
--

LOCK TABLES `Logistics` WRITE;
/*!40000 ALTER TABLE `Logistics` DISABLE KEYS */;
INSERT INTO `Logistics` (`ShipperID`, `LogisticID`, `CompanyName`, `fo_AVList`, `fo_Phone`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_last_modified`) VALUES (1,'5020_001','General Freight Agent',NULL,NULL,NULL,'This option made available if the mode of transportation can be source via non specific logistic arrangement','<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 15:45:23',NULL);
/*!40000 ALTER TABLE `Logistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MRM`
--

DROP TABLE IF EXISTS `MRM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MRM` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MRM`
--

LOCK TABLES `MRM` WRITE;
/*!40000 ALTER TABLE `MRM` DISABLE KEYS */;
/*!40000 ALTER TABLE `MRM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWConditionBased`
--

DROP TABLE IF EXISTS `MWConditionBased`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWConditionBased` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CondBaseID` varchar(200) NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CondBaseID_unique` (`CondBaseID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWConditionBased`
--

LOCK TABLES `MWConditionBased` WRITE;
/*!40000 ALTER TABLE `MWConditionBased` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWConditionBased` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWO`
--

DROP TABLE IF EXISTS `MWO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWO` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `MWONumber` varchar(200) NOT NULL,
  `Critical` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_InventoryID` int(10) unsigned DEFAULT NULL,
  `fo_Task` text NOT NULL,
  `fo_Category` text NOT NULL,
  `fo_JobInstruction` text NOT NULL,
  `fo_DetailInstruction` text,
  `fo_Resources` text,
  `fo_Duedate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MWONumber_unique` (`MWONumber`),
  KEY `fo_InventoryID` (`fo_InventoryID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWO`
--

LOCK TABLES `MWO` WRITE;
/*!40000 ALTER TABLE `MWO` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWOCorrective`
--

DROP TABLE IF EXISTS `MWOCorrective`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWOCorrective` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CorrectiveID` varchar(200) NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CorrectiveID_unique` (`CorrectiveID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWOCorrective`
--

LOCK TABLES `MWOCorrective` WRITE;
/*!40000 ALTER TABLE `MWOCorrective` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWOCorrective` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWOPlanned`
--

DROP TABLE IF EXISTS `MWOPlanned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWOPlanned` (
  `WMOPlannedID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PlannedID` int(10) unsigned NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`WMOPlannedID`),
  UNIQUE KEY `PlannedID_unique` (`PlannedID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWOPlanned`
--

LOCK TABLES `MWOPlanned` WRITE;
/*!40000 ALTER TABLE `MWOPlanned` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWOPlanned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWOReactive`
--

DROP TABLE IF EXISTS `MWOReactive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWOReactive` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ReactiveID` varchar(200) NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ReactiveID_unique` (`ReactiveID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWOReactive`
--

LOCK TABLES `MWOReactive` WRITE;
/*!40000 ALTER TABLE `MWOReactive` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWOReactive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWOpreventive`
--

DROP TABLE IF EXISTS `MWOpreventive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWOpreventive` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PreventiveID` varchar(200) NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PreventiveID_unique` (`PreventiveID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWOpreventive`
--

LOCK TABLES `MWOpreventive` WRITE;
/*!40000 ALTER TABLE `MWOpreventive` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWOpreventive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MWOproactive`
--

DROP TABLE IF EXISTS `MWOproactive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MWOproactive` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ProactiveID` varchar(200) NOT NULL,
  `MwoID` int(10) unsigned DEFAULT '0',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ProactiveID_unique` (`ProactiveID`),
  KEY `MwoID` (`MwoID`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MWOproactive`
--

LOCK TABLES `MWOproactive` WRITE;
/*!40000 ALTER TABLE `MWOproactive` DISABLE KEYS */;
/*!40000 ALTER TABLE `MWOproactive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ManagementVisit`
--

DROP TABLE IF EXISTS `ManagementVisit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ManagementVisit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `MgtVstID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `MgtVstID_unique` (`MgtVstID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ManagementVisit`
--

LOCK TABLES `ManagementVisit` WRITE;
/*!40000 ALTER TABLE `ManagementVisit` DISABLE KEYS */;
/*!40000 ALTER TABLE `ManagementVisit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ManagingVendor`
--

DROP TABLE IF EXISTS `ManagingVendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ManagingVendor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ManagingVendNumber` varchar(40) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_VendorID` int(11) unsigned DEFAULT NULL,
  `fo_DocumentDescription` varchar(255) NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Auditdate` date DEFAULT NULL,
  `fo_image` varchar(40) DEFAULT NULL,
  `fo_address` text,
  `fo_city` varchar(40) DEFAULT NULL,
  `fo_state` varchar(15) DEFAULT NULL,
  `fo_zip` char(8) DEFAULT NULL,
  `fo_workphone` varchar(40) DEFAULT NULL,
  `fo_mobile` varchar(40) DEFAULT NULL,
  `fo_contactperson` varchar(100) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ManagingVendNumber_unique` (`ManagingVendNumber`),
  KEY `fo_VendorID` (`fo_VendorID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ManagingVendor`
--

LOCK TABLES `ManagingVendor` WRITE;
/*!40000 ALTER TABLE `ManagingVendor` DISABLE KEYS */;
/*!40000 ALTER TABLE `ManagingVendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Marketing`
--

DROP TABLE IF EXISTS `Marketing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Marketing` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecordNumber` varchar(250) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Type` varchar(250) NOT NULL DEFAULT 'Unknown',
  `fo_Source` varchar(256) NOT NULL,
  `fo_Qualification` varchar(256) DEFAULT NULL,
  `fo_DateUpload` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecordNumber_unique` (`RecordNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Marketing`
--

LOCK TABLES `Marketing` WRITE;
/*!40000 ALTER TABLE `Marketing` DISABLE KEYS */;
INSERT INTO `Marketing` (`id`, `RecordNumber`, `DocItem`, `fo_DocumentDescription`, `fo_Type`, `fo_Source`, `fo_Qualification`, `fo_DateUpload`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'2020_001','PLUS: Introduction Meeting','Main Contractor meeting with PLUS the MD. The opportunity of:\r\n1_Road Intervention\r\n2_Maintenance 5 years','Campaigns','Face to Face','Active Opportunity','2018-04-15',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 15:34:18',NULL);
/*!40000 ALTER TABLE `Marketing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MgtofChange`
--

DROP TABLE IF EXISTS `MgtofChange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MgtofChange` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `fo_Desc` text,
  `fo_class` text NOT NULL,
  `fo_regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MgtofChange`
--

LOCK TABLES `MgtofChange` WRITE;
/*!40000 ALTER TABLE `MgtofChange` DISABLE KEYS */;
/*!40000 ALTER TABLE `MgtofChange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MonthlyTimesheet`
--

DROP TABLE IF EXISTS `MonthlyTimesheet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MonthlyTimesheet` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TimesheetID` varchar(100) NOT NULL,
  `MTSID` int(10) unsigned DEFAULT '0',
  `fo_Class` varchar(40) NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TimesheetID_unique` (`TimesheetID`),
  KEY `MTSID` (`MTSID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MonthlyTimesheet`
--

LOCK TABLES `MonthlyTimesheet` WRITE;
/*!40000 ALTER TABLE `MonthlyTimesheet` DISABLE KEYS */;
/*!40000 ALTER TABLE `MonthlyTimesheet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NonConformance`
--

DROP TABLE IF EXISTS `NonConformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NonConformance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `worklocID` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `fo_ClosedIssue` tinyint(4) DEFAULT '0',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `worklocID` (`worklocID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NonConformance`
--

LOCK TABLES `NonConformance` WRITE;
/*!40000 ALTER TABLE `NonConformance` DISABLE KEYS */;
/*!40000 ALTER TABLE `NonConformance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ObsoleteRec`
--

DROP TABLE IF EXISTS `ObsoleteRec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ObsoleteRec` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(255) NOT NULL,
  `DCCID` int(10) unsigned DEFAULT '0',
  `fo_DCCITEM` int(10) unsigned DEFAULT '0',
  `fo_Description` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `DCCID` (`DCCID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ObsoleteRec`
--

LOCK TABLES `ObsoleteRec` WRITE;
/*!40000 ALTER TABLE `ObsoleteRec` DISABLE KEYS */;
/*!40000 ALTER TABLE `ObsoleteRec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrgContentContext`
--

DROP TABLE IF EXISTS `OrgContentContext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `OrgContentContext` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecordNumber` varchar(250) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Type` varchar(250) NOT NULL DEFAULT 'Unknown',
  `fo_genrec` varchar(256) NOT NULL,
  `fo_Update` varchar(256) DEFAULT NULL,
  `fo_DateUpload` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecordNumber_unique` (`RecordNumber`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrgContentContext`
--

LOCK TABLES `OrgContentContext` WRITE;
/*!40000 ALTER TABLE `OrgContentContext` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrgContentContext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROCompletion`
--

DROP TABLE IF EXISTS `PROCompletion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROCompletion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `CompletionNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_Classification` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CompletionNo_unique` (`CompletionNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROCompletion`
--

LOCK TABLES `PROCompletion` WRITE;
/*!40000 ALTER TABLE `PROCompletion` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROCompletion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROControlMonitoring`
--

DROP TABLE IF EXISTS `PROControlMonitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROControlMonitoring` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ContMonitNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_AuditInspection` text NOT NULL,
  `fo_Classification` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ContMonitNo_unique` (`ContMonitNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROControlMonitoring`
--

LOCK TABLES `PROControlMonitoring` WRITE;
/*!40000 ALTER TABLE `PROControlMonitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROControlMonitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROExecution`
--

DROP TABLE IF EXISTS `PROExecution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROExecution` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ExecutionNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_Classification` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ExecutionNo_unique` (`ExecutionNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROExecution`
--

LOCK TABLES `PROExecution` WRITE;
/*!40000 ALTER TABLE `PROExecution` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROExecution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROInitiation`
--

DROP TABLE IF EXISTS `PROInitiation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROInitiation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `InitiationNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_InitiationForm` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `InitiationNo_unique` (`InitiationNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROInitiation`
--

LOCK TABLES `PROInitiation` WRITE;
/*!40000 ALTER TABLE `PROInitiation` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROInitiation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROPlanning`
--

DROP TABLE IF EXISTS `PROPlanning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROPlanning` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PlanningNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_RelatedDocument` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PlanningNo_unique` (`PlanningNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROPlanning`
--

LOCK TABLES `PROPlanning` WRITE;
/*!40000 ALTER TABLE `PROPlanning` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROPlanning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROVariation`
--

DROP TABLE IF EXISTS `PROVariation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROVariation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `VariationNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `fo_Classification` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `VariationNo_unique` (`VariationNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROVariation`
--

LOCK TABLES `PROVariation` WRITE;
/*!40000 ALTER TABLE `PROVariation` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROVariation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PersonnalFile`
--

DROP TABLE IF EXISTS `PersonnalFile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PersonnalFile` (
  `PersonalFileID` int(11) NOT NULL AUTO_INCREMENT,
  `FileID` varchar(200) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `ProjectTeamID` int(11) DEFAULT NULL,
  `fo_PersonalFileDesc` varchar(40) DEFAULT NULL,
  `fo_Description` text,
  `fo_Date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`PersonalFileID`),
  UNIQUE KEY `FileID_unique` (`FileID`),
  KEY `EmployeeID` (`EmployeeID`),
  KEY `ProjectTeamID` (`ProjectTeamID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PersonnalFile`
--

LOCK TABLES `PersonnalFile` WRITE;
/*!40000 ALTER TABLE `PersonnalFile` DISABLE KEYS */;
/*!40000 ALTER TABLE `PersonnalFile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProjectTeam`
--

DROP TABLE IF EXISTS `ProjectTeam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ProjectTeam` (
  `ProjectTeamID` int(11) NOT NULL AUTO_INCREMENT,
  `EmpNo` varchar(256) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_TermEmployment` varchar(50) DEFAULT NULL,
  `fo_Photo` varchar(40) DEFAULT NULL,
  `fo_Position` varchar(200) DEFAULT NULL,
  `fo_BirthDate` date DEFAULT NULL,
  `fo_HireDate` date DEFAULT NULL,
  `fo_Address` varchar(50) DEFAULT NULL,
  `fo_City` varchar(100) DEFAULT NULL,
  `fo_Region` varchar(100) DEFAULT NULL,
  `fo_PostalCode` varchar(10) DEFAULT NULL,
  `fo_Country` varchar(100) DEFAULT NULL,
  `fo_HomePhone` varchar(24) DEFAULT NULL,
  `fo_Extension` varchar(4) DEFAULT NULL,
  `fo_Notes` text,
  `fo_ReportsTo` int(11) DEFAULT NULL,
  `fo_Acknowledgement` int(11) DEFAULT '0',
  `fo_Induction` tinyint(4) DEFAULT '0',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`ProjectTeamID`),
  UNIQUE KEY `EmpNo_unique` (`EmpNo`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `fo_ReportsTo` (`fo_ReportsTo`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProjectTeam`
--

LOCK TABLES `ProjectTeam` WRITE;
/*!40000 ALTER TABLE `ProjectTeam` DISABLE KEYS */;
INSERT INTO `ProjectTeam` (`ProjectTeamID`, `EmpNo`, `Name`, `BaseLocation`, `fo_TermEmployment`, `fo_Photo`, `fo_Position`, `fo_BirthDate`, `fo_HireDate`, `fo_Address`, `fo_City`, `fo_Region`, `fo_PostalCode`, `fo_Country`, `fo_HomePhone`, `fo_Extension`, `fo_Notes`, `fo_ReportsTo`, `fo_Acknowledgement`, `fo_Induction`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'4040-001','NOT APPLICABLE',1,'Others',NULL,'NOT APPLICABLE',NULL,'2018-06-05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Default selection for application that has non applicability',NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,4,NULL,4,NULL,4,NULL,'2018-06-05 15:29:35',NULL);
/*!40000 ALTER TABLE `ProjectTeam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PurchaseOrder`
--

DROP TABLE IF EXISTS `PurchaseOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PurchaseOrder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `POID` varchar(100) NOT NULL,
  `OrderID` int(10) unsigned DEFAULT '0',
  `fo_Vendor` int(11) unsigned DEFAULT '0',
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `fo_Price` decimal(10,2) DEFAULT '0.00',
  `fo_Description` text,
  `fo_Discount` float(10,2) DEFAULT '0.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `POID_unique` (`POID`),
  KEY `OrderID` (`OrderID`),
  KEY `fo_Vendor` (`fo_Vendor`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurchaseOrder`
--

LOCK TABLES `PurchaseOrder` WRITE;
/*!40000 ALTER TABLE `PurchaseOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `PurchaseOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QA`
--

DROP TABLE IF EXISTS `QA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QA` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Class` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QA`
--

LOCK TABLES `QA` WRITE;
/*!40000 ALTER TABLE `QA` DISABLE KEYS */;
/*!40000 ALTER TABLE `QA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QuarterlyMeeting`
--

DROP TABLE IF EXISTS `QuarterlyMeeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QuarterlyMeeting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `QmID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `QmID_unique` (`QmID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QuarterlyMeeting`
--

LOCK TABLES `QuarterlyMeeting` WRITE;
/*!40000 ALTER TABLE `QuarterlyMeeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `QuarterlyMeeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Quotation`
--

DROP TABLE IF EXISTS `Quotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Quotation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `QuoID` varchar(100) NOT NULL,
  `OrderID` int(10) unsigned DEFAULT '0',
  `fo_Vendor` int(11) unsigned DEFAULT '0',
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `fo_Price` decimal(10,2) DEFAULT '0.00',
  `fo_Description` text,
  `fo_Discount` float(10,2) DEFAULT '0.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `QuoID_unique` (`QuoID`),
  KEY `OrderID` (`OrderID`),
  KEY `fo_Vendor` (`fo_Vendor`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Quotation`
--

LOCK TABLES `Quotation` WRITE;
/*!40000 ALTER TABLE `Quotation` DISABLE KEYS */;
/*!40000 ALTER TABLE `Quotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Receivables`
--

DROP TABLE IF EXISTS `Receivables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Receivables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ClaimNo` varchar(200) NOT NULL,
  `ProjectsID` int(10) unsigned DEFAULT NULL,
  `ResourcesID` int(10) unsigned DEFAULT NULL,
  `fo_Classification` text NOT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_UnitPrice` float(10,2) DEFAULT '0.00',
  `fo_DocumentDescription` text NOT NULL,
  `fo_Registerdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ClaimNo_unique` (`ClaimNo`),
  KEY `ProjectsID` (`ProjectsID`),
  KEY `ResourcesID` (`ResourcesID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Receivables`
--

LOCK TABLES `Receivables` WRITE;
/*!40000 ALTER TABLE `Receivables` DISABLE KEYS */;
/*!40000 ALTER TABLE `Receivables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Recruitment`
--

DROP TABLE IF EXISTS `Recruitment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Recruitment` (
  `RecruitID` int(11) NOT NULL AUTO_INCREMENT,
  `CompID` varchar(200) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `ProjectTeamID` int(11) DEFAULT NULL,
  `fo_RecruitmentSession` varchar(40) DEFAULT NULL,
  `fo_Description` text,
  `fo_Date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`RecruitID`),
  UNIQUE KEY `CompID_unique` (`CompID`),
  KEY `EmployeeID` (`EmployeeID`),
  KEY `ProjectTeamID` (`ProjectTeamID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Recruitment`
--

LOCK TABLES `Recruitment` WRITE;
/*!40000 ALTER TABLE `Recruitment` DISABLE KEYS */;
/*!40000 ALTER TABLE `Recruitment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ReportComment`
--

DROP TABLE IF EXISTS `ReportComment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ReportComment` (
  `RunningID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PostID` int(10) unsigned DEFAULT '0',
  `TextPost` text,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`RunningID`),
  KEY `PostID` (`PostID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ReportComment`
--

LOCK TABLES `ReportComment` WRITE;
/*!40000 ALTER TABLE `ReportComment` DISABLE KEYS */;
/*!40000 ALTER TABLE `ReportComment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RiskandOpportunity`
--

DROP TABLE IF EXISTS `RiskandOpportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `RiskandOpportunity` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RISKid` varchar(250) NOT NULL,
  `Item` varchar(250) NOT NULL,
  `fo_Description` text,
  `fo_Class` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_Riskregister` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RISKid_unique` (`RISKid`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RiskandOpportunity`
--

LOCK TABLES `RiskandOpportunity` WRITE;
/*!40000 ALTER TABLE `RiskandOpportunity` DISABLE KEYS */;
/*!40000 ALTER TABLE `RiskandOpportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ScheduleWaste`
--

DROP TABLE IF EXISTS `ScheduleWaste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ScheduleWaste` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `worklocID` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `worklocID` (`worklocID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ScheduleWaste`
--

LOCK TABLES `ScheduleWaste` WRITE;
/*!40000 ALTER TABLE `ScheduleWaste` DISABLE KEYS */;
/*!40000 ALTER TABLE `ScheduleWaste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SoftboardComment`
--

DROP TABLE IF EXISTS `SoftboardComment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SoftboardComment` (
  `RunningID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `PostID` int(10) unsigned DEFAULT '0',
  `TextPost` text,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`RunningID`),
  KEY `PostID` (`PostID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SoftboardComment`
--

LOCK TABLES `SoftboardComment` WRITE;
/*!40000 ALTER TABLE `SoftboardComment` DISABLE KEYS */;
/*!40000 ALTER TABLE `SoftboardComment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `StakeholderSatisfaction`
--

DROP TABLE IF EXISTS `StakeholderSatisfaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `StakeholderSatisfaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecordID` varchar(256) NOT NULL,
  `RecTitle` varchar(256) DEFAULT NULL,
  `fo_ProjectId` int(10) unsigned NOT NULL,
  `fo_Recources` int(10) unsigned NOT NULL,
  `fo_ClientID` int(10) unsigned NOT NULL,
  `fo_gender` varchar(10) NOT NULL,
  `fo_SurveyType` text NOT NULL,
  `fo_Stakeholder` varchar(256) DEFAULT NULL,
  `fo_Description` text,
  `fo_Regdate` date DEFAULT NULL,
  `fo_website` varchar(200) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecordID_unique` (`RecordID`),
  KEY `fo_ProjectId` (`fo_ProjectId`),
  KEY `fo_Recources` (`fo_Recources`),
  KEY `fo_ClientID` (`fo_ClientID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `StakeholderSatisfaction`
--

LOCK TABLES `StakeholderSatisfaction` WRITE;
/*!40000 ALTER TABLE `StakeholderSatisfaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `StakeholderSatisfaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TeamSoftBoard`
--

DROP TABLE IF EXISTS `TeamSoftBoard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TeamSoftBoard` (
  `Postid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Title` varchar(250) NOT NULL,
  `image` varchar(40) DEFAULT NULL,
  `TextPost` text,
  `website` varchar(200) DEFAULT NULL,
  `Ref01` varchar(40) DEFAULT NULL,
  `filed` datetime DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`Postid`),
  UNIQUE KEY `Title_unique` (`Title`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TeamSoftBoard`
--

LOCK TABLES `TeamSoftBoard` WRITE;
/*!40000 ALTER TABLE `TeamSoftBoard` DISABLE KEYS */;
INSERT INTO `TeamSoftBoard` (`Postid`, `Title`, `image`, `TextPost`, `website`, `Ref01`, `filed`, `last_modified`) VALUES (1,'Welcome to the central portal of IMS','14270900_1528183038.jpg','we welcome all to the online colaborative platform. This will be the starting point of the organization journey towards better coordination of the ISO compliance activity.\r\n\r\nFeel free to comment and promote constructive input to support the organization goal towards success.',NULL,NULL,'2018-06-05 15:17:18',NULL),(2,'KEY ISO 9001 Principles','55003900_1528183084.jpg','ISO 9001:2015 Standard is based on seven Quality Management Principles (QMPs). Quality Management Principles are a set of fundamental beliefs, norms, rules and values that are accepted as true and can be used as a basis for quality management.\r\n\r\nhttp://psaa.com.sa/iso-90012015-qmps/',NULL,NULL,'2018-06-05 15:18:04',NULL),(3,'New ISO 9001 Structure','54442400_1528183124.png','This illustration shows the requirements for maintaining and retaining documents based on the clause in which they appear. Blue circles indicate what is typically referred to as required document while the red circles indicate what is typically referred to as a record requirement\r\n\r\nhttp://www.concentricglobal.co/blog/iso-9001-2015-documentation-requirements',NULL,NULL,'2018-06-05 15:18:44',NULL),(4,'PDCA cycle on ISO 9001','56491100_1528183164.jpg','The first three clauses in ISO 9001:2015 are largely the same as those in ISO 9001:2008, but there are considerable differences between ISO 9001:2008 and ISO 9001:2015 from the fourth clause onwards. The last seven clauses are now arranged according to the PDCA cycle (Plan, Do, Check, Act).\r\n\r\nClauses 4, 5, 6 and 7 of ISO 9001:2015 come under PLAN, clause 8 comes under DO, clause 9 comes under CHECK and clause 10 is covered by ACT.\r\n\r\nWith this new arrangement, the new ISO 9001:2015 strives to give additional momentum to the continuous and systematic improvement of processes within organisations.\r\n\r\nhttps://www.pauwelsconsulting.com/blog/iso-9001-2015/',NULL,NULL,'2018-06-05 15:19:24',NULL);
/*!40000 ALTER TABLE `TeamSoftBoard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ToolBoxMeeting`
--

DROP TABLE IF EXISTS `ToolBoxMeeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ToolBoxMeeting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tbmID` varchar(100) NOT NULL,
  `ccpID` int(10) unsigned DEFAULT '0',
  `fo_Desc` text,
  `fo_RequiredDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tbmID_unique` (`tbmID`),
  KEY `ccpID` (`ccpID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ToolBoxMeeting`
--

LOCK TABLES `ToolBoxMeeting` WRITE;
/*!40000 ALTER TABLE `ToolBoxMeeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `ToolBoxMeeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Training`
--

DROP TABLE IF EXISTS `Training`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Training` (
  `TrainingID` int(11) NOT NULL AUTO_INCREMENT,
  `TraningNo` varchar(100) NOT NULL,
  `EmployeeID` int(11) DEFAULT NULL,
  `ProjectTeamID` int(11) DEFAULT NULL,
  `fo_TrainingSession` varchar(40) DEFAULT NULL,
  `fo_Classification` varchar(40) DEFAULT NULL,
  `fo_Description` text,
  `fo_Date` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`TrainingID`),
  UNIQUE KEY `TraningNo_unique` (`TraningNo`),
  KEY `EmployeeID` (`EmployeeID`),
  KEY `ProjectTeamID` (`ProjectTeamID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Training`
--

LOCK TABLES `Training` WRITE;
/*!40000 ALTER TABLE `Training` DISABLE KEYS */;
/*!40000 ALTER TABLE `Training` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VenPerformance`
--

DROP TABLE IF EXISTS `VenPerformance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `VenPerformance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `VendPerfNumber` varchar(40) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_SupplierID` int(11) unsigned DEFAULT NULL,
  `fo_NewList` tinyint(4) DEFAULT '0',
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(100) NOT NULL DEFAULT 'Unknown',
  `fo_Perfdate` date DEFAULT NULL,
  `fo_image` varchar(40) DEFAULT NULL,
  `fo_address` text,
  `fo_city` varchar(40) DEFAULT NULL,
  `fo_state` varchar(15) DEFAULT NULL,
  `fo_zip` char(8) DEFAULT NULL,
  `fo_workphone` varchar(40) DEFAULT NULL,
  `fo_mobile` varchar(40) DEFAULT NULL,
  `fo_contactperson` varchar(100) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `VendPerfNumber_unique` (`VendPerfNumber`),
  KEY `fo_SupplierID` (`fo_SupplierID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VenPerformance`
--

LOCK TABLES `VenPerformance` WRITE;
/*!40000 ALTER TABLE `VenPerformance` DISABLE KEYS */;
/*!40000 ALTER TABLE `VenPerformance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkEnvMonitoring`
--

DROP TABLE IF EXISTS `WorkEnvMonitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkEnvMonitoring` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DocconNumber` varchar(40) NOT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Classification` varchar(10) NOT NULL DEFAULT 'Unknown',
  `fo_Impact` text NOT NULL,
  `fo_Regdate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherDetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `DocconNumber_unique` (`DocconNumber`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkEnvMonitoring`
--

LOCK TABLES `WorkEnvMonitoring` WRITE;
/*!40000 ALTER TABLE `WorkEnvMonitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `WorkEnvMonitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkLocation`
--

DROP TABLE IF EXISTS `WorkLocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkLocation` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `BaseLocation` varchar(250) NOT NULL,
  `DocItem` varchar(255) NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_Type` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_Sector` varchar(256) DEFAULT NULL,
  `fo_Zone` varchar(256) DEFAULT NULL,
  `fo_Country` varchar(15) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BaseLocation_unique` (`BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkLocation`
--

LOCK TABLES `WorkLocation` WRITE;
/*!40000 ALTER TABLE `WorkLocation` DISABLE KEYS */;
INSERT INTO `WorkLocation` (`id`, `BaseLocation`, `DocItem`, `fo_DocumentDescription`, `fo_Type`, `fo_Sector`, `fo_Zone`, `fo_Country`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'1020-001','OFFICE HQ SENAI','Head Office Senai','Head Quaters','SOUTHERN','SENAI','Malaysia',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 15:26:09',NULL),(2,'1020-002','SALES HQ OFFICE','Sales Office KL','Head Quaters','CENTRAL','Wilayah Persekutuan','Malaysia',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 15:27:32',NULL);
/*!40000 ALTER TABLE `WorkLocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkOrder`
--

DROP TABLE IF EXISTS `WorkOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkOrder` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `WONumber` varchar(40) NOT NULL,
  `Task` varchar(100) NOT NULL,
  `fo_Critical` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_EmployeeID` int(11) DEFAULT NULL,
  `fo_Position` int(11) DEFAULT NULL,
  `fo_BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_JobInstruction` text NOT NULL,
  `fo_DetailInstruction` text,
  `fo_Resources` text,
  `fo_Duedate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `WONumber_unique` (`WONumber`),
  KEY `fo_EmployeeID` (`fo_EmployeeID`),
  KEY `fo_BaseLocation` (`fo_BaseLocation`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkOrder`
--

LOCK TABLES `WorkOrder` WRITE;
/*!40000 ALTER TABLE `WorkOrder` DISABLE KEYS */;
/*!40000 ALTER TABLE `WorkOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WorkPermit`
--

DROP TABLE IF EXISTS `WorkPermit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WorkPermit` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `RecNum` varchar(100) NOT NULL,
  `WrLocID` int(10) unsigned DEFAULT '0',
  `fo_Type` varchar(250) NOT NULL DEFAULT 'Unknown',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `RecNum_unique` (`RecNum`),
  KEY `WrLocID` (`WrLocID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WorkPermit`
--

LOCK TABLES `WorkPermit` WRITE;
/*!40000 ALTER TABLE `WorkPermit` DISABLE KEYS */;
/*!40000 ALTER TABLE `WorkPermit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batches`
--

DROP TABLE IF EXISTS `batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batches` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `batch_no` varchar(40) NOT NULL,
  `fo_item` int(11) DEFAULT NULL,
  `fo_suppliers` int(11) unsigned DEFAULT NULL,
  `fo_manudate` date DEFAULT NULL,
  `fo_expdate` date DEFAULT NULL,
  `fo_Quantity` decimal(10,0) DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `fo_otherdetails` text,
  `fo_comments` text,
  `fo_SharedLink1` varchar(200) DEFAULT NULL,
  `fo_SharedLink2` varchar(200) DEFAULT NULL,
  `fo_Ref01` varchar(40) DEFAULT NULL,
  `fo_Ref02` varchar(40) DEFAULT NULL,
  `fo_Photo` varchar(40) DEFAULT NULL,
  `fo_ap_filed` datetime DEFAULT NULL,
  `fo_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `batch_no_unique` (`batch_no`),
  KEY `fo_item` (`fo_item`),
  KEY `fo_suppliers` (`fo_suppliers`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batches`
--

LOCK TABLES `batches` WRITE;
/*!40000 ALTER TABLE `batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `CategoryID` int(11) NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(50) NOT NULL,
  `fo_Description` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Picture` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`CategoryID`),
  UNIQUE KEY `CategoryName_unique` (`CategoryName`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`CategoryID`, `CategoryName`, `fo_Description`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Picture`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'General Item','<span style=\"font-size: 11.998px;\">General Item. Available easily off the shelve</span><br>',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:08:08',NULL),(2,'Mechanical Consumables','Replaceable mechanical consumables parts',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:09:03',NULL),(3,'Electrical Consumables','Electrical consumables parts',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:12:09',NULL),(4,'Hydraulic Consumables','Hydraulic Consumables<br>',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:12:31',NULL),(5,'Electronic Consumables','Electronic Consumables<br>',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:12:51',NULL),(6,'Stationery','<span style=\"font-size: 11.998px;\">General Stationery item for administrative usage</span><br>',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:13:40',NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `EmployeeID` int(11) NOT NULL AUTO_INCREMENT,
  `EmpNo` varchar(256) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `BaseLocation` int(10) unsigned DEFAULT NULL,
  `fo_TermEmployment` varchar(50) DEFAULT NULL,
  `fo_Photo` varchar(40) DEFAULT NULL,
  `fo_Position` varchar(200) DEFAULT NULL,
  `fo_BirthDate` date DEFAULT NULL,
  `fo_HireDate` date DEFAULT NULL,
  `fo_Address` varchar(50) DEFAULT NULL,
  `fo_City` varchar(100) DEFAULT NULL,
  `fo_Region` varchar(100) DEFAULT NULL,
  `fo_PostalCode` varchar(10) DEFAULT NULL,
  `fo_Country` varchar(100) DEFAULT NULL,
  `fo_HomePhone` varchar(24) DEFAULT NULL,
  `fo_Extension` varchar(4) DEFAULT NULL,
  `fo_Notes` text,
  `fo_ReportsTo` int(11) DEFAULT NULL,
  `fo_Acknowledgement` int(11) DEFAULT '0',
  `fo_Induction` tinyint(4) DEFAULT '0',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`EmployeeID`),
  UNIQUE KEY `EmpNo_unique` (`EmpNo`),
  KEY `BaseLocation` (`BaseLocation`),
  KEY `fo_ReportsTo` (`fo_ReportsTo`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` (`EmployeeID`, `EmpNo`, `Name`, `BaseLocation`, `fo_TermEmployment`, `fo_Photo`, `fo_Position`, `fo_BirthDate`, `fo_HireDate`, `fo_Address`, `fo_City`, `fo_Region`, `fo_PostalCode`, `fo_Country`, `fo_HomePhone`, `fo_Extension`, `fo_Notes`, `fo_ReportsTo`, `fo_Acknowledgement`, `fo_Induction`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'3010-001','SITI BALKIS BINTI MOHD ARIFFIN',1,'Permanent','38108700_1528187804.jpg','ENGINEER','1989-02-15','2018-01-01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,1,1,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:36:44',NULL),(2,'3010-002','SHARIFAH NAJWA',2,'Contract','75574500_1528187926.jpg','SECRETARY SALES','1990-08-15','2018-01-05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,1,1,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:38:46',NULL),(3,'3010-003','IBRAHIM ALI',1,'Permanent','30128200_1528188003.jpg','DIRECTOR','1975-03-16','2016-01-05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,1,1,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:40:03',NULL);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_grouppermissions`
--

DROP TABLE IF EXISTS `membership_grouppermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_grouppermissions` (
  `permissionID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupID` int(11) DEFAULT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT '0',
  `allowEdit` tinyint(4) NOT NULL DEFAULT '0',
  `allowDelete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permissionID`)
) ENGINE=MyISAM AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_grouppermissions`
--

LOCK TABLES `membership_grouppermissions` WRITE;
/*!40000 ALTER TABLE `membership_grouppermissions` DISABLE KEYS */;
INSERT INTO `membership_grouppermissions` (`permissionID`, `groupID`, `tableName`, `allowInsert`, `allowView`, `allowEdit`, `allowDelete`) VALUES (1,2,'OrgContentContext',1,3,3,3),(2,2,'Marketing',1,3,3,3),(3,2,'Client',1,3,3,3),(4,2,'Inquiry',1,3,3,3),(5,2,'DesignProposal',1,3,3,3),(6,2,'ContractDeployment',1,3,3,3),(7,2,'employees',1,3,3,3),(8,2,'Recruitment',1,3,3,3),(9,2,'PersonnalFile',1,3,3,3),(10,2,'Competency',1,3,3,3),(11,2,'Training',1,3,3,3),(12,2,'JD_JS',1,3,3,3),(13,2,'InOutRegister',1,3,3,3),(14,2,'vendor',1,3,3,3),(15,2,'ManagingVendor',1,3,3,3),(16,2,'VenPerformance',1,3,3,3),(17,2,'Logistics',1,3,3,3),(18,2,'Inventory',1,3,3,3),(19,2,'CalibrationCtrl',1,3,3,3),(20,2,'WorkOrder',1,3,3,3),(21,2,'MWO',1,3,3,3),(22,2,'MWOPlanned',1,3,3,3),(23,2,'MWOpreventive',1,3,3,3),(24,2,'MWOproactive',1,3,3,3),(25,2,'MWConditionBased',1,3,3,3),(26,2,'MWOReactive',1,3,3,3),(27,2,'MWOCorrective',1,3,3,3),(28,2,'LogisticRequest',1,3,3,3),(29,2,'orders',1,3,3,3),(30,2,'Quotation',1,3,3,3),(31,2,'PurchaseOrder',1,3,3,3),(32,2,'DeliveryOrder',1,3,3,3),(33,2,'AccountPayables',1,3,3,3),(34,2,'Item',1,3,3,3),(35,2,'categories',1,3,3,3),(36,2,'batches',1,3,3,3),(37,2,'transactions',1,3,3,3),(38,2,'CommConsParticipate',1,3,3,3),(39,2,'ToolBoxMeeting',1,3,3,3),(40,2,'Bi_WeeklyMeeting',1,3,3,3),(41,2,'QuarterlyMeeting',1,3,3,3),(42,2,'Campaign',1,3,3,3),(43,2,'DrillNInspection',1,3,3,3),(44,2,'ManagementVisit',1,3,3,3),(45,2,'EventNotification',1,3,3,3),(46,2,'ActCard',1,3,3,3),(47,2,'KM',1,3,3,3),(48,2,'LegalRegister',1,3,3,3),(49,2,'RiskandOpportunity',1,3,3,3),(50,2,'DocControl',1,3,3,3),(51,2,'DCN',1,3,3,3),(52,2,'ObsoleteRec',1,3,3,3),(53,2,'QA',1,3,3,3),(54,2,'ERP',1,3,3,3),(55,2,'WorkEnvMonitoring',1,3,3,3),(56,2,'ScheduleWaste',1,3,3,3),(57,2,'IncidentReporting',1,3,3,3),(58,2,'MgtofChange',1,3,3,3),(59,2,'IMStrackingNmonitoring',1,3,3,3),(60,2,'IMSDataAnalysis',1,3,3,3),(61,2,'Audit',1,3,3,3),(62,2,'NonConformance',1,3,3,3),(63,2,'ContinualImprovement',1,3,3,3),(64,2,'StakeholderSatisfaction',1,3,3,3),(65,2,'MRM',1,3,3,3),(66,2,'projects',1,3,3,3),(67,2,'WorkLocation',1,3,3,3),(68,2,'WorkPermit',1,3,3,3),(69,2,'ProjectTeam',1,3,3,3),(70,2,'resources',1,3,3,3),(71,2,'PROInitiation',1,3,3,3),(72,2,'PROPlanning',1,3,3,3),(73,2,'PROExecution',1,3,3,3),(74,2,'DailyProgressReport',1,3,3,3),(75,2,'MonthlyTimesheet',1,3,3,3),(76,2,'Breakdown',1,3,3,3),(77,2,'PROControlMonitoring',1,3,3,3),(78,2,'PROVariation',1,3,3,3),(79,2,'PROCompletion',1,3,3,3),(80,2,'Receivables',1,3,3,3),(81,2,'ClaimRecord',1,3,3,3),(82,2,'TeamSoftBoard',1,3,3,3),(83,2,'SoftboardComment',1,3,3,3),(84,2,'IMSReport',1,3,3,3),(85,2,'ReportComment',1,3,3,3),(86,2,'Leadership',1,3,3,3),(87,2,'Approval',1,3,3,3),(88,2,'IMSControl',1,3,3,3);
/*!40000 ALTER TABLE `membership_grouppermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_groups`
--

DROP TABLE IF EXISTS `membership_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_groups` (
  `groupID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `description` text,
  `allowSignup` tinyint(4) DEFAULT NULL,
  `needsApproval` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`groupID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_groups`
--

LOCK TABLES `membership_groups` WRITE;
/*!40000 ALTER TABLE `membership_groups` DISABLE KEYS */;
INSERT INTO `membership_groups` (`groupID`, `name`, `description`, `allowSignup`, `needsApproval`) VALUES (1,'anonymous','Anonymous group created automatically on 2018-06-03',0,0),(2,'Admins','Admin group created automatically on 2018-06-03',0,1);
/*!40000 ALTER TABLE `membership_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_userpermissions`
--

DROP TABLE IF EXISTS `membership_userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_userpermissions` (
  `permissionID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `memberID` varchar(20) NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT '0',
  `allowEdit` tinyint(4) NOT NULL DEFAULT '0',
  `allowDelete` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permissionID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_userpermissions`
--

LOCK TABLES `membership_userpermissions` WRITE;
/*!40000 ALTER TABLE `membership_userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `membership_userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_userrecords`
--

DROP TABLE IF EXISTS `membership_userrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_userrecords` (
  `recID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tableName` varchar(100) DEFAULT NULL,
  `pkValue` varchar(255) DEFAULT NULL,
  `memberID` varchar(20) DEFAULT NULL,
  `dateAdded` bigint(20) unsigned DEFAULT NULL,
  `dateUpdated` bigint(20) unsigned DEFAULT NULL,
  `groupID` int(11) DEFAULT NULL,
  PRIMARY KEY (`recID`),
  UNIQUE KEY `tableName_pkValue` (`tableName`,`pkValue`),
  KEY `pkValue` (`pkValue`),
  KEY `tableName` (`tableName`),
  KEY `memberID` (`memberID`),
  KEY `groupID` (`groupID`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_userrecords`
--

LOCK TABLES `membership_userrecords` WRITE;
/*!40000 ALTER TABLE `membership_userrecords` DISABLE KEYS */;
INSERT INTO `membership_userrecords` (`recID`, `tableName`, `pkValue`, `memberID`, `dateAdded`, `dateUpdated`, `groupID`) VALUES (1,'Leadership','1','administrator',1528182326,1528182540,2),(2,'Leadership','2','administrator',1528182566,1528182566,2),(3,'Leadership','3','administrator',1528182609,1528182609,2),(4,'Leadership','4','administrator',1528182626,1528182626,2),(5,'Approval','1','administrator',1528182658,1528182658,2),(6,'Approval','2','administrator',1528182679,1528182679,2),(7,'Approval','3','administrator',1528182696,1528182696,2),(8,'Approval','4','administrator',1528182730,1528182730,2),(9,'IMSControl','1','administrator',1528182757,1528182757,2),(10,'IMSControl','2','administrator',1528182793,1528182793,2),(11,'IMSControl','3','administrator',1528182809,1528182809,2),(12,'IMSControl','4','administrator',1528182828,1528182828,2),(13,'IMSReport','1','administrator',1528182912,1528182912,2),(14,'TeamSoftBoard','1','administrator',1528183038,1528183038,2),(15,'TeamSoftBoard','2','administrator',1528183084,1528183084,2),(16,'TeamSoftBoard','3','administrator',1528183124,1528183124,2),(17,'TeamSoftBoard','4','administrator',1528183164,1528183164,2),(18,'projects','1','administrator',1528183291,1528183291,2),(19,'projects','2','administrator',1528183371,1528183371,2),(20,'projects','3','administrator',1528183428,1528183428,2),(21,'WorkLocation','1','administrator',1528183569,1528183569,2),(22,'WorkLocation','2','administrator',1528183652,1528183652,2),(23,'ProjectTeam','1','administrator',1528183775,1528183775,2),(24,'resources','1','administrator',1528183854,1528183854,2),(25,'Marketing','1','administrator',1528184058,1528184058,2),(26,'Client','1','administrator',1528184441,1528184441,2),(27,'Inquiry','1','administrator',1528184627,1528184760,2),(28,'Logistics','1','administrator',1528184723,1528184723,2),(29,'vendor','1','administrator',1528184839,1528184839,2),(30,'vendor','2','administrator',1528184935,1528185538,2),(31,'vendor','3','administrator',1528185408,1528185408,2),(32,'vendor','4','administrator',1528185917,1528185917,2),(33,'categories','1','administrator',1528186088,1528186088,2),(34,'categories','2','administrator',1528186143,1528186143,2),(35,'categories','3','administrator',1528186329,1528186329,2),(36,'categories','4','administrator',1528186351,1528186351,2),(37,'categories','5','administrator',1528186371,1528186371,2),(38,'categories','6','administrator',1528186420,1528186420,2),(39,'Inventory','1','administrator',1528186608,1528186608,2),(40,'Inventory','2','administrator',1528186871,1528186871,2),(41,'employees','1','administrator',1528187804,1528187804,2),(42,'employees','2','administrator',1528187926,1528187926,2),(43,'employees','3','administrator',1528188003,1528188003,2),(44,'JD_JS','1','administrator',1528188232,1528188232,2);
/*!40000 ALTER TABLE `membership_userrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_users`
--

DROP TABLE IF EXISTS `membership_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_users` (
  `memberID` varchar(20) NOT NULL,
  `passMD5` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `signupDate` date DEFAULT NULL,
  `groupID` int(10) unsigned DEFAULT NULL,
  `isBanned` tinyint(4) DEFAULT NULL,
  `isApproved` tinyint(4) DEFAULT NULL,
  `custom1` text,
  `custom2` text,
  `custom3` text,
  `custom4` text,
  `comments` text,
  `pass_reset_key` varchar(100) DEFAULT NULL,
  `pass_reset_expiry` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`memberID`),
  KEY `groupID` (`groupID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_users`
--

LOCK TABLES `membership_users` WRITE;
/*!40000 ALTER TABLE `membership_users` DISABLE KEYS */;
INSERT INTO `membership_users` (`memberID`, `passMD5`, `email`, `signupDate`, `groupID`, `isBanned`, `isApproved`, `custom1`, `custom2`, `custom3`, `custom4`, `comments`, `pass_reset_key`, `pass_reset_expiry`) VALUES ('guest',NULL,NULL,'2018-06-03',1,0,1,NULL,NULL,NULL,NULL,'Anonymous member created automatically on 2018-06-03',NULL,NULL),('administrator','200ceb26807d6bf99fd6f4f0d1ca54d4','syamsul.azmee@supplynetworkagency.com','2018-06-03',2,0,1,NULL,NULL,NULL,NULL,'Admin member created automatically on 2018-06-03\nRecord updated automatically on 2018-06-02',NULL,NULL);
/*!40000 ALTER TABLE `membership_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `OrderID` varchar(100) NOT NULL,
  `Market_Survey` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_Classification` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_Critical` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_Justification` varchar(40) NOT NULL DEFAULT 'Unknown',
  `fo_ProjectID` int(10) unsigned NOT NULL,
  `fo_InventoryID` int(10) unsigned NOT NULL,
  `fo_ItemID` int(11) NOT NULL,
  `fo_ProductID` int(11) DEFAULT '0',
  `fo_Description` varchar(255) DEFAULT NULL,
  `fo_Detail` text,
  `fo_OrderDate` date DEFAULT NULL,
  `fo_RequiredDate` date DEFAULT NULL,
  `fo_ShippedDate` date DEFAULT NULL,
  `fo_ShipVia` int(11) unsigned DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `OrderID_unique` (`OrderID`),
  KEY `fo_ProjectID` (`fo_ProjectID`),
  KEY `fo_InventoryID` (`fo_InventoryID`),
  KEY `fo_ItemID` (`fo_ItemID`),
  KEY `fo_ShipVia` (`fo_ShipVia`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `projectID` varchar(200) NOT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `fo_ProjectIndication` text NOT NULL,
  `fo_DocumentDescription` text NOT NULL,
  `fo_StartDate` date DEFAULT NULL,
  `fo_EndDate` date DEFAULT NULL,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `projectID_unique` (`projectID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` (`Id`, `projectID`, `Name`, `fo_ProjectIndication`, `fo_DocumentDescription`, `fo_StartDate`, `fo_EndDate`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'1100-001','NON-PROJECT ACTIVITIES','Others','This to enable the function of all request order or form that is not related to any project','2018-01-01','2018-12-31','NA',NULL,'<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,2,NULL,2,NULL,'2018-06-05 15:21:31',NULL),(2,'1100-002','INTERNAL GENERAL PROJECT','Others','All internal project request to be position here. this can be created annually. based on annual budget','2018-01-01','2018-12-31',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,2,NULL,2,NULL,'2018-06-05 15:22:51',NULL),(3,'1100-003','EXTERNAL GENERAL PROJECT','Others','All external project request to be position here. this can be created annually. based on annual budget','2018-01-01','2018-12-31',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,2,NULL,2,NULL,'2018-06-05 15:23:48',NULL);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resources`
--

DROP TABLE IF EXISTS `resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resources` (
  `Id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ResourcesID` varchar(200) NOT NULL,
  `Name` varchar(250) DEFAULT NULL,
  `fo_Type` text NOT NULL,
  `fo_Description` text,
  `fo_Available` varchar(40) DEFAULT '1',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `ResourcesID_unique` (`ResourcesID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resources`
--

LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
INSERT INTO `resources` (`Id`, `ResourcesID`, `Name`, `fo_Type`, `fo_Description`, `fo_Available`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'1040_001','NOT APPLICABLE','OTHERS','<span style=\"font-size: 11.99px;\">Generic line item for asset. This is prepared for general default setting</span><br>','1',NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,'2018-06-05 15:30:54',NULL);
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TransCode` varchar(256) NOT NULL,
  `fo_transaction_date` date DEFAULT NULL,
  `fo_item` int(11) DEFAULT NULL,
  `fo_ResourcesID` int(10) unsigned DEFAULT NULL,
  `fo_transactiontype` varchar(40) NOT NULL,
  `fo_quantity` decimal(10,2) DEFAULT '1.00',
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TransCode_unique` (`TransCode`),
  KEY `fo_item` (`fo_item`),
  KEY `fo_ResourcesID` (`fo_ResourcesID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor` (
  `VendorID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `CompanyID` varchar(200) NOT NULL,
  `CopanyName` varchar(100) DEFAULT NULL,
  `fo_AVList` tinyint(4) DEFAULT '0',
  `fo_ContactTitle` varchar(100) DEFAULT NULL,
  `fo_Address` varchar(100) DEFAULT NULL,
  `fo_City` varchar(50) DEFAULT NULL,
  `fo_Region` varchar(50) DEFAULT NULL,
  `fo_PostalCode` varchar(10) DEFAULT NULL,
  `fo_Country` varchar(50) DEFAULT NULL,
  `fo_Phone` varchar(24) DEFAULT NULL,
  `fo_Fax` varchar(24) DEFAULT NULL,
  `fo_HomePage` text,
  `ot_FileLoc` varchar(100) DEFAULT NULL,
  `ot_otherdetails` text,
  `ot_comments` text,
  `ot_SharedLink1` varchar(200) DEFAULT NULL,
  `ot_SharedLink2` varchar(200) DEFAULT NULL,
  `ot_Ref01` varchar(40) DEFAULT NULL,
  `ot_Ref02` varchar(40) DEFAULT NULL,
  `ot_Photo` varchar(40) DEFAULT NULL,
  `ot_ap_Review` int(10) unsigned DEFAULT NULL,
  `ot_ap_RevComment` text,
  `ot_ap_Approval` int(10) unsigned DEFAULT NULL,
  `ot_ap_ApprComment` text,
  `ot_ap_QC` int(10) unsigned DEFAULT NULL,
  `ot_ap_QCComment` text,
  `ot_ap_filed` datetime DEFAULT NULL,
  `ot_ap_lastmodified` datetime DEFAULT NULL,
  PRIMARY KEY (`VendorID`),
  UNIQUE KEY `CompanyID_unique` (`CompanyID`),
  KEY `ot_ap_Review` (`ot_ap_Review`),
  KEY `ot_ap_Approval` (`ot_ap_Approval`),
  KEY `ot_ap_QC` (`ot_ap_QC`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor`
--

LOCK TABLES `vendor` WRITE;
/*!40000 ALTER TABLE `vendor` DISABLE KEYS */;
INSERT INTO `vendor` (`VendorID`, `CompanyID`, `CopanyName`, `fo_AVList`, `fo_ContactTitle`, `fo_Address`, `fo_City`, `fo_Region`, `fo_PostalCode`, `fo_Country`, `fo_Phone`, `fo_Fax`, `fo_HomePage`, `ot_FileLoc`, `ot_otherdetails`, `ot_comments`, `ot_SharedLink1`, `ot_SharedLink2`, `ot_Ref01`, `ot_Ref02`, `ot_Photo`, `ot_ap_Review`, `ot_ap_RevComment`, `ot_ap_Approval`, `ot_ap_ApprComment`, `ot_ap_QC`, `ot_ap_QCComment`, `ot_ap_filed`, `ot_ap_lastmodified`) VALUES (1,'5010_001','GENERAL VENDOR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'<br>',NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 15:47:19',NULL),(2,'5010_002','BECON ENTERPRISE SDN BHD',NULL,'SALES MARKETING','BECON ENTERPRISE SDN BHD\r\nNO 19,11,13 & 15 JALAN KEMPAS 2','KEMPAS','JOHOR','81900','Malaysia','07 232 1166','07 232 1188','sales-jb@becon',NULL,NULL,'<br>','https://becon.my/',NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 15:48:55','2018-06-05 15:58:58'),(3,'5010_003','CI INTERNATIONAL CERTIFICATION SDN. BHD',NULL,'MR. OOI SOO KANG, MANAGING DERICTOR','NO. 37-4 Jalan SP 2/2, Serdang Perdana, Seksyen 2','SERI KEMBANGAN','SELANGOR','43300','Malaysia','03 8942 9001','03 8942 9002','cimarketing@cimalaysia.com.my',NULL,'CI International Certification Sdn Bhd (known as CI International) operates under the group of Certification International (UK) Ltd. (CIUK) in Swindon, United Kingdom. CI International started its office in Malaysia in May 2000, by the founder Mr Ooi Soo Kang, who is now the Country Director/ Managing Director of the local Malaysia office.\r\n\r\nCI International is one of the leading certification bodies in Malaysia, providing international certification services to assist organizations that seek to harness on Quality, Environmental, Information Security, Food Safety, Occupational Health and Safety, Energy, and Information Technology Service Management System for business performance improvement.','<br>','http://www.cimalaysia.com.my/',NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 15:56:48',NULL),(4,'5010_004','Supply Network Agency PLT',NULL,'Syamsul Nizam Azmee','no 38, Jalan Desa 13-1','Bandar Country Homes','Selangor','48000','Malaysia','+60124883001',NULL,'syamsul.azmee@supplynetworkagency.com','NA','We have over 20 years of experience providing insightful quality management system advice for both businesses and entrepreneurs. Our team Committee brings decades of industry expertise in driving our management approach, foundation outline, and resource allocation. The committee ensures our involvement are best in class, combining substantiated survey with the most effective management tools available today.','<br>','https://www.qualitymanagementcentral.com',NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,'2018-06-05 16:05:17',NULL);
/*!40000 ALTER TABLE `vendor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'priggm80_pjd05'
--

--
-- Dumping routines for database 'priggm80_pjd05'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-10-27 17:39:55
