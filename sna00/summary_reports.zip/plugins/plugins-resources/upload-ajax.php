<?php
	include(dirname(__FILE__) . '/AppGiniPlugin.php');
	
	$plugin = new AppGiniPlugin();
	$plugin->process_ajax_upload();