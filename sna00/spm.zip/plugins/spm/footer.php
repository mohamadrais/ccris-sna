		<?php echo $spm->git_branch(); ?>
		
		</div> <!-- /div.container -->
	</body>
</html>
